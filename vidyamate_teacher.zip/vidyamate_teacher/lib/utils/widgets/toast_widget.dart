import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../resources/my_colors.dart';

class ToastWidget {
  static void showToast({required BuildContext context, required String msg}) {
    Fluttertoast.showToast(
      msg: msg,
      fontSize: 13,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: MyColor.coral,
      textColor: MyColor.white,
    );
  }
}
