import 'dart:ui';
import 'package:flutter/material.dart';

class Global {
  static const Color white = const Color(0xffffffff);
  static const Color mediumBlue = const Color(0xff4A64FE);
  static const List validEmail = ['test@gmail.com'];
}
