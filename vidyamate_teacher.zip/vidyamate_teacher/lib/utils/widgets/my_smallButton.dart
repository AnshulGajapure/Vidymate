
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../resources/my_colors.dart';
import '../../resources/my_font.dart';

Widget mySmallButton({
  required VoidCallback? onTap,
  required String? btnName,
  required double? btnWidth,
}) {
  return Container(
      width: btnWidth,
      height: 45.0,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [MyColor.secondryColor, MyColor.primaryColor],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: MaterialButton(
        shape: RoundedRectangleBorder(borderRadius: new BorderRadius.circular(10.0)),
        textColor: Colors.white,
        //color: MyColor.primaryColor,
        splashColor: Color.fromARGB(255, 80, 144, 255),
        disabledColor: MyColor.primaryColor,
        onPressed: onTap!,
        child: GestureDetector(
          onTap: onTap,
          child: Text(
            btnName!,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontFamily: MyFont.jakartaMedium,
              color: Colors.white,
              fontSize: 16.0,
              //fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ));
}
