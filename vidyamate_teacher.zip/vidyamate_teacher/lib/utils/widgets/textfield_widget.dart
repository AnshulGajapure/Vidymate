import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'globals.dart';

class TextFieldWidget extends StatelessWidget {
  final String hintText;
  final IconData prefixIconData;
  final IconData suffixIconData;
  final bool obscureText;
  final Function(String) onChanged;

  TextFieldWidget({
    required this.hintText,
    required this.prefixIconData,
    required this.suffixIconData,
    required this.obscureText,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final TextFieldController controller = Get.put(TextFieldController());

    return Obx(() {
      return TextField(
        onChanged: onChanged,
        obscureText: obscureText && !controller.isVisible.value,
        cursorColor: Global.mediumBlue,
        style: TextStyle(
          color: Global.mediumBlue,
          fontSize: 14.0,
        ),
        decoration: InputDecoration(
          labelStyle: TextStyle(color: Global.mediumBlue),
          focusColor: Global.mediumBlue,
          filled: true,
          enabledBorder: UnderlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide(color: Global.mediumBlue),
          ),
          labelText: hintText,
          prefixIcon: Icon(
            prefixIconData,
            size: 18,
            color: Global.mediumBlue,
          ),
          suffixIcon: GestureDetector(
            onTap: () {
              controller.toggleVisibility();
            },
            child: Icon(
              suffixIconData,
              size: 18,
              color: Global.mediumBlue,
            ),
          ),
        ),
      );
    });
  }
}
class TextFieldController extends GetxController {
  RxBool isVisible = false.obs;

  void toggleVisibility() {
    isVisible.value = !isVisible.value;
  }
}