import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../resources/my_colors.dart';
import '../../resources/my_font.dart';

Widget myButton({
  required context,
  required VoidCallback? onTap,
  required String? btnName,
  required int? colorType,
}) {
  return Container(
    // width: MediaQuery.of(context).size.width,
    width: Get.height * 0.2,
    height: Get.height * 0.06,
    child: MaterialButton(
        //shape: StadiumBorder(),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(25.0),
        ),
        textColor: Colors.white,
        color: colorType == 1 ? MyColor.coral : Colors.grey.shade800,
        splashColor: MyColor.coral,
        disabledColor: MyColor.coral,
        onPressed: onTap!,
        elevation: 3.0,
        child: GestureDetector(
          onTap: onTap,
          child: Text(
            btnName!,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: MyFont.jakartaMedium,
              //color: Colors.white,
              fontSize: Get.width * 0.043,
              //fontWeight: FontWeight.bold,
            ),
          ),
        )),
  );
}

class CustomButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String buttonText;

  CustomButton({required this.onPressed, required this.buttonText});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: Container(
        width: MediaQuery.of(context).size.width * 0.5,
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 30),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          // Adjust to match rounded corners
          gradient: LinearGradient(
            colors: [
              Color(0xFF24A0FB),
              Color(0xFF0067B2),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: Text(
            buttonText,
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              fontFamily: 'LexendRegular',
            ),
          ),
        ),
      ),
    );
  }
}
