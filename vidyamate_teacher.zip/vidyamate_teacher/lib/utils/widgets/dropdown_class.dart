import 'package:flutter/material.dart';
import '../../model/class_Section_Model.dart';

class ClassAndSectionDropdown extends StatefulWidget {
  final List<Payload> items;
  final Function(int?) onItemSelected;

  ClassAndSectionDropdown({required this.items, required this.onItemSelected});

  @override
  _ClassAndSectionDropdownState createState() =>
      _ClassAndSectionDropdownState();
}

class _ClassAndSectionDropdownState extends State<ClassAndSectionDropdown> {
  Payload? selectedPayload;

  @override
  void initState() {
    super.initState();
    if (widget.items.isNotEmpty) {
      selectedPayload = widget.items[0];
      widget.onItemSelected(selectedPayload?.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    return Container(
      width: screenWidth * 0.28,
      height: screenHeight * 0.05,
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(
          color: Colors.grey.shade300,
          width: 2,
        ),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<Payload>(
          value: selectedPayload,
          onChanged: (Payload? newValue) {
            setState(() {
              selectedPayload = newValue;
            });
            widget.onItemSelected(newValue?.id);
          },
          items: widget.items.map((Payload item) {
            return DropdownMenuItem<Payload>(
              value: item,
              child: Text('${item.className} ${item.section}',
                  style: TextStyle(fontSize: 12)),
            );
          }).toList(),
        ),
      ),
    );
  }
}
