import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';

class ActiveProjectsCard extends StatelessWidget {
  final Color cardColor;
  final double loadingPercent;
  final String title;
  final String reportCount;

  ActiveProjectsCard({
    required this.cardColor,
    required this.loadingPercent,
    required this.title,
    required this.reportCount,
  });

  @override
  Widget build(BuildContext context) {
    double deviceWidth = MediaQuery.of(context).size.width;
    double deviceHeight = MediaQuery.of(context).size.height;

    return Expanded(
      flex: 1,
      child: Container(
        margin: EdgeInsets.symmetric(vertical: deviceHeight * 0.02),
        padding: EdgeInsets.all(deviceWidth * 0.04),
        height: deviceHeight * 0.223,
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(deviceWidth * 0.1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.2),
              spreadRadius: 3,
              blurRadius: 10,
              offset: Offset(4, 8),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.1),
              spreadRadius: -2,
              blurRadius: 15,
              offset: Offset(-4, -4),
            ),
          ],
          gradient: LinearGradient(
            colors: [
              cardColor.withOpacity(0.9),
              cardColor,
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.symmetric(horizontal: deviceWidth * 0.01),
              child: CircularPercentIndicator(
                animation: true,
                radius: deviceWidth * 0.11,
                percent: loadingPercent,
                lineWidth: deviceWidth * 0.015,
                circularStrokeCap: CircularStrokeCap.round,
                backgroundColor: Colors.white10,
                progressColor: Colors.white,
                center: Text(
                  '${reportCount}',
                  style: TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: deviceWidth * 0.05,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            SizedBox(height: deviceHeight * 0.01), // Add space between indicator and title
            Expanded(
              child: Center(
                child: Text(
                  title,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  style: TextStyle(
                    fontSize: deviceWidth * 0.04,
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ),
            // Optionally handle subtitle if needed
            // if (subtitle.isNotEmpty)
            //   Text(
            //     subtitle,
            //     style: TextStyle(
            //       fontSize: deviceWidth * 0.035,
            //       color: Colors.white54,
            //       fontWeight: FontWeight.w400,
            //     ),
            //   ),
          ],
        ),
      ),
    );
  }
}
