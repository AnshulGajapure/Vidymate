import 'package:flutter/material.dart';

import '../../resources/my_colors.dart';

class TopContainer extends StatelessWidget {
  final double height;
  final double width;
  final Widget child;
  final EdgeInsets padding;

  TopContainer({
    required this.height,
    required this.width,
    required this.child,
    required this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding != null ? padding : EdgeInsets.symmetric(horizontal: 20.0),
      decoration: BoxDecoration(
        // Use gradient to give a subtle depth with a color transition
        gradient: MyColor.coralLightYellowGradient,
        // Rounded corners for smooth appearance
        borderRadius: BorderRadius.only(
          bottomRight: Radius.circular(40.0),
          bottomLeft: Radius.circular(40.0),
          topLeft: Radius.circular(40.0),
          topRight: Radius.circular(40.0),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            spreadRadius: 2,
            blurRadius: 10,
            offset: Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.1),
            spreadRadius: -3,
            blurRadius: 15,
            offset: Offset(-4, -4),
          ),
        ],
      ),
      height: height,
      width: width,
      child: child,
    );
  }
}
