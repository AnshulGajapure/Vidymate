import 'package:flutter/cupertino.dart';

Widget MyMenuCard() {
  return Container(
    child: Column(
      children: [
        GestureDetector(
          onTap: () {
            // Navigator.push(context, MaterialPageRoute(builder: (context) {
            //   return ProductDetails();
            // }));
            // Navigator.push(
            //   context,
            //   PageTransition(
            //       child: const ProductDetails(),
            //       type: PageTransitionType.scale,
            //       alignment: Alignment.center),
            // );
          },
          child: SizedBox(
            height: 190,
            child: Image.asset(
              "assets/images/UVHeal3.jpg",
              //fit: BoxFit.cover,
            ),
          ),
        ),
      ],
    ),
  );
}
