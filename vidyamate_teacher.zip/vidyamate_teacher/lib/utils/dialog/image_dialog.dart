// import 'package:flutter/material.dart';

// class ShowImageDialog extends StatefulWidget {
//   const ShowImageDialog({Key? key}) : super(key: key);

//   @override
//   State<ShowImageDialog> createState() => _ShowImageDialogState();
// }

// class _ShowImageDialogState extends State<ShowImageDialog> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//     body: Dialog(
//         child: showGeneralDialog(
//                           context: Get.context!,
//                           barrierDismissible: true,
//                           barrierLabel: MaterialLocalizations.of(context)
//                               .modalBarrierDismissLabel,
//                           barrierColor: Colors.black45,
//                           transitionDuration: const Duration(milliseconds: 200),
//                           pageBuilder: (BuildContext context, Animation animation,
//                               Animation secondaryAnimation) {
//                             return Container(
//                               color: Colors.black45,
//                               child: Column(
//                                 children: [
//                                   Container(
//                                     child: Stack(
//                                       children: [
//                                         Container(
//                                           height:
//                                               MediaQuery.of(context).size.height,
//                                           width:
//                                               MediaQuery.of(context).size.width,
//                                           child: Column(
//                                             mainAxisAlignment:
//                                                 MainAxisAlignment.center,
//                                             children: [
//                                               Container(
//                                                 height: MediaQuery.of(context)
//                                                         .size
//                                                         .height *
//                                                     0.75,
//                                                 width: MediaQuery.of(context)
//                                                     .size
//                                                     .width,
//                                                 child: Image(image: vector2),
//                                               ),
//                                             ],
//                                           ),
//                                         ),
//                                         Positioned(
//                                           top: 80.0,
//                                           child: Container(
//                                             padding: EdgeInsets.only(right: 20.0),
//                                             width:
//                                                 MediaQuery.of(context).size.width,
//                                             child: Row(
//                                               mainAxisAlignment:
//                                                   MainAxisAlignment.spaceBetween,
//                                               children: [
//                                                 SizedBox(width: 5.0),
//                                                 GestureDetector(
//                                                   onTap: () {
//                                                     Get.back();
//                                                   },
//                                                   child: Icon(
//                                                     Icons.cancel_outlined,
//                                                     color: Colors.white,
//                                                     size: 40,
//                                                   ),
//                                                 ),
//                                               ],
//                                             ),
//                                           ),
//                                         ),
//                                       ],
//                                     ),
//                                   ),
//                                 ],
//                               ),
//                             );
//                           });,
//       ),
//     );
//   }
// }
