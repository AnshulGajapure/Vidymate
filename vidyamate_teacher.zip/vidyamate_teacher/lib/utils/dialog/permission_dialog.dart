
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../resources/my_font.dart';

class PermissionDialog extends StatefulWidget {
  String? title;
  String msg;
  Function yesFunction;
  Function noFunction;

  PermissionDialog({
    super.key,
    required this.title,
    required this.msg,
    required this.yesFunction,
    required this.noFunction,
  });

  @override
  State<PermissionDialog> createState() => _PermissionDialogState();
}

class _PermissionDialogState extends State<PermissionDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      elevation: 5.0,
      backgroundColor: Color.fromARGB(255, 230, 239, 255),
      child: dialogContent(context),
    );
  }

  dialogContent(BuildContext context) {
    return SizedBox(
        child: Container(
      // padding:
      //     const EdgeInsets.only(left: 15.0, right: 15, bottom: 15, top: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Column(
            children: <Widget>[
              Container(
                  width: double.infinity,
                  padding: EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                  decoration: BoxDecoration(
                    // color: Colors.red,
                    gradient: LinearGradient(colors: [
                      Color.fromARGB(255, 194, 16, 3),
                      Color.fromARGB(255, 236, 98, 43),
                    ]),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                    ),
                  ),
                  child: CircleAvatar(
                      radius: 25,
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        FontAwesomeIcons.question,
                        color: const Color.fromARGB(255, 54, 120, 244),
                        size: 30,
                      ))),
              const SizedBox(height: 10),
              widget.title != ""
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            widget.title!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color.fromARGB(255, 236, 98, 43),
                              fontSize: 20.0,
                              fontFamily: MyFont.jakartaBold,
                            ),
                          ),
                        )
                      ],
                    )
                  : const SizedBox(height: 10),
              const SizedBox(height: 10),
              widget.msg != ""
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Flexible(
                          child: Text(widget.msg, textAlign: TextAlign.center, style: const TextStyle(color: Color.fromARGB(255, 90, 90, 90), fontSize: 14.0, fontFamily: 'RobotoRegular')),
                        )
                      ],
                    )
                  : SizedBox(),
              const SizedBox(height: 15),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  widget.noFunction();
                },
                child: Container(
                  width: 100.0,
                  height: 35.0,
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(3.0),
                  decoration: ShapeDecoration(
                    shape: StadiumBorder(),
                    // color: Colors.red,
                    gradient: LinearGradient(colors: [
                      Color.fromARGB(255, 177, 177, 177),
                      Color.fromARGB(255, 233, 233, 233),
                    ]),
                    // borderRadius: BorderRadius.only(
                    //   topLeft: Radius.circular(15),
                    //   topRight: Radius.circular(15),
                    // ),
                  ),
                  child: Container(
                    width: 97.0,
                    height: 32.0,
                    padding: const EdgeInsets.all(3.0),
                    alignment: Alignment.center,
                    decoration: const ShapeDecoration(
                      shape: StadiumBorder(),
                      // color: Colors.red,
                      gradient: LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [
                        Color.fromARGB(255, 177, 177, 177),
                        Color.fromARGB(255, 233, 233, 233),
                      ]),
                      // borderRadius: BorderRadius.only(
                      //   topLeft: Radius.circular(15),
                      //   topRight: Radius.circular(15),
                      // ),
                    ),
                    child: Text(
                      "No",
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: MyFont.jakartaMedium,
                        color: Color.fromARGB(255, 194, 16, 3),
                        fontSize: 14.0,

                        //fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  widget.yesFunction();
                },
                child: Container(
                  width: 100.0,
                  height: 35.0,
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(3.0),
                  decoration: ShapeDecoration(
                    shape: StadiumBorder(),
                    // color: Colors.red,
                    gradient: LinearGradient(colors: [
                      Color.fromARGB(255, 194, 16, 3),
                      Color.fromARGB(255, 236, 98, 43),
                    ]),
                    // borderRadius: BorderRadius.only(
                    //   topLeft: Radius.circular(15),
                    //   topRight: Radius.circular(15),
                    // ),
                  ),
                  child: Container(
                    width: 97.0,
                    height: 32.0,
                    padding: const EdgeInsets.all(3.0),
                    alignment: Alignment.center,
                    decoration: const ShapeDecoration(
                      shape: StadiumBorder(),
                      // color: Colors.red,
                      gradient: LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [Color.fromARGB(255, 194, 16, 3), Color.fromARGB(255, 233, 23, 8)]),
                      // borderRadius: BorderRadius.only(
                      //   topLeft: Radius.circular(15),
                      //   topRight: Radius.circular(15),
                      // ),
                    ),
                    child: Text(
                      "Yes",
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: MyFont.jakartaMedium,
                        color: Colors.white,
                        fontSize: 14.0,

                        //fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
        ],
      ),
    ));
  }
}
