
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import '../../resources/my_font.dart';

class OnSuccessDialog extends StatefulWidget {
  String? title;
  String? descriptions;
  AssetImage img;
  VoidCallback onTap;

  OnSuccessDialog({Key? key, required this.title, required this.descriptions, required this.img, required this.onTap}) : super(key: key);

  @override
  _OnSuccessDialogState createState() => _OnSuccessDialogState();
}

class _OnSuccessDialogState extends State<OnSuccessDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(15.0))),
      elevation: 20.0,
      backgroundColor: const Color.fromARGB(255, 236, 243, 255),
      child: dialogContent(context),
    );
  }

  dialogContent(BuildContext context) {
    return SizedBox(
        child: Container(
      // padding:
      //     const EdgeInsets.only(left: 15.0, right: 15, bottom: 15, top: 10),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: <Widget>[
          Column(
            children: <Widget>[
              Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(0.0, 10.0, 0.0, 10.0),
                  decoration: const BoxDecoration(
                    // color: Colors.red,
                    gradient: LinearGradient(colors: [
                      Color.fromARGB(255, 22, 141, 6),
                      Color.fromARGB(255, 81, 190, 18),
                    ]),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(15),
                      topRight: Radius.circular(15),
                    ),
                  ),
                  child: CircleAvatar(
                      radius: 25,
                      backgroundColor: Colors.grey.shade200,
                      child: Icon(
                        FontAwesomeIcons.check,
                        color: const Color.fromARGB(255, 54, 120, 244),
                        size: 30,
                      ))),
              const SizedBox(height: 10),
              widget.title != ""
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Flexible(
                          child: Text(
                            widget.title!,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              color: Color.fromARGB(255, 27, 150, 34),
                              fontSize: 20.0,
                              fontFamily: MyFont.jakartaBold,
                            ),
                          ),
                        )
                      ],
                    )
                  : const SizedBox(height: 10),
              const SizedBox(height: 10),
              widget.descriptions != ""
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Flexible(
                          child: Text(widget.descriptions!, textAlign: TextAlign.center, style: const TextStyle(color: Color.fromARGB(255, 90, 90, 90), fontSize: 14.0, fontFamily: 'RobotoRegular')),
                        )
                      ],
                    )
                  : SizedBox(),
              const SizedBox(height: 15),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: widget.onTap,
                child: Container(
                  width: 100.0,
                  height: 35.0,
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(3.0),
                  decoration: ShapeDecoration(
                    shape: StadiumBorder(),
                    // color: Colors.red,
                    gradient: LinearGradient(colors: [
                      Color.fromARGB(255, 22, 141, 6),
                      Color.fromARGB(255, 81, 190, 18),
                    ]),
                    // borderRadius: BorderRadius.only(
                    //   topLeft: Radius.circular(15),
                    //   topRight: Radius.circular(15),
                    // ),
                  ),
                  child: Container(
                    width: 97.0,
                    height: 32.0,
                    padding: const EdgeInsets.all(3.0),
                    alignment: Alignment.center,
                    decoration: const ShapeDecoration(
                      shape: StadiumBorder(),
                      // color: Colors.red,
                      gradient: LinearGradient(begin: Alignment.centerRight, end: Alignment.centerLeft, colors: [
                        Color.fromARGB(255, 28, 163, 10),
                        Color.fromARGB(255, 81, 190, 18),
                      ]),
                      // borderRadius: BorderRadius.only(
                      //   topLeft: Radius.circular(15),
                      //   topRight: Radius.circular(15),
                      // ),
                    ),
                    child: Text(
                      "OK",
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontFamily: MyFont.jakartaMedium,
                        color: Colors.white,
                        fontSize: 14.0,

                        //fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 15),
        ],
      ),
    ));
  }
}
