import 'package:fluttertoast/fluttertoast.dart';

import '../../resources/my_colors.dart';
import '../../resources/my_font.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomProgressDialog {
  bool _dialogIsOpen = false;

  showProgressDialog({
    bool barrierDismissible = false,
  }) {
    _dialogIsOpen = true;
    return showDialog(
        barrierDismissible: barrierDismissible,
        barrierColor: Colors.black38,
        context: Get.context!,
        builder: (context) {
          return WillPopScope(
              onWillPop: () {
                if (barrierDismissible) {
                  _dialogIsOpen = false;
                }
                return Future.value(barrierDismissible);
              },
              child: ProgressDialogWidget());
        });
  }

  void close() {
    if (_dialogIsOpen) {
      Get.back();
      _dialogIsOpen = false;
    }
  }
}

class ProgressDialogWidget extends StatefulWidget {
  const ProgressDialogWidget({super.key});

  @override
  State<ProgressDialogWidget> createState() => _ProgressDialogWidgetState();
}

class _ProgressDialogWidgetState extends State<ProgressDialogWidget> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  bool _isFlipped = false;

  @override
  void initState() {
    _controller = AnimationController(vsync: this, duration: Duration(milliseconds: 600));
    _animation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOut,
    ));

    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        _controller.reverse();
        setState(() {
          _isFlipped = !_isFlipped;
        });
      } else if (status == AnimationStatus.dismissed) {
        _controller.forward();
        setState(() {
          _isFlipped = !_isFlipped;
        });
      }
    });
    _controller.forward();
    // TODO: implement initState
    super.initState();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.of(context).size.height;
    var width = MediaQuery.of(context).size.width;

    /*return Container(
      color: Colors.black38,
      height: MediaQuery.of(context).size.height,
      child: Dialog(
        insetPadding: EdgeInsets.all(90),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        elevation: 0.0,
        backgroundColor: Colors.transparent,
        child: animatedDialogContent(context),
      ),
    );*/

    return Center(
      child: AnimatedBuilder(
        animation: _animation,
        builder: (context, child) {
          final value = _animation.value;

          return Transform(
            transform: Matrix4.identity()
              ..setEntry(3, 2, 0.001)
              ..rotateY(_isFlipped ? -value * 3.141592 : value * 3.141592),
            alignment: Alignment.center,
            child: child,
          );
        },
        child: Container(
          width: 100.0,
          height: 100.0,
          // color: Colors.blue,
          child: Center(child: Image.asset('assets/images/logo.png')),
        ),
      ),
    );

    /*return AlertDialog(
      elevation: 0,
      backgroundColor: Colors.transparent,
      content: animatedDialogContent(context)
    );*/
  }

  ///*
  ///
  ///
  dialogContent(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          DefaultTextStyle(
            style: const TextStyle(fontSize: 30.0, fontFamily: MyFont.jakartaBold, color: MyColor.primaryColor),
            child: Text("sgherhrth"),
          )
        ],
      ),
    );
  }

  ///
  ///
  ///
  animatedDialogContent(BuildContext context) {
    return AnimatedBuilder(
      animation: _animation,
      builder: (context, child) {
        final value = _animation.value;

        return Transform(
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateY(_isFlipped ? -value * 3.141592 : value * 3.141592),
          alignment: Alignment.center,
          child: child,
        );
      },
      child: Container(
        width: 70.0,
        height: 70.0,
        // color: Colors.blue,
        child: Center(child: Image.asset('assets/images/appLogo.png')),
      ),
    );

    // return Image(
    //   // image: greenBgLoader,
    //   image: appLogo,
    //   // height: 170.0,
    // );
    /*ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Image(
        // image: greenBgLoader,
        image: progressLoader,
        // height: 170.0,
      ),
    );*/
  }

}
