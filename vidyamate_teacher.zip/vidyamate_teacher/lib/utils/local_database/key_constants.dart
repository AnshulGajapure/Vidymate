class KeyConstants {
  static String otp = "otp";
  static String userDetails = 'userDetails';
  static String isLogin = 'is_login';
}
