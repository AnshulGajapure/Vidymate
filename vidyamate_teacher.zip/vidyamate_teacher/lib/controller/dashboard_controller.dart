import 'dart:convert';
import 'dart:developer';

import 'package:get/get.dart';

import '../model/academic_model.dart';
import '../model/class_Section_Model.dart';
import '../model/dashboard_model.dart';
import '../model/teacher_data_model.dart';
import '../network/api_client.dart';
import '../network/api_constant.dart';
import '../utils/local_database/key_constants.dart';
import '../utils/local_database/shdf.dart';

class DashboardController extends GetxController {
  List<String> session = [];
  List<Circulars> circulrsList = [];
  TeacherDataModel? teacherData;
  AcademicSessionModel? academicSessionList;
  ClassAndSectionModel? classAndSectionList;
  String? selectedAcademicSessionId;
  String? selectedSessionId;
  String? selectedFkClassId;
  String? selectedSectionID;
  String? selectedWeekDay = "Monday";

  //================================= Get Session API ==============================================
  getAcademicSession(ctx) async {
    String? userDetailsJson =
        await SHDFClass.readStringValue(KeyConstants.userDetails, '');

    if (userDetailsJson != null && userDetailsJson.isNotEmpty) {
      teacherData = TeacherDataModel.fromJson(jsonDecode(userDetailsJson));
    } else {
      log("No user details found");
      return;
    }

    var data = {
      "organization_id": teacherData!.tempDict!.userDetail!.organizationId
    };

    log("RequestData :${teacherData!.tempDict!.userDetail!.organizationId}");

    final results = await ApiClient().requestPostWithauth(
        url: ApiConstant.getAcademicYearList,
        parameters: json.encode(data),
        accessToken: teacherData!.tempDict!.token,
        context: ctx);

    if (results != null) {
      academicSessionList = AcademicSessionModel.fromJson(results);
      if (academicSessionList!.status == 200) {
        session =
            academicSessionList!.payload?.map((e) => e.name ?? '').toList() ??
                [];

        if (academicSessionList!.payload != null &&
            academicSessionList!.payload!.isNotEmpty) {
          // Set the selected session ID after fetching the session list
          selectedSessionId = academicSessionList!.payload![0].id.toString();
          selectedAcademicSessionId = academicSessionList!.payload![0].name;
          print("selectedSessionId  --> $selectedSessionId");
          await getClassAndSection(ctx);
        }

        update();
      }
    }
  }

  //================================= Get Class and Section API =============================================
  getClassAndSection(ctx) async {
    if (selectedSessionId == null) {
      log("Selected session ID is null. Cannot proceed with getClassAndSection.");
      return;
    }

    String? userDetailsJson =
        await SHDFClass.readStringValue(KeyConstants.userDetails, '');

    if (userDetailsJson != null && userDetailsJson.isNotEmpty) {
      teacherData = TeacherDataModel.fromJson(jsonDecode(userDetailsJson));
    } else {
      log("No user details found");
      return;
    }

    var data = {
      "school_id": teacherData!.tempDict!.userDetail!.fkSchoolId,
      "acedamic_id": selectedSessionId,
      "user_id": teacherData!.tempDict!.userDetail!.staffId
    };

    log("RequestData :${teacherData!.tempDict!.userDetail!.organizationId}");

    final results = await ApiClient().requestPostWithauth(
        url: ApiConstant.getClassAndSection,
        parameters: json.encode(data),
        accessToken: teacherData!.tempDict!.token,
        context: ctx);

    if (results != null) {
      classAndSectionList = ClassAndSectionModel.fromJson(results);
      if (classAndSectionList!.status == 200) {
        selectedFkClassId =
            classAndSectionList!.payload![0].fkClassId.toString();
        selectedSectionID = classAndSectionList!.payload![0].id.toString();
        print("classAndSectionList  -->$classAndSectionList");
        await getDashboardApi2(ctx);
        update();
      }
    }
  }

  //================================= Get Dashboard API 2 =============================================
  getDashboardApi(ctx) async {
    if (selectedSessionId == null) {
      log("Selected session ID is null. Cannot proceed with getDashboardApi2.");
      return;
    }

    String? userDetailsJson =
        await SHDFClass.readStringValue(KeyConstants.userDetails, '');

    if (userDetailsJson != null && userDetailsJson.isNotEmpty) {
      teacherData = TeacherDataModel.fromJson(jsonDecode(userDetailsJson));
    } else {
      log("No user details found");
      return;
    }

    var data = {
      "school_id": teacherData!.tempDict!.userDetail!.fkSchoolId,
      "academic_id": selectedSessionId,
      "class_id": selectedFkClassId,
      "section_id": selectedSectionID,
      "staff_id": teacherData!.tempDict!.userDetail!.staffId,
      "day": selectedWeekDay,
      "user_type": "Teacher"
    };

    log("RequestData :${teacherData!.tempDict!.userDetail!.organizationId}");

    final results = await ApiClient().requestPostWithauth(
        url: ApiConstant.dashboard_Api2,
        parameters: json.encode(data),
        accessToken: teacherData!.tempDict!.token,
        context: ctx);

    if (results != null) {
      DashboardApi2Model dashboardData2 = DashboardApi2Model.fromJson(results);
      if (dashboardData2.status == 200) {
        circulrsList = dashboardData2.payload!.circulars!;
        print("dashboardData2 ==> ${circulrsList}");
        update();
      }
    }
  }

  //================================= Get Dashboard API 2 =============================================
  getDashboardApi2(ctx) async {
    if (selectedSessionId == null) {
      log("Selected session ID is null. Cannot proceed with getDashboardApi2.");
      return;
    }

    String? userDetailsJson =
        await SHDFClass.readStringValue(KeyConstants.userDetails, '');

    if (userDetailsJson != null && userDetailsJson.isNotEmpty) {
      teacherData = TeacherDataModel.fromJson(jsonDecode(userDetailsJson));
    } else {
      log("No user details found");
      return;
    }

    var data = {
      "school_id": teacherData!.tempDict!.userDetail!.fkSchoolId,
      "academic_id": selectedSessionId,
      "class_id": selectedFkClassId,
      "section_id": selectedSectionID,
      "staff_id": teacherData!.tempDict!.userDetail!.staffId,
      "day": selectedWeekDay,
      "user_type": "Teacher"
    };

    log("RequestData :${teacherData!.tempDict!.userDetail!.organizationId}");

    final results = await ApiClient().requestPostWithauth(
        url: ApiConstant.dashboard_Api2,
        parameters: json.encode(data),
        accessToken: teacherData!.tempDict!.token,
        context: ctx);

    if (results != null) {
      DashboardApi2Model dashboardData2 = DashboardApi2Model.fromJson(results);
      if (dashboardData2.status == 200) {
        circulrsList = dashboardData2.payload!.circulars!;
        print("dashboardData2 ==> ${circulrsList}");
        update();
      }
    }
  }
}
