import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vidyamate_teacher/view/screen/Dashboard.dart';

import '../model/loginModel.dart';
import '../model/teacher_data_model.dart';
import '../network/api_client.dart';
import '../network/api_constant.dart';
import '../resources/my_assets.dart';
import '../utils/dialog/ok_dialog.dart';
import '../utils/local_database/key_constants.dart';
import '../utils/local_database/shdf.dart';
import '../utils/widgets/toast_widget.dart';
import '../view/auth/verify_otp_view.dart';

class LoginController extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }

  TeacherLoginOTP? teacherLoginOTPModel;
  TeacherDataModel? teacherData;

// ========================   User Login    ==============================================
  loginUser(BuildContext ctx, String techerCode) async {
    var data = {"mobile_no": techerCode};

    log("RequestData :${techerCode}");
    final results = await ApiClient().requestPost(
        url: ApiConstant.sendotp, parameters: json.encode(data), context: ctx);
    if (results != null) {
      teacherLoginOTPModel = TeacherLoginOTP.fromJson(results);
      if (teacherLoginOTPModel!.status == 200) {
        await SHDFClass.saveStringValue(
            KeyConstants.otp, teacherLoginOTPModel!.otp!.toString());
        Get.to(() => VerifyOtpScreen(
            teacherLoginOTPModel!.schoolStatfId.toString(),
            teacherLoginOTPModel!.staffId.toString(),
            techerCode));

        ToastWidget.showToast(
          context: ctx,
          msg: "${teacherLoginOTPModel!.msg}",
        );
      } else {
        showDialog(
            context: Get.context!,
            builder: (BuildContext context1) => OKDialog(
                  title: "",
                  descriptions: teacherLoginOTPModel!.msg,
                  img: errorIcon,
                ));
      }
    }
  }

  // ========================   Verify OTP   ==============================================
  afterOtpVerify(ctx) async {
    var data = {
      "school_statf_id": teacherLoginOTPModel!.schoolStatfId.toString(),
      "staff_id": teacherLoginOTPModel!.staffId.toString()
    };

    // log("RequestData :${}");
    final results = await ApiClient().requestPost(
        url: ApiConstant.tescherLogin,
        parameters: json.encode(data),
        context: ctx);

    await SHDFClass.saveStringValue(
        KeyConstants.userDetails, jsonEncode(teacherData!.toJson()));
    Get.offAll(() => Dashboard(teacherData!));
    await SHDFClass.saveBooleanValue(KeyConstants.isLogin, true);
    // ToastWidget.showToast(
    //   context: BuildContext,
    //   msg: "${responseModel.msg}",
    // );
  }

  // ========================   User Login    ==============================================
  resend(BuildContext ctx, String techerCode) async {
    var data = {"mobile_no": techerCode};
    log("RequestData :${techerCode}");
    final results = await ApiClient().requestPost(
        url: ApiConstant.sendotp, parameters: json.encode(data), context: ctx);
    if (results != null) {
      teacherLoginOTPModel = TeacherLoginOTP.fromJson(results);
      if (teacherLoginOTPModel!.status == 200) {
        await SHDFClass.saveStringValue(
            KeyConstants.otp, teacherLoginOTPModel!.otp!.toString());
        ToastWidget.showToast(
          context: ctx,
          msg: "${teacherLoginOTPModel!.msg}",
        );
      } else {
        showDialog(
            context: Get.context!,
            builder: (BuildContext context1) => OKDialog(
                  title: "",
                  descriptions: teacherLoginOTPModel!.msg,
                  img: errorIcon,
                ));
      }
    }
  }
}
