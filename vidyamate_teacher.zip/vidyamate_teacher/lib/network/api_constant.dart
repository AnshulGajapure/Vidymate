class ApiConstant {
  static String baseUrl =
      "http://3.109.124.47:8000/api/"; //Developement server path
  static String baseUrl2 =
      "http://3.109.124.47:8000/"; //Developement server path
  // static String baseUrl = "https://api.vidyamate.in/api/"; //prod server path

  static String sendotp = baseUrl + "send_teacher_login_otp/";
  static String tescherLogin = baseUrl + "teacher_login_api/";
  static String getNotificationData = baseUrl + "get_StaffNotification/";
  static String getAcademicYearList = baseUrl + "get_academic_session/";
  static String dashboard_Api2 = baseUrl2 + "Dashboard_Api2/";
  static String getClassAndSection = baseUrl2 + "get_class_and_section/";
}
