import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../resources/my_assets.dart';
import '../resources/my_string.dart';
import '../utils/dialog/circular_progress_dialog.dart';
import '../utils/dialog/ok_dialog.dart';
import '../utils/my_internet_connection.dart';

class ApiClient {
  CircularProgressDialog progressDialog = CircularProgressDialog();

  //CustomProgressDialog progressDialog = CustomProgressDialog();
  //CustomProgressDialog progressDialog = CustomProgressDialog();

  Future<Map?> requestGet({required String url, context}) async {
    progressDialog.showProgressDialog(context: context);

    log("API : $url");
    bool flagNet = await MyInternetConnection().isInternetAvailable();

    if (flagNet) {
      try {
        Uri uri = Uri.parse(url);

        final results = await http.get(
          uri,
          headers: {"Content-Type": "application/json"},
        );
        //print(results);

        if (results.statusCode == 200 || results.statusCode == 401) {
          final jsonObject = json.decode(results.body);
          log("RequestData : ${jsonObject.toString()}");
          //debugPrint(jsonObject, wrapWidth: 2000);

          progressDialog.close();
          return jsonObject;
        } else {
          progressDialog.close();
          log("Request API : null ");

          showDialog(
            context: Get.context!,
            builder: (BuildContext context1) => OKDialog(
              title: "Alert",
              descriptions: MyString.errorMessage,
              img: errorIcon,
            ),
          );
          return null;
        }
      } catch (exception) {
        log("Request API Exception: $exception.toString()");
        progressDialog.close();
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Alert",
            descriptions: MyString.errorMessage,
            img: errorIcon,
          ),
        );
        return null;
      }
    } else {
      progressDialog.close();
      log("Request API : No Internet ");

      showDialog(
        context: Get.context!,
        builder: (BuildContext context1) => OKDialog(
          title: "No Internet",
          descriptions: "Please check Internet Connection",
          img: noInternetIcon,
        ),
      );
      return null;
    }
  }

  ///
  ///
  ///
  Future<Map<String, dynamic>?> requestPost(
      {required String url,
      required String parameters,
      String? accessToken,
      context}) async {
    progressDialog.showProgressDialog(context: context);

    log("API : $url");
    log("RequestData : ${parameters.toString()}");
    // log("accessToken : $accessToken");
    bool flagNet = await MyInternetConnection().isInternetAvailable();

    if (flagNet) {
      // try {
      Uri uri = Uri.parse(url);

      final results = await http.post(
        uri,
        body: parameters,
        headers: {
          "Content-Type": "application/json",
        },
      );
      //print(results);

      if (results.statusCode == 200) {
        final jsonObject = json.decode(results.body);
        log("ResponseData : ${results.body.toString()}");
        //debugPrint(jsonObject, wrapWidth: 2000);

        progressDialog.close();
        return jsonObject;
      } else {
        progressDialog.close();
        log("${results.body}  ");
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Failed",
            descriptions: MyString.errorMessage,
            img: errorIcon,
          ),
        );
        return null;
      }
      // } catch (exception) {
      //   log("Request API Exception: $exception.toString()");
      //   progressDialog.close();
      //   showDialog(
      //     context: Get.context!,
      //     builder: (BuildContext context1) => OKDialog(
      //       title: "Failed",
      //       descriptions: "MyString.errorMessage",
      //       img: errorIcon,
      //     ),
      //   );
      //   return null;
      // }
    } else {
      progressDialog.close();
      log("Request API : No Internet ");

      showDialog(
        context: Get.context!,
        builder: (BuildContext context1) => OKDialog(
          title: "No Internet",
          descriptions: "Please check Internet Connection",
          img: noInternetIcon,
        ),
      );
      return null;
    }
  }

  Future<Map<String, dynamic>?> requestPost2(
      {required String url,
      required String parameters,
      String? accessToken,
      context}) async {
    progressDialog.showProgressDialog(context: context);

    log("API : $url");
    log("RequestData : ${parameters.toString()}");
    // log("accessToken : $accessToken");
    bool flagNet = await MyInternetConnection().isInternetAvailable();

    if (flagNet) {
      // try {
      Uri uri = Uri.parse(url);

      final results = await http.post(
        uri,
        body: parameters,
        headers: {"Content-Type": "application/json"},
      );
      // print("resultsssssssssssssssssssssssssss ${results.statusCode}");

      if (results.statusCode == 201) {
        final jsonObject = json.decode(results.body);
        log("ResponseData : ${results.body.toString()}");
        //debugPrint(jsonObject, wrapWidth: 2000);

        progressDialog.close();
        return jsonObject;
      } else {
        progressDialog.close();
        log("${results.body}  ");
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Failed",
            descriptions: MyString.errorMessage,
            img: errorIcon,
          ),
        );
        return null;
      }
      // } catch (exception) {
      //   log("Request API Exception: $exception.toString()");
      //   progressDialog.close();
      //   showDialog(
      //     context: Get.context!,
      //     builder: (BuildContext context1) => OKDialog(
      //       title: "Failed",
      //       descriptions: "MyString.errorMessage",
      //       img: errorIcon,
      //     ),
      //   );
      //   return null;
      // }
    } else {
      progressDialog.close();
      log("Request API : No Internet ");

      showDialog(
        context: Get.context!,
        builder: (BuildContext context1) => OKDialog(
          title: "No Internet",
          descriptions: "Please check Internet Connection",
          img: noInternetIcon,
        ),
      );
      return null;
    }
  }

  ///
  ///
  ///
  Future<Map<String, dynamic>?> requestPostWithauth(
      {required String url,
      required String parameters,
      String? accessToken,
      context}) async {
    try {
      progressDialog.showProgressDialog(context: context);
      log("API :: ${url.toString()}");
      log("request :: ${parameters.toString()}");
      // debugPrint(parameters);
      // debugPrint(parameters, wrapWidth: 2000);

      bool flagNet = await MyInternetConnection().isInternetAvailable();
      if (flagNet!) {
        // String url1 = url.toString();
        Uri uri = Uri.parse(url);

        final results = await http.post(uri, body: parameters, headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $accessToken"
        });
        log("responseBody :: ${results.body}");

        if (results.statusCode == 200 ||
            results.statusCode == 401 ||
            results.statusCode == 403) {
          final jsonObject = json.decode(results.body);
          // print(jsonObject);
          //debugPrint(jsonObject, wrapWidth: 2000);

          progressDialog.close();
          if (jsonObject['code'] == 'token_not_valid') {
            // SharedPreferences preferences = await SharedPreferences.getInstance();
            // FirebaseAuth.instance.signOut();
            // DatabaseHelper.clearAllTables();
            // await preferences.reload();
            // HiveDB.clearAll();
            // Navigator.pushAndRemoveUntil(context, FadeRoute(page: LoginScreen(from: 'forgot')), (route) => false);
            return {};
          } else if (jsonObject['code'] == 'bad_authorization_header') {
            // SharedPreferences preferences = await SharedPreferences.getInstance();
            // FirebaseAuth.instance.signOut();
            // DatabaseHelper.clearAllTables();
            // await preferences.reload();
            // HiveDB.clearAll();
            // Navigator.pushAndRemoveUntil(context, FadeRoute(page: LoginScreen(from: 'forgot')), (route) => false);
            return {};
          }
          return jsonObject;
        } else {
          progressDialog.close();

          return null;
        }
      } else {
        progressDialog.close();
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Error!",
            descriptions: "Please check your internet connection!",
            img: noInternetIcon,
          ),
        );

        return null;
      }
    } catch (e) {
      progressDialog.close();
      print("eeeee " + e.toString());
    }
  }

  ///
  ///
  ///
  Future<Map<String, dynamic>?> requestPostNoLoader(
      {required String url,
      required String parameters,
      String? accessToken,
      context}) async {
    // progressDialog.showProgressDialog(context: context);

    log("API : $url");
    log("RequestData : ${parameters.toString()}");
    // log("accessToken : $accessToken");
    bool flagNet = await MyInternetConnection().isInternetAvailable();

    if (flagNet) {
      try {
        Uri uri = Uri.parse(url);

        final results = await http.post(
          uri,
          body: parameters,
          headers: {"Content-Type": "application/json"},
        );
        //print(results);

        if (results.statusCode == 200 || results.statusCode == 401) {
          final jsonObject = json.decode(results.body);
          log("ResponseData : ${results.body.toString()}");
          //debugPrint(jsonObject, wrapWidth: 2000);

          // progressDialog.close();
          return jsonObject;
        } else {
          // progressDialog.close();
          log("Request API : null ");

          showDialog(
            context: Get.context!,
            builder: (BuildContext context1) => OKDialog(
              title: "Failed",
              descriptions: MyString.errorMessage,
              img: errorIcon,
            ),
          );
          return null;
        }
      } catch (exception) {
        log("Request API Exception: $exception.toString()");
        // progressDialog.close();
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Failed",
            descriptions: MyString.errorMessage,
            img: errorIcon,
          ),
        );
        return null;
      }
    } else {
      // progressDialog.close();
      log("Request API : No Internet ");

      showDialog(
        context: Get.context!,
        builder: (BuildContext context1) => OKDialog(
          title: "No Internet",
          descriptions: "Please check Internet Connection",
          img: noInternetIcon,
        ),
      );
      return null;
    }
  }

  ///
  ///
  ///
  Future<Map<String, dynamic>?> requestAddUserMultipart(
      {required String url,
      required Map<String, dynamic> parameters,
      context}) async {
    progressDialog.showProgressDialog(context: context);

    log("API : $url");
    bool flagNet = await MyInternetConnection().isInternetAvailable();

    if (flagNet) {
      try {
        final request = http.MultipartRequest("POST", Uri.parse(url));
        request.headers.addAll({"Content-Type": "multipart/form-data"});
        request.fields['main_user_id'] = parameters['main_user_id'];
        request.fields['user_name'] = parameters['user_name'];
        if (parameters['profile_image'] != null &&
            parameters['profile_image'].toString().isNotEmpty) {
          request.files.add(await http.MultipartFile.fromPath(
              "profile_image", parameters['profile_image']));
        }

        final response = await request.send();
        final responseStream = await response.stream.toBytes();
        final responseString = String.fromCharCodes(responseStream);

        final results = jsonDecode(responseString);

        if (results != null) {
          print(jsonEncode(results));
          print("done");
          progressDialog.close();
          return results;
        } else {
          print("else2");
          progressDialog.close();
          return null;
        }
      } catch (exception) {
        log("Request API Exception: $exception.toString()");
        progressDialog.close();
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Failed",
            descriptions: MyString.errorMessage,
            img: errorIcon,
          ),
        );
        return null;
      }
    } else {
      progressDialog.close();
      log("Request API: No Internet");
      showDialog(
        context: Get.context!,
        builder: (BuildContext context1) => OKDialog(
          title: "No Internet",
          descriptions: "Please check Internet Connection",
          img: noInternetIcon,
        ),
      );
      return null;
    }
  }

  ///
  ///
  ///
  Future<Map<String, dynamic>?> requestUpdateUserMultipart(
      {required String url,
      required Map<String, dynamic> parameters,
      context}) async {
    progressDialog.showProgressDialog(context: context);

    log("API : $url");
    bool flagNet = await MyInternetConnection().isInternetAvailable();

    if (flagNet) {
      try {
        final request = http.MultipartRequest("POST", Uri.parse(url));
        request.headers.addAll({"Content-Type": "multipart/form-data"});
        request.fields['sub_user_id'] = parameters['sub_user_id'];
        request.fields['user_name'] = parameters['user_name'];
        if (parameters['profile_image'] != null &&
            parameters['profile_image'].toString().isNotEmpty) {
          request.files.add(await http.MultipartFile.fromPath(
              "profile_image", parameters['profile_image']));
        }

        final response = await request.send();
        final responseStream = await response.stream.toBytes();
        final responseString = String.fromCharCodes(responseStream);

        final results = jsonDecode(responseString);

        if (results != null) {
          print(jsonEncode(results));
          print("done");
          progressDialog.close();
          return results;
        } else {
          print("else2");
          progressDialog.close();
          return null;
        }
      } catch (exception) {
        log("Request API Exception: $exception.toString()");
        progressDialog.close();
        showDialog(
          context: Get.context!,
          builder: (BuildContext context1) => OKDialog(
            title: "Failed",
            descriptions: MyString.errorMessage,
            img: errorIcon,
          ),
        );
        return null;
      }
    } else {
      progressDialog.close();
      log("Request API: No Internet");
      showDialog(
        context: Get.context!,
        builder: (BuildContext context1) => OKDialog(
          title: "No Internet",
          descriptions: "Please check Internet Connection",
          img: noInternetIcon,
        ),
      );
      return null;
    }
  }
}
