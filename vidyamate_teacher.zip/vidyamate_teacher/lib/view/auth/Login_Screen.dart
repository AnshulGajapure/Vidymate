import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vidyamate_teacher/controller/login_controller.dart';
import 'package:vidyamate_teacher/utils/widgets/my_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final LoginController loginController = Get.put(LoginController());
  final TextEditingController teacherCodeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.57,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment(0.00, -1.00),
                    end: Alignment(0, 1),
                    colors: [Color(0xFFAADBFF), Color(0x77EDC7FF)],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image.asset(
                      'assets/images/logo.png',
                      height: MediaQuery.of(context).size.height * 0.23,
                    ),
                    const Text(
                      'WELCOME',
                      style: TextStyle(
                        color: Color(0xFF26252F),
                        fontSize: 30,
                        fontFamily: 'LexendBold',
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.03),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: MediaQuery.of(context).size.width > 600
                      ? MediaQuery.of(context).size.width * 0.35
                      : 20,
                ),
                child: Form(
                  key: _formKey, // Form key to handle validation
                  child: Column(
                    children: [
                      const Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Login as a Teacher',
                          style: TextStyle(
                            color: Color(0xFF26252F),
                            fontSize: 18,
                            fontFamily: 'LexendSemiBold',
                          ),
                        ),
                      ),
                      SizedBox(
                          height: MediaQuery.of(context).size.height * 0.05),
                      const Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Get started using teacher code',
                          style: TextStyle(
                            color: Color(0xFF26252F),
                            fontSize: 16,
                            fontFamily: 'LexendMedium',
                          ),
                        ),
                      ),
                      const SizedBox(height: 10.0),
                      TextFormField(
                        controller: teacherCodeController,
                        autofocus: false,
                        style: TextStyle(fontFamily: 'LexendRegular'),
                        cursorColor: Colors.black,
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 16.0),
                          hintText: "Please enter your teacher code",
                          hintStyle: TextStyle(
                            fontSize: 12,
                            color: Color.fromARGB(255, 196, 196, 196),
                            fontFamily: 'LexendRegular',
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(13.0)),
                            borderSide: BorderSide(
                              color: Color.fromARGB(255, 184, 184, 184),
                              width: 0.0,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(13.0)),
                          ),
                        ),
                        // Add validation logic
                        // validator: (value) {
                        //   if (value == null || value.isEmpty) {
                        //     return 'Please enter your teacher code';
                        //   }
                        //   // if (value.length < 6) {
                        //   //   return 'Teacher code must be at least 6 characters';
                        //   // }
                        //   return null; // If validation passes
                        // },
                      ),
                      const SizedBox(height: 15.0),
                      SizedBox(
                          height: MediaQuery.of(context).size.height * 0.04),
                      CustomButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            loginController.loginUser(
                                context, teacherCodeController.text);
                          }
                        },
                        buttonText: "Get OTP",
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
