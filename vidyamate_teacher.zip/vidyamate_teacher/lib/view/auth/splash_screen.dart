import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vidyamate_teacher/model/teacher_data_model.dart';
import 'package:vidyamate_teacher/resources/my_assets.dart';
import 'package:vidyamate_teacher/view/screen/Dashboard.dart';

import '../../utils/local_database/key_constants.dart';
import '../../utils/local_database/shdf.dart';
import 'Login_Screen.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    handleSession();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image(
                image: appLogo,
                height: MediaQuery.of(context).size.height * 0.18),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  handleSession() async {
    bool? userdata = false;
    TeacherDataModel? payload;
    try {
      userdata =
          await SHDFClass.readBooleanValue(KeyConstants.isLogin, '') ?? false;

      if (userdata == true) {
        // Retrieve and log the stored user details
        String? userDetailsString =
            await SHDFClass.readStringValue(KeyConstants.userDetails, '');
        log("Retrieved userDetails: $userDetailsString");

        if (userDetailsString != null && userDetailsString.isNotEmpty) {
          try {
            Map<String, dynamic> userMap = jsonDecode(userDetailsString);
            payload = TeacherDataModel.fromJson(userMap);
          } catch (e) {
            log("Error decoding JSON: $e");
          }
        }
      }

      log("userdata. $userdata");
    } catch (e) {
      log(e.toString());
    }

    Future.delayed(const Duration(milliseconds: 1800), () async {
      if (userdata == null) {
        log("userdata-null $userdata");
        Get.off(
          () => LoginScreen(),
          duration: Duration(milliseconds: 1800),
          transition: Transition.fadeIn,
        );
      } else {
        log("Home $userdata");

        if (userdata == true && payload != null) {
          // Pass Payload data to HomePageView
          Get.offAll(
            () => Dashboard(payload!), // Pass payload here
            duration: const Duration(milliseconds: 1800),
            transition: Transition.downToUp,
          );
        } else {
          log("userdata-false $userdata");
          Get.offAll(
            () => LoginScreen(),
            duration: const Duration(milliseconds: 1800),
            transition: Transition.fadeIn,
          );
        }
      }
    });
  }
}
