import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vidyamate_teacher/resources/my_assets.dart';
import 'package:vidyamate_teacher/utils/widgets/my_button.dart';

import '../../controller/login_controller.dart';
import '../../utils/local_database/key_constants.dart';
import '../../utils/local_database/shdf.dart';
import '../../utils/widgets/toast_widget.dart';

class VerifyOtpScreen extends StatefulWidget {
  final String? schoolStatfId;
  final String? staffId;
  final String? techerCode;

  VerifyOtpScreen(this.schoolStatfId, this.staffId, this.techerCode);

  @override
  _VerifyOtpScreenState createState() => _VerifyOtpScreenState();
}

class _VerifyOtpScreenState extends State<VerifyOtpScreen> {
  final _formKey = GlobalKey<FormState>();
  final LoginController loginController = Get.put(LoginController());
  final TextEditingController oTPController = TextEditingController();

  @override
  void dispose() {
    oTPController.dispose();
    super.dispose();
  }

  Future<void> verifyOTP(ctx, String otpCode) async {
    String? storedOtp = await SHDFClass.readStringValue(KeyConstants.otp, '');
    print("$storedOtp == $otpCode");
    if (storedOtp.toString() == otpCode.toString()) {
      loginController.afterOtpVerify(ctx);
    } else if (storedOtp.toString() == "") {
      ToastWidget.showToast(
        context: ctx,
        msg: "OTP Expired",
      );
    } else {
      ToastWidget.showToast(
        context: ctx,
        msg: "Incorrect OTP",
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                height: MediaQuery.of(context).size.height * 0.57,
                width: MediaQuery.of(context).size.width,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment(0.00, -1.00),
                    end: Alignment(0, 1),
                    colors: [Color(0xFFAADBFF), Color(0x77EDC7FF)],
                  ),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image(
                      height: MediaQuery.of(context).size.height * 0.38,
                      image: unlock,
                    ),
                  ],
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.03),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: MediaQuery.of(context).size.width > 600
                      ? MediaQuery.of(context).size.width * 0.35
                      : 20,
                ),
                child: Form(
                  key: _formKey, // Form key to handle validation
                  child: Column(
                    children: [
                      const Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Verify your code',
                          style: TextStyle(
                            color: Color(0xFF26252F),
                            fontSize: 18,
                            fontFamily: 'LexendSemiBold',
                          ),
                        ),
                      ),
                      SizedBox(
                          height: MediaQuery.of(context).size.height * 0.05),
                      const Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          'Enter the code sent to',
                          style: TextStyle(
                            color: Color(0xFF26252F),
                            fontSize: 16,
                            fontFamily: 'LexendMedium',
                          ),
                        ),
                      ),
                      Align(
                        alignment: Alignment.topLeft,
                        child: Text(
                          '+91 ${widget.techerCode}',
                          style: const TextStyle(
                            color: Color(0xFF26252F),
                            fontSize: 16,
                            fontFamily: 'LexendMedium',
                          ),
                        ),
                      ),
                      const SizedBox(height: 10.0),
                      TextFormField(
                        controller: oTPController,
                        autofocus: false,
                        style: TextStyle(fontFamily: 'LexendRegular'),
                        cursorColor: Colors.black,
                        keyboardType: TextInputType.text,
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.symmetric(
                              vertical: 8.0, horizontal: 16.0),
                          hintText: "Please enter your OTP",
                          hintStyle: TextStyle(
                            fontSize: 12,
                            color: Color.fromARGB(255, 196, 196, 196),
                            fontFamily: 'LexendRegular',
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(13.0)),
                            borderSide: BorderSide(
                              color: Color.fromARGB(255, 184, 184, 184),
                              width: 0.0,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(13.0)),
                          ),
                        ),
                        // Add validation logic
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your OTP';
                          }
                          if (value.length < 6) {
                            return 'OTP must be at least 6 characters';
                          }
                          return null; // If validation passes
                        },
                      ),
                      SizedBox(
                          height: MediaQuery.of(context).size.height * 0.01),
                      Align(
                        alignment: Alignment.centerRight,
                        child: InkWell(
                          onTap: () {
                            loginController.resend(
                                context, widget.techerCode.toString());
                          },
                          child: Text(
                            "Resend OTP",
                            style: TextStyle(
                                fontSize: 12,
                                color: Color(0xFF0082E1),
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                      ),
                      SizedBox(
                          height: MediaQuery.of(context).size.height * 0.04),
                      CustomButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            verifyOTP(context, oTPController.text);
                            print("Teacher Code: ${oTPController.text}");
                          }
                        },
                        buttonText: "Sign In",
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
