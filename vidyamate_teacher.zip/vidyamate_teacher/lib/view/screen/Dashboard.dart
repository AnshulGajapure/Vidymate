import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:searchfield/searchfield.dart';
import 'package:vidyamate_teacher/controller/dashboard_controller.dart';
import 'package:vidyamate_teacher/controller/login_controller.dart';
import 'package:vidyamate_teacher/model/dashboard_model.dart';
import 'package:vidyamate_teacher/model/teacher_data_model.dart';
import 'package:vidyamate_teacher/resources/my_assets.dart';
import 'package:vidyamate_teacher/utils/widgets/dropdown_class.dart';
import 'package:vidyamate_teacher/view/screen/OnboardingScreen.dart';

import 'Attendance.dart';
import 'Content Uploader.dart';
import 'Exmination.dart';
import 'Mock Test.dart';
import 'MyTimetable.dart';
import 'Online Test.dart';
import 'Profile.dart';
import 'Report.dart';
import 'School Communication.dart';
import 'Teacher Desk.dart';
import 'horizontal_attendence.dart';

class Dashboard extends StatefulWidget {
  final TeacherDataModel responseModel;

  Dashboard(this.responseModel);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  String? selectedClass;
  String? selectedDay;
  TempDict? teacherData;
  final DashboardController dashboardController =
      Get.put(DashboardController());
  final LoginController loginController = Get.put(LoginController());

  @override
  void initState() {
    super.initState();
    teacherData = widget.responseModel.tempDict;
    callAPiSequence();
  }

  void callAPiSequence() {
    // call for set data in select session drop down
    WidgetsBinding.instance.addPostFrameCallback((_) {
      dashboardController.getAcademicSession(context).then((_) {
        if (dashboardController.session.isNotEmpty) {
          setState(() {
            dashboardController.selectedAcademicSessionId =
                dashboardController.session[0];
          });
        }
      });
    });
    // call for how much class asign to login in teacher
    // dashboardController.getClassAndSection(context);
    // call for half data of dashboard
    // dashboardController.getDashboardApi2(context);
  }

  DateTime selectedDate = DateTime.now();

  // Function to open the date picker and update the selected date
  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null && pickedDate != selectedDate) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }

  final List<Map<String, String>> data = [
    {"name": "Donna Lewis", "class": "6th C"},
    {"name": "John Doe", "class": "7th B"},
  ];

  final List<String> suggestions = [
    'India',
    'United States',
    'Canada',
    'Australia',
    'Germany',
    'France'
  ];

  String? selectedValue;
  final FocusNode focus = FocusNode();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: Padding(
          padding: EdgeInsets.only(left: size.width * 0.04),
          child: PopupMenuButton<String>(
            offset: Offset(0, size.height * 0.075),
            // Adjust the offset as needed
            onSelected: (value) {
              if (value == 'Profile') {
                Get.to(Profile());
              } else if (value == 'Logout') {
                // Perform logout action
              }
            },
            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'Profile',
                child: SizedBox(
                  height: size.height * 0.02,
                  // Set a fixed height for each item
                  child: Row(
                    children: [
                      Image.asset(
                        "assets/images/user.png",
                        height: size.height * 0.04,
                        width: size.width * 0.04,
                      ),
                      SizedBox(width: 6),
                      // Reduced spacing
                      Text('Profile', style: TextStyle(fontSize: 14)),
                      // Adjusted font size
                    ],
                  ),
                ),
              ),
              PopupMenuItem(
                value: 'Logout',
                child: SizedBox(
                  height: size.height * 0.04,
                  child: Row(
                    children: [
                      Image.asset(
                        "assets/images/logout.png",
                        height: size.height * 0.04,
                        width: size.width * 0.04,
                      ),
                      SizedBox(width: 2),
                      Text('Logout', style: TextStyle(fontSize: 14)),
                    ],
                  ),
                ),
              ),
            ],
            child: CircleAvatar(
              backgroundImage: AssetImage("assets/images/Ellipse 256.png"),
            ),
          ),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(
                  "Hi, ",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: size.width * 0.05,
                  ),
                ),
                Text(
                  "${teacherData?.userDetail?.firstName ?? ''} ${teacherData?.userDetail?.lastName ?? ''}",
                  style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                    fontSize: size.width * 0.05,
                  ),
                ),
              ],
            ),
            Text(
              "Employee Code: ${teacherData?.userDetail?.staffId ?? ''}",
              style: TextStyle(
                color: Colors.grey,
                fontSize: size.width * 0.03,
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: size.width * 0.04),
            child: Row(
              children: [
                InkWell(
                  onTap: () {
                    showDialog(
                      context: context,
                      barrierDismissible: false,
                      builder: (BuildContext context) {
                        return Dialog(
                          insetPadding: EdgeInsets.symmetric(horizontal: 20),
                          child: Container(
                            padding: const EdgeInsets.all(16.0),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(20.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.5),
                                  spreadRadius: 2,
                                  blurRadius: 5,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    InkWell(
                                      onTap: () => Navigator.pop(context),
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: Colors.black,
                                          borderRadius:
                                              BorderRadius.circular(20.0),
                                        ),
                                        child: Icon(
                                          Icons.close,
                                          color: Colors.white,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      child: Text(
                                        'Principal’s Message',
                                        style: TextStyle(
                                            color: Color(0xFF007DFF),
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                            fontFamily: "LexendRegular"),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),
                                const SingleChildScrollView(
                                  child: Text(
                                    'Please be informed that the examination schedule for the upcoming term has been finalized. Kindly review the schedule shared in your email and ensure all necessary preparations are in place. Let’s work together to make this a smooth process for our students.',
                                    style: TextStyle(
                                      fontSize: 12,
                                      height: 1.5,
                                    ),
                                    textAlign: TextAlign.justify,
                                  ),
                                ),
                                const SizedBox(height: 16),
                                GestureDetector(
                                  onTap: () => Navigator.pop(context),
                                  child: Container(
                                    height: size.height * 0.050,
                                    width: size.width * 0.2,
                                    // Adjust button width
                                    decoration: BoxDecoration(
                                      color: Color(0xFF0082E1),
                                      borderRadius: BorderRadius.circular(8.0),
                                    ),
                                    child: const Center(
                                      child: Text(
                                        "Ok",
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontFamily: 'LexendRegular',
                                          fontSize: 18.0,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                  child: Image.asset(
                    'assets/images/message.png',
                    width: size.width * 0.07,
                    height: size.width * 0.07,
                  ),
                ),
                SizedBox(width: size.width * 0.03),
                InkWell(
                  onTap: () {},
                  child: Image.asset(
                    'assets/images/bell.png',
                    width: size.width * 0.07,
                    height: size.width * 0.07,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            color: Color(0xffF9FAFB),
          ),
          padding: EdgeInsets.all(size.width * 0.04),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: Container(
                      height: size.height * 0.05,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: Color(0xFFD4D4D4), width: 1),
                      ),
                      child: SearchField(
                        suggestions: suggestions
                            .map((e) => SearchFieldListItem(e))
                            .toList(),
                        suggestionStyle:
                            TextStyle(color: Colors.black, fontSize: 16),
                        suggestionItemDecoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(5),
                        ),
                        hint: "Search here...",
                        searchStyle: TextStyle(fontSize: 10),
                        searchInputDecoration: InputDecoration(
                          prefixIcon: Icon(
                            Icons.search,
                            size: 20,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8.0),
                            borderSide: BorderSide.none,
                          ),
                          filled: true,
                          fillColor: Colors.grey[200],
                        ),
                        onSuggestionTap: (suggestion) {
                          print("You selected: ${suggestion.searchKey}");
                        },
                      ),
                    ),
                  ),
                  SizedBox(width: size.width * 0.03),
                  Expanded(
                    flex: 2,
                    child: Text(
                      'Select Session',
                      style: TextStyle(fontSize: size.width * 0.03),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  SizedBox(width: size.width * 0.02),
                  Expanded(
                    flex: 3,
                    child: Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: size.width * 0.02,
                      ),
                      decoration: BoxDecoration(
                        border: Border.all(color: Color(0xFFD9D9D9)),
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      child: DropdownButton<String>(
                        value: dashboardController.selectedAcademicSessionId,
                        isExpanded: true,
                        hint: Text(
                          "Select Session",
                          style: TextStyle(fontSize: size.width * 0.03),
                        ),
                        underline: SizedBox(),
                        icon: Icon(Icons.keyboard_arrow_down_outlined),
                        onChanged: (String? newValue) {
                          setState(() {
                            dashboardController.selectedAcademicSessionId =
                                newValue;
                          });
                        },
                        items: dashboardController.session.map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(
                              value,
                              style: TextStyle(fontSize: size.width * 0.03),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: size.height * 0.02),
              HorizontalNoticeListView(),
              SizedBox(height: size.height * 0.02),
              // Grid view with limited height to avoid overflow
              SizedBox(
                height: size.height * 0.46,
                child: GridView.builder(
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                    childAspectRatio: 1,
                  ),
                  itemCount: teacherData!.schoolModules?.length ?? 0,
                  itemBuilder: (context, index) {
                    final schoolModule = teacherData!.schoolModules![index];
                    return MenuTile(schoolModule: schoolModule);
                  },
                ),
              ),
              HorizontalAttendenceListView(),
              SizedBox(height: size.height * 0.01),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                    child: Text(
                      "View More",
                      style: TextStyle(
                          fontFamily: "Plus Jakarta Sans",
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0XFF0082E1)),
                    ),
                  )
                ],
              ),
              SizedBox(height: size.height * 0.02),
              buildBirthdayList(),
              SizedBox(height: size.height * 0.05),
              buildHolidayList(),
              SizedBox(height: size.height * 0.02),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  InkWell(
                    child: Text(
                      "View More",
                      style: TextStyle(
                          fontFamily: "Plus Jakarta Sans",
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0XFF0082E1)),
                    ),
                  )
                ],
              ),
              SizedBox(height: size.height * 0.04),
              AttendenceList(),
              SizedBox(
                height: size.height * 0.04,
              )
            ],
          ),
        ),
      ),
    );
  }
}

class MenuTile extends StatelessWidget {
  final SchoolModules schoolModule;

  MenuTile({required this.schoolModule});

  @override
  Widget build(BuildContext context) {
    print("Module Name: ${schoolModule.fkModuleName}");
    return GestureDetector(
      onTap: () {
        // Navigate to a different page based on fkModuleName or other conditions.
        if (schoolModule.fkModuleName == "Timetable") {
          Get.to(MyTimetable());
        } else if (schoolModule.fkModuleName == "Attendance") {
          Get.to(Attendance());
        } else if (schoolModule.fkModuleName == "Examination") {
          Get.to(Examination());
        } else if (schoolModule.fkModuleName == "Teacher Desk") {
          Get.to(TeacherDesk());
        } else if (schoolModule.fkModuleName == "Mock Test") {
          Get.to(MockTest());
        } else if (schoolModule.fkModuleName == "Online Test") {
          Get.to(OnlineTest());
        } else if (schoolModule.fkModuleName == "Content Uploader") {
          Get.to(ContentUploader());
        } else if (schoolModule.fkModuleName == "Reports") {
          Get.to(Report());
        } else if (schoolModule.fkModuleName == "School Communication") {
          Get.to(SchoolCommunication());
        } else if (schoolModule.fkModuleName == "Administration") {
          Get.to(OnboardingScreen());
        }
        // Continue this pattern for other modules or use a more concise method.
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 1,
              blurRadius: 5,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image(
                image: schoolModule.fkModuleName == "Administration"
                    ? administration
                    : schoolModule.fkModuleName == "Admission"
                        ? addmission
                        : schoolModule.fkModuleName == "Attendance"
                            ? attendence
                            : schoolModule.fkModuleName == "Examination"
                                ? examination
                                : schoolModule.fkModuleName == "Fees"
                                    ? fees
                                    : schoolModule.fkModuleName == "LMS"
                                        ? lms
                                        : schoolModule.fkModuleName == "Hostel"
                                            ? hostel
                                            : schoolModule.fkModuleName ==
                                                    "Payroll"
                                                ? payroll
                                                : schoolModule.fkModuleName ==
                                                        "Reports"
                                                    ? reports
                                                    : schoolModule
                                                                .fkModuleName ==
                                                            "School Communication"
                                                        ? schoolCommunication
                                                        : schoolModule
                                                                    .fkModuleName ==
                                                                "Teacher Desk"
                                                            ? teachersDesk
                                                            : schoolModule
                                                                        .fkModuleName ==
                                                                    "Timetable"
                                                                ? timetable
                                                                : schoolModule
                                                                            .fkModuleName ==
                                                                        "Transport"
                                                                    ? transport
                                                                    : appLogo,
                width: 32,
                height: 32,
              ),
              SizedBox(height: 4),
              Flexible(
                child: Text(
                  schoolModule.fkModuleName ?? '',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.w500),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HorizontalNoticeListView extends StatefulWidget {
  @override
  _HorizontalNoticeListViewState createState() =>
      _HorizontalNoticeListViewState();
}

class _HorizontalNoticeListViewState extends State<HorizontalNoticeListView> {
  final DashboardController dashboardController =
      Get.put(DashboardController());

  final PageController _pageController = PageController();
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          height: 140,
          // padding: EdgeInsets.all(10),
          child: GetBuilder<DashboardController>(
            builder: (controller) {
              if (controller.circulrsList.isEmpty) {
                return Center(child: Text("No circulars available."));
              }
              return PageView.builder(
                controller: _pageController,
                itemCount: controller.circulrsList.length,
                onPageChanged: (int index) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
                itemBuilder: (context, index) {
                  final circular = controller.circulrsList[index];
                  return InkWell(
                    onTap: () {
                      _showCircularDetailsDialog(circular);
                    },
                    child: Container(
                      width: 400,
                      padding: EdgeInsets.all(10),
                      child: Card(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(8))),
                        color: Color(0xffECF1FF),
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: Text(
                                      circular.mainTitle!,
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.black,
                                      ),
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 10),
                              Flexible(
                                child: Text(
                                  circular.title!,
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black,
                                    fontFamily: 'Plus Jakarta Sans',
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            dashboardController.circulrsList.length,
            (index) => AnimatedContainer(
              duration: Duration(milliseconds: 300),
              margin: EdgeInsets.symmetric(horizontal: 4),
              width: 20,
              height: 5,
              decoration: BoxDecoration(
                color: _currentIndex == index
                    ? Color(0xff0082E1)
                    : Colors.grey[400],
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
            ),
          ),
        ),
      ],
    );
  }

  void _showCircularDetailsDialog(Circulars circular) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(30)),
              color: Colors.white,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30)),
                    color: Color(0xffECF1FF),
                  ),
                  padding: EdgeInsets.all(16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Flexible(
                        child: Text(
                          circular.mainTitle!,
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 10),
                Expanded(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: SingleChildScrollView(
                      child: Text(circular.title!),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  padding: EdgeInsets.all(10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(width: 10),
                      Container(
                        height: 40,
                        width: 80,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                          border: Border.all(
                            width: 1,
                            color: Color(0xffECF1FF),
                          ),
                        ),
                        child: TextButton(
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                          child: Text(
                            'Close',
                            style: TextStyle(color: Colors.blue),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

Widget buildBirthdayList() {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.blue.shade50,
      borderRadius: BorderRadius.circular(10),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.5), // Shadow color
          spreadRadius: 2, // How much the shadow spreads
          blurRadius: 8, // Softness of the shadow
          offset: Offset(4, 4), // Positioning of the shadow
        ),
        BoxShadow(
          color: Colors.white.withOpacity(0.5), // Highlight effect for 3D
          spreadRadius: 1,
          blurRadius: 8,
          offset: Offset(-4, -4),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Birthday List',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            InkWell(
              onTap: () {},
              child: Text(
                "View More",
                style: TextStyle(
                    fontFamily: "Plus Jakarta Sans",
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0XFF0082E1)),
              ),
            )
          ],
        ),
        SizedBox(height: 10),
        ListView.builder(
          shrinkWrap: true,
          itemCount: 2,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 5),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundImage: ellipse,
                  ),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Test1", style: TextStyle(fontSize: 15)),
                      Text("Test 2", style: TextStyle(fontSize: 10)),
                    ],
                  ),
                  Spacer(),
                  Container(
                    height: 30,
                    width: 30,
                    child: Image(
                      image: confetti,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    ),
  );
}

Widget buildHolidayList() {
  return Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(10),
      boxShadow: [
        BoxShadow(
          color: Colors.grey.withOpacity(0.5), // Shadow color
          spreadRadius: 2, // How much the shadow spreads
          blurRadius: 8, // Softness of the shadow
          offset: Offset(4, 4), // Positioning of the shadow
        ),
        BoxShadow(
          color: Colors.white.withOpacity(0.5), // Highlight effect for 3D
          spreadRadius: 1,
          blurRadius: 8,
          offset: Offset(-4, -4),
        ),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Holiday List',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        SizedBox(height: 10),
        ListView.builder(
          shrinkWrap: true,
          itemCount: 2,
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Container(
              margin: const EdgeInsets.symmetric(vertical: 5),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Color(0XFFEEEBEB),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    backgroundImage: ellipse,
                  ),
                  SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Test1", style: TextStyle(fontSize: 15)),
                      Text("Test 2", style: TextStyle(fontSize: 10)),
                    ],
                  ),
                  Spacer(),
                  Container(
                    height: 30,
                    width: 30,
                    child: Image(
                      image: confetti,
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    ),
  );
}

class AttendenceList extends StatefulWidget {
  @override
  _AttendenceListState createState() => _AttendenceListState();
}

class _AttendenceListState extends State<AttendenceList> {
  final DashboardController dashboardController =
      Get.put(DashboardController());
  DateTime selectedDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (pickedDate != null && pickedDate != selectedDate) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // Use MediaQuery to get screen width and height for responsive adjustments
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Container(
      padding: EdgeInsets.all(screenWidth * 0.04), // Responsive padding
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        boxShadow: const [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 5,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Attendance List',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
          ),
          SizedBox(height: screenHeight * 0.02), // Responsive spacing
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () => _selectDate(context),
                child: Container(
                  width: screenWidth * 0.28,
                  height: screenHeight * 0.05,
                  padding: EdgeInsets.symmetric(horizontal: screenWidth * 0.04),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(
                      color: Colors.grey.shade300,
                      width: 2,
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Image.asset(
                        'assets/images/calendar.png',
                        width: screenWidth * 0.04,
                        height: screenHeight * 0.04,
                      ),
                      SizedBox(width: screenWidth * 0.01), // Responsive spacing
                      Text(
                        DateFormat('dd-MM-yy').format(selectedDate),
                        style: TextStyle(fontSize: screenWidth * 0.03),
                      ),
                    ],
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Text(
                    'Select Class',
                    style: TextStyle(fontWeight: FontWeight.w500),
                  ),
                  SizedBox(
                    width: screenWidth * 0.02,
                  ),
                  ClassAndSectionDropdown(
                    items: dashboardController.classAndSectionList!.payload!,
                    onItemSelected: (int? id) {
                      // Handle the selected id here
                      print("Selected ID: $id");
                    },
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: screenHeight * 0.03), // Responsive spacing
          Row(
            children: [
              Image.asset(
                'assets/images/chart.png',
                width: screenWidth * 0.4,
                height: screenHeight * 0.2,
              ),

              SizedBox(width: screenWidth * 0.05),
              // Responsive spacing
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: screenWidth * 0.02,
                        height: screenHeight * 0.01,
                        color: Colors.red,
                      ),
                      SizedBox(width: screenWidth * 0.01),
                      const Text('Present Students'),
                    ],
                  ),
                  SizedBox(height: screenHeight * 0.01),
                  Row(
                    children: [
                      Container(
                        width: screenWidth * 0.02,
                        height: screenHeight * 0.01,
                        color: Colors.green,
                      ),
                      SizedBox(width: screenWidth * 0.01),
                      const Text('Absent Students'),
                    ],
                  ),
                ],
              ),
            ],
          ),
          SizedBox(height: screenHeight * 0.03), // Responsive spacing
          const Center(
            child: Text('Pie Chart Placeholder'),
          ),
        ],
      ),
    );
  }
}
