import 'package:flutter/material.dart';

class syllabus extends StatefulWidget {
  const syllabus({super.key});

  @override
  State<syllabus> createState() => _syllabusState();
}

late Size size;
final List<String> Options = ['abc', 'efg', 'hij', 'klm', 'nop'];
String? dropDown;
String? dropDown1;

class _syllabusState extends State<syllabus> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  children: [
                    Builder(builder: (context) {
                      return InkWell(
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        },
                        onLongPress: () {},
                        child: SizedBox(
                            height: size.height * 0.050,
                            width: size.width * 0.075,
                            child: Image.asset(
                              'assets/images/hamburger-menu.png',
                            )),
                      );
                    }),
                    const SizedBox(
                      width: 20,
                    ),
                    const Text(
                      "Syllabus",
                      style: TextStyle(
                          color: Color(0xFF0079EA),
                          fontSize: 17,
                          fontFamily: 'LexendRegular',
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ),
            // Row(
            //   mainAxisAlignment: MainAxisAlignment.start,
            //   children: [
            //     Text(
            //       "Syllabus",
            //       style: TextStyle(
            //           fontFamily: "LexendRegular",
            //           fontSize: 22,
            //           color: Colors.blue),
            //     ),
            //   ],
            // ),
            Container(
              width: size.width,
              decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: Color(0xFFD4D4D4),
                  ),
                  borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15, top: 10, bottom: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text("Class", 1),
                    Dropdown("Select Class", dropDown, Options,
                        (newValue) => setState(() => dropDown = newValue)),
                    text("Subject", 1),
                    Dropdown("Select Class", dropDown1, Options,
                        (newValue) => setState(() => dropDown = newValue)),
                    text("Upload File :", 1),
                    File(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: size.height * 0.040,
                            width: size.width * 0.2,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    width: 1, color: const Color(0xFF0079EA)),
                                color: Color(0xFF0079EA),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Image.asset(
                                  'assets/images/plus.png',
                                  height: 25,
                                ),
                                const Text(
                                  "Add",
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    color: Colors.white,
                                    fontFamily: "LexendReguler",
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: size.height * 0.040,
                            width: size.width * 0.2,
                            decoration: BoxDecoration(
                                border: Border.all(width: 1, color: Colors.red),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Image.asset(
                                  'assets/images/clear.png',
                                  height: 25,
                                ),
                                const Text(
                                  "Clear",
                                  style: TextStyle(
                                    color: Colors.red,
                                    fontSize: 12.0,
                                    fontFamily: "LexendReguler",
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              width: size.width,
              decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: Color(0xFFD4D4D4),
                  ),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8, top: 8),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('SR NO',
                            style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontFamily: "LexendReguler",
                                fontSize: 12,
                                color: Color(0xFF989292))),
                        Spacer(),
                        Text('CLASS NAME',
                            style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontFamily: "LexendReguler",
                                fontSize: 12,
                                color: Color(0xFF989292))),
                        Spacer(),
                        Text(
                          'SUBJECT NAME',
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontFamily: "LexendReguler",
                              fontSize: 12,
                              color: Color(0xFF989292)),
                        ),
                        Spacer(),
                        Text('FILE',
                            style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                fontFamily: "LexendReguler",
                                color: Color(0xFF989292))),
                        Spacer(),
                        Text('ACTION',
                            style: TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 12,
                                fontFamily: "LexendReguler",
                                color: Color(0xFF989292))),
                      ],
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.only(bottom: 30.0, left: 8, right: 8),
                    child: Divider(),
                  ),
                  // Placeholder for 'Video Not Available' message
                  Padding(
                    padding: const EdgeInsets.only(bottom: 30.0),
                    child: Center(
                      child: Text(
                        'Syllabus Not Available !',
                        style: TextStyle(
                          color: Color(0xff989292),
                          fontWeight: FontWeight.bold,
                          fontFamily: "LexendReguler",
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              width: size.width,
              height: size.height * 0.2,
              decoration: BoxDecoration(
                  border: Border.all(
                    width: 1,
                    color: Color(0xFFD4D4D4),
                  ),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text('SR NO',
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontFamily: "LexendReguler",
                              fontSize: 12,
                              color: Color(0xFF989292))),
                      Text('CLASS NAME',
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontFamily: "LexendReguler",
                              fontSize: 12,
                              color: Color(0xFF989292))),
                      Text(
                        'SUBJECT NAME',
                        style: TextStyle(
                            fontWeight: FontWeight.w400,
                            fontFamily: "LexendReguler",
                            fontSize: 12,
                            color: Color(0xFF989292)),
                      ),
                      Text('FILE',
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                              fontFamily: "LexendReguler",
                              color: Color(0xFF989292))),
                      Text('ACTION',
                          style: TextStyle(
                              fontWeight: FontWeight.w400,
                              fontSize: 12,
                              fontFamily: "LexendReguler",
                              color: Color(0xFF989292))),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8, right: 8),
                    child: Divider(),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text("1"),
                      Text("10th"),
                      Text("Maths"),
                      Image.asset(
                        "assets/images/pdf-file.png",
                        height: 20,
                      ),
                      Image.asset(
                        "assets/images/delete.png",
                        height: 20,
                      )
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.050,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(
            color: Color(0xFF989292),
            fontSize: 12,
            fontFamily: "LexendReguler",
          ),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              // Display the passed text or an empty string if null
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Color(0xff444444),
              ),
            ),
            if (value == 1)
              TextSpan(
                text: " *",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget File() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                  hintText: "No file chosen",
                  hintStyle: TextStyle(
                    color: Color(0xFF989292),
                    fontSize: 12,
                    fontFamily: "LexendReguler",
                  ),
                  border: InputBorder.none,
                  // Removes default underline
                  contentPadding: EdgeInsets.zero,
                  // Adjusts the internal padding
                  prefixIcon: Stack(
                    children: [
                      Image.asset(
                        'assets/images/Rectangle.png',
                        // Adjust the width of the image
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 9.0, bottom: 5, left: 13),
                        child: Image.asset(
                          'assets/images/file.png',
                          height: 15, // Adjust the height of the image
                          width: 15, // Adjust the width of the image
                        ),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ],
    );
  }
}
