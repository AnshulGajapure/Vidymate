import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class BusTracking extends StatefulWidget {
  const BusTracking({Key? key}) : super(key: key);

  @override
  State<BusTracking> createState() => _BusTrackingState();
}

class _BusTrackingState extends State<BusTracking> {
  // Google Maps controller
  late GoogleMapController mapController;

  // Initial position of the map
  final LatLng _center = const LatLng(37.7749, -122.4194); // San Francisco

  // Marker for the map
  final Set<Marker> _markers = {};

  // Function to handle map creation
  void _onMapCreated(GoogleMapController controller) {
    mapController = controller;
  }

  // Function to add a marker to the map
  void _addMarker(LatLng position) {
    final Marker marker = Marker(
      markerId: MarkerId(position.toString()),
      position: position,
      infoWindow: InfoWindow(title: "Selected Location"),
    );
    setState(() {
      _markers.add(marker);
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Bus Tracking",
          style: TextStyle(
            fontFamily: 'LexendRegular',
            fontWeight: FontWeight.bold,
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
            ),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding:
                const EdgeInsets.symmetric(horizontal: 10.0, vertical: 15.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "Bus Tracking",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: "LexendRegular",
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context); // Back navigation
                  },
                  child: Container(
                    height: size.height * 0.05,
                    width: size.width * 0.3,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: const Color(0xFF0079EA),
                        width: 1,
                      ),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: const Center(
                      child: Text(
                        "Go Back",
                        style: TextStyle(
                          fontSize: 12.0,
                          color: Colors.blue,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
              height: size.height * 0.78,
              width: size.width,
              padding: EdgeInsets.all(10),
              child: GoogleMap(
                onMapCreated: _onMapCreated,
                initialCameraPosition: CameraPosition(
                  target: _center,
                  zoom: 10,
                ),
                markers: _markers,
                onTap: _addMarker, // Add marker when tapping on the map
              )),
        ],
      ),
    );
  }
}
