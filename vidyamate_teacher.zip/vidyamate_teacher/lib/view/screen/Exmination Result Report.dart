import 'package:flutter/material.dart';

class ResultReport extends StatefulWidget {
  const ResultReport({super.key});

  @override
  State<ResultReport> createState() => _ResultReportState();
}

class _ResultReportState extends State<ResultReport> {
  late Size size;
  String? selectClass;
  final List<String> options = ['abc', 'efg', 'hij', 'klm', 'nop'];

  // List to track individual row selection
  List<bool> _selectedRows = [false, false, false];

  // To track the "Select All" header checkbox
  bool _selectAll = false;

  void _handleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      _selectedRows = List<bool>.filled(_selectedRows.length, _selectAll);
    });
  }

  void _handleRowSelection(int index, bool? value) {
    setState(() {
      _selectedRows[index] = value ?? false;
      _selectAll = _selectedRows.every((isSelected) => isSelected);
    });
  }

  @override
  Widget build(BuildContext context) {
    DateTime? _eventStartDate;
    DateTime? _eventEndDate;
    Future<void> _selectDate(BuildContext context, bool isStartDate) async {
      DateTime initialDate = DateTime.now();
      DateTime firstDate = DateTime(2000);
      DateTime lastDate = DateTime(2100);

      final DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: isStartDate && _eventStartDate != null
            ? _eventStartDate!
            : (!isStartDate && _eventEndDate != null)
                ? _eventEndDate!
                : initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
      );

      if (pickedDate != null) {
        setState(() {
          if (isStartDate) {
            _eventStartDate = pickedDate;
          } else {
            _eventEndDate = pickedDate;
          }
        });
      }
    }

    String? SelectClass;
    final List<String> Option = ['abc', 'efg', 'hij', 'klm', 'nop'];

    String? selectedClass;
    String? selectedDay;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];
    size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                children: [
                  Builder(builder: (context) {
                    return InkWell(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      onLongPress: () {},
                      child: SizedBox(
                          height: size.height * 0.050,
                          width: size.width * 0.075,
                          child: Image.asset(
                            'assets/images/hamburger-menu.png',
                          )),
                    );
                  }),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text(
                    "Result Report",
                    style: TextStyle(
                        color: Color(0xFF0079EA),
                        fontFamily: "LexendRegular",
                        fontSize: 17,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: size.width,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFD4D4D4)),
                borderRadius: BorderRadius.circular(17),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      text("Class"),
                      dropdown("Select Class", selectClass, options,
                          (newValue) => setState(() => selectClass = newValue))
                    ],
                  ),
                  Container(
                    height: size.height * 0.050,
                    width: size.width * 0.22,
                    decoration: BoxDecoration(
                        border: Border.all(width: 1, color: Colors.black),
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(5)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Image.asset(
                          'assets/images/eye.png',
                          height: 25,
                        ),
                        const Text(
                          "View",
                          style: TextStyle(
                              fontSize: 14.0, color: Color(0xFF989292)),
                        )
                      ],
                    ),
                  ),
                  Container(
                    height: size.height * 0.050,
                    width: size.width * 0.22,
                    decoration: BoxDecoration(
                        border: Border.all(width: 1, color: Colors.green),
                        color: Color(0xFF0DA800),
                        borderRadius: BorderRadius.circular(5)),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Image.asset(
                        //   'assets/images/eye.png',
                        //   height: 25,
                        // ),
                        Text(
                          "EXPORT",
                          style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.white,
                            fontFamily: "LexendRegular",
                          ),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(bottom: 30.0, top: 30),
            child: Text(
              "Result Not Available !",
              style: TextStyle(fontSize: 20),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Color(0xFFECF1FF),
                borderRadius: BorderRadius.circular(10),
                // Optional rounded corners
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2), // Shadow color
                    blurRadius: 10, // Softness of the shadow
                    spreadRadius: 2, // Extend the shadow
                    offset: Offset(0, 5), // Horizontal and vertical offset
                  ),
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Sr No.",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("1",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Student Name :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Prithvi Shah",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Rank",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("1",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Student Code :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("TIM00001",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Marks :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("20 /20",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          ))
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Class :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("10 th B",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Percentage :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("100",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          ))
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.4,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xffD4D4D4)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: const TextStyle(
                fontSize: 12,
                fontFamily: "LexendRegular",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
//
// class ResultReport extends StatefulWidget {
//   const ResultReport({super.key});
//
//   @override
//   State<ResultReport> createState() => _ResultReportState();
// }
//
// late Size size;
// String? selectClass;
// final List<String> options = ['abc', 'efg', 'hij', 'klm', 'nop'];
//
// class _ResultReportState extends State<ResultReport> {
//   @override
//   Widget build(BuildContext context) {
//     size = MediaQuery.of(context).size;
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: const Text(
//           "Result Report",
//           style: TextStyle(
//               fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
//         ),
//         flexibleSpace: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
//             ),
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           const Row(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               Padding(
//                 padding: EdgeInsets.all(15.0),
//                 child: Text(
//                   "Grade Card",
//                   style: TextStyle(
//                       fontFamily: "LexendRegular",
//                       fontSize: 18,
//                       color: Colors.blue),
//                 ),
//               ),
//             ],
//           ),
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Container(
//               width: size.width,
//               padding: const EdgeInsets.all(10),
//               decoration: BoxDecoration(
//                 border: Border.all(color: const Color(0xFFD4D4D4)),
//                 borderRadius: BorderRadius.circular(17),
//               ),
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       text("Class"),
//                       dropdown("Select Class", selectClass, options,
//                           (newValue) => setState(() => selectClass = newValue))
//                     ],
//                   ),
//                   Container(
//                     height: size.height * 0.050,
//                     width: size.width * 0.2,
//                     decoration: BoxDecoration(
//                         border: Border.all(width: 1, color: Colors.black),
//                         color: Colors.white,
//                         borderRadius: BorderRadius.circular(5)),
//                     child: Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         Image.asset(
//                           'assets/images/eye.png',
//                           height: 25,
//                         ),
//                         const Text(
//                           "View",
//                           style: TextStyle(
//                               fontSize: 14.0, color: Color(0xFF989292)),
//                         )
//                       ],
//                     ),
//                   ),
//                   Container(
//                     height: size.height * 0.050,
//                     width: size.width * 0.2,
//                     decoration: BoxDecoration(
//                         border: Border.all(width: 1, color: Colors.green),
//                         color: Color(0xFF0DA800),
//                         borderRadius: BorderRadius.circular(5)),
//                     child: const Row(
//                       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                       children: [
//                         // Image.asset(
//                         //   'assets/images/eye.png',
//                         //   height: 25,
//                         // ),
//                         Text(
//                           "EXPORT",
//                           style: TextStyle(fontSize: 14.0, color: Colors.black),
//                         )
//                       ],
//                     ),
//                   )
//                 ],
//               ),
//             ),
//           ),
//           const Padding(
//             padding: EdgeInsets.only(bottom: 30.0, top: 30),
//             child: Text(
//               "Result Not Available !",
//               style: TextStyle(fontSize: 20),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: EdgeInsets.all(10),
//               decoration: BoxDecoration(
//                 color: Color(0xFFECF1FF),
//                 borderRadius: BorderRadius.circular(10),
//                 // Optional rounded corners
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.2), // Shadow color
//                     blurRadius: 10, // Softness of the shadow
//                     spreadRadius: 2, // Extend the shadow
//                     offset: Offset(0, 5), // Horizontal and vertical offset
//                   ),
//                 ],
//               ),
//               child: const Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text("Sr No.",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("1",
//                           style: TextStyle(
//                               color: Color(0xFF444444), fontSize: 11)),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Text("Student Name :",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("Prithvi Shah",
//                           style: TextStyle(
//                               color: Color(0xFF444444), fontSize: 11)),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Text("Rank",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("1",
//                           style: TextStyle(
//                               color: Color(0xFF444444), fontSize: 11)),
//                     ],
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text("Student Code :",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("TIM00001",
//                           style: TextStyle(
//                               color: Color(0xFF444444), fontSize: 11)),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Text("Marks :",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("20 /20",
//                           style:
//                               TextStyle(color: Color(0xFF444444), fontSize: 11))
//                     ],
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text("Class :",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("10 th B",
//                           style: TextStyle(
//                               color: Color(0xFF444444), fontSize: 11)),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Text("Percentage :",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("100",
//                           style:
//                               TextStyle(color: Color(0xFF444444), fontSize: 11))
//                     ],
//                   )
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget dropdown(String hint, String? selectedValue, List<String> items,
//       ValueChanged<String?> onChanged) {
//     return Container(
//       height: size.height * 0.05,
//       width: size.width * 0.4,
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         border: Border.all(color: Colors.grey),
//         borderRadius: BorderRadius.circular(8),
//       ),
//       child: DropdownButton<String>(
//         value: selectedValue,
//         isExpanded: true,
//         hint: Text(
//           hint,
//           style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
//         ),
//         underline: const SizedBox(),
//         icon: Image.asset(
//           'assets/images/down-arrow.png',
//           height: 15,
//           width: 15,
//         ),
//         onChanged: onChanged,
//         items: items.map((String value) {
//           return DropdownMenuItem<String>(
//             value: value,
//             child: Text(value),
//           );
//         }).toList(),
//       ),
//     );
//   }
//
//   Widget text(String? text) {
//     return Padding(
//       padding: const EdgeInsets.only(top: 10.0, bottom: 10),
//       child: RichText(
//         text: TextSpan(
//           children: [
//             TextSpan(
//               text: text ?? '',
//               style: const TextStyle(
//                 fontSize: 14,
//                 fontFamily: "LexendRegular",
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black,
//               ),
//             ),
//             const TextSpan(
//               text: '*',
//               style: TextStyle(
//                 fontSize: 14,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.red,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
