import 'package:flutter/material.dart';

class SchoolCommunication extends StatefulWidget {
  const SchoolCommunication({super.key});

  @override
  State<SchoolCommunication> createState() => _SchoolCommunicationState();
}

late Size size;
bool isSwitch = false;
bool isSwitch1 = false;
String? SelectClass;
String? Section;
String? Concession;
String? Category;
String? BloodGroup;
String? Religion;
final List<String> classOptions = ['abc', 'efg', 'hij', 'klm', 'nop'];

class _SchoolCommunicationState extends State<SchoolCommunication> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            "School Communication",
            style: TextStyle(
                fontFamily: 'LexendRegular',
                fontWeight: FontWeight.bold,
                fontSize: 17),
          ),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
              ),
            ),
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.start,
                //   children: [
                //     Padding(
                //       padding: const EdgeInsets.all(8.0),
                //       child: Text(
                //         "SchoolCommunication",
                //         style: TextStyle(
                //             fontFamily: "LexendRegular",
                //             fontSize: 18,
                //             color: Colors.blue),
                //       ),
                //     ),
                //   ],
                // ),
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Row(
                      children: [
                        Builder(builder: (context) {
                          return InkWell(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            onLongPress: () {},
                            child: SizedBox(
                                height: size.height * 0.050,
                                width: size.width * 0.075,
                                child: Image.asset(
                                  'assets/images/hamburger-menu.png',
                                )),
                          );
                        }),
                        const SizedBox(
                          width: 20,
                        ),
                        const Text(
                          "School Communication",
                          style: TextStyle(
                              color: Color(0xFF0079EA),
                              fontFamily: "LexendReguler",
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: size.height * 0.05,
                      width: size.width * 0.7,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Color(
                                0xFF0079EA,
                              ),
                              width: 1),
                          borderRadius: BorderRadius.circular(20)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: size.height * 0.5,
                            width: (size.width * 0.69) / 2,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(20),
                                  bottomLeft: Radius.circular(20)),
                              color: Color(0xFF0079EA),
                            ),
                            child: Center(
                                child: Text("Student List",
                                    style: TextStyle(
                                        fontFamily: "LexendReguler",
                                        color: Colors.white,
                                        fontSize: 11))),
                          ),
                          Container(
                            height: size.height * 0.5,
                            width: (size.width * 0.69) / 2,
                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(20),
                                    bottomRight: Radius.circular(20))),
                            child: Center(
                              child: Text(
                                "Installment Balance",
                                style: TextStyle(
                                    fontFamily: "LexendReguler",
                                    color: Colors.black,
                                    fontSize: 11), // Optional styling
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                      width: size.width,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        border: Border.all(color: const Color(0xFFD4D4D4)),
                        borderRadius: BorderRadius.circular(17),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text("Messeges"),
                          textFormField("Message", size, 0.050),
                          Row(
                            children: [
                              Transform.scale(
                                scale: 0.6,
                                child: Switch(
                                  value: isSwitch,
                                  onChanged: (value) {
                                    setState(() {
                                      isSwitch = value;
                                    });
                                  },
                                  activeColor: Colors.white,
                                  inactiveTrackColor: Colors.grey,
                                  inactiveThumbColor: Colors.white,
                                  trackOutlineColor: WidgetStateProperty.all(
                                      Colors.transparent),
                                  activeTrackColor: Colors.blue,
                                ),
                              ),
                              Text("SMS"),
                              SizedBox(
                                width: 40,
                              ),
                              Transform.scale(
                                scale: 0.6,
                                child: Switch(
                                  value: isSwitch1,
                                  onChanged: (value) {
                                    setState(() {
                                      isSwitch1 = value;
                                    });
                                  },
                                  activeColor: Colors.white,
                                  inactiveTrackColor: Colors.grey,
                                  inactiveThumbColor: Colors.white,
                                  trackOutlineColor: WidgetStateProperty.all(
                                      Colors.transparent),
                                  activeTrackColor: Colors.blue,
                                ),
                              ),
                              Text("Notification"),
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: size.height * 0.050,
                                  width: size.width * 0.2,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1,
                                          color: const Color(0xFF0079EA)),
                                      color: Color(0xFF0079EA),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Image.asset(
                                        'assets/images/plus.png',
                                        height: 25,
                                      ),
                                      const Text(
                                        "Send",
                                        style: TextStyle(
                                            fontSize: 12.0,
                                            color: Colors.white),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Container(
                                  height: size.height * 0.050,
                                  width: size.width * 0.2,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1, color: Colors.red),
                                      borderRadius: BorderRadius.circular(5)),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      Image.asset(
                                        'assets/images/clear.png',
                                        height: 25,
                                      ),
                                      const Text(
                                        "Clear",
                                        style: TextStyle(
                                          color: Colors.red,
                                          fontFamily: "LexendReguler",
                                          fontSize: 12.0,
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      )),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: size.width,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFD4D4D4)),
                      borderRadius: BorderRadius.circular(17),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "FILTERS",
                          style: TextStyle(
                            color: Colors.blue,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendReguler",
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Dropdown(
                            "Select Class",
                            SelectClass,
                            classOptions,
                            (newValue) =>
                                setState(() => SelectClass = newValue)),
                        SizedBox(
                          height: 10,
                        ),
                        Dropdown("Section", Section, classOptions,
                            (newValue) => setState(() => Section = newValue)),
                        SizedBox(
                          height: 10,
                        ),
                        Dropdown(
                            "Concession",
                            Concession,
                            classOptions,
                            (newValue) =>
                                setState(() => Concession = newValue)),
                        SizedBox(
                          height: 10,
                        ),
                        Dropdown("Category", Category, classOptions,
                            (newValue) => setState(() => Category = newValue)),
                        SizedBox(
                          height: 10,
                        ),
                        Dropdown(
                            "Blood Group",
                            BloodGroup,
                            classOptions,
                            (newValue) =>
                                setState(() => BloodGroup = newValue)),
                        SizedBox(
                          height: 10,
                        ),
                        Dropdown("Religion", Religion, classOptions,
                            (newValue) => setState(() => Religion = newValue)),
                        SizedBox(
                          height: 10,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              height: size.height * 0.050,
                              width: size.width * 0.2,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 1, color: const Color(0xFF989292)),
                                  borderRadius: BorderRadius.circular(5)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Image.asset(
                                    'assets/images/eye.png',
                                    height: 25,
                                  ),
                                  const Text(
                                    "View",
                                    style: TextStyle(
                                      fontSize: 12.0,
                                      color: Colors.black,
                                      fontFamily: "LexendReguler",
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: size.width,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      border: Border.all(color: const Color(0xFFD4D4D4)),
                      borderRadius: BorderRadius.circular(17),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Text(
                              "Sr No",
                              style: TextStyle(fontSize: 11),
                            ),
                            Text(
                              "Student Code",
                              style: TextStyle(
                                fontSize: 11,
                                fontFamily: "LexendReguler",
                              ),
                            ),
                            Text("Phone Number",
                                style: TextStyle(
                                  fontSize: 11,
                                  fontFamily: "LexendReguler",
                                )),
                            Text("Student Name",
                                style: TextStyle(
                                  fontSize: 11,
                                  fontFamily: "LexendReguler",
                                )),
                          ],
                        ),
                        Divider(),
                        Text(
                          "Student Not Available",
                          style: TextStyle(
                            fontSize: 20,
                            color: Color(0xFF989292),
                            fontFamily: "LexendReguler",
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Container(
                    width: size.width,
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Color(0xFFE2E8F5),
                      border: Border.all(color: const Color(0xFFD4D4D4)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Student Code :',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: "LexendReguler",
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                  TextSpan(
                                    text: '23055',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: "LexendReguler",
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Phone Number : ',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: "LexendReguler",
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                  TextSpan(
                                    text: '9966332211',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: "LexendReguler",
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Student Name :',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: "LexendReguler",
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Veronika Doe',
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontFamily: "LexendReguler",
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Image.asset(
                              "assets/images/check1.png",
                              height: 30,
                              width: 30,
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ));
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * value,
            width: size.width * value,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white, // White background for the container
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(10),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(
            color: Color(0xFF989292),
            fontSize: 12,
            fontFamily: "LexendReguler",
          ),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.white, // White background for dropdown items
              child: Text(value),
            ),
          );
        }).toList(),
        dropdownColor: Colors.white, // White background for the dropdown menu
      ),
    );
  }
}
