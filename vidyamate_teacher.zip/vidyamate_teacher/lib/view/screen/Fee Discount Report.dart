import 'package:flutter/material.dart';

class FeeDiscountReport extends StatefulWidget {
  const FeeDiscountReport({super.key});

  @override
  State<FeeDiscountReport> createState() => _FeeDiscountReportState();
}

class _FeeDiscountReportState extends State<FeeDiscountReport> {
  late Size size;

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    String? selectedClass;
    String? selectedDay;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  children: [
                    Builder(builder: (context) {
                      return InkWell(
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        },
                        onLongPress: () {},
                        child: SizedBox(
                            height: 25,
                            width: 25,
                            child: Image.asset(
                                'assets/images/hamburger-menu.png')),
                      );
                    }),
                    const SizedBox(
                      width: 20,
                    ),
                    const Text(
                      "Fee Discount Report",
                      style: TextStyle(
                          fontFamily: "LexendRegular",
                          color: Color(0xFF0079EA),
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              width: size.width,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFD4D4D4)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text("Class", 1),
                          dropdown(
                              "Select Class",
                              selectedClass,
                              classOptions,
                              (newValue) =>
                                  setState(() => selectedClass = newValue)),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text("Section", 0),
                          dropdown(
                              "Select Class",
                              selectedClass,
                              classOptions,
                              (newValue) =>
                                  setState(() => selectedClass = newValue)),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text("Discount Reason ", 0),
                          dropdown(
                              "Select Class",
                              selectedClass,
                              classOptions,
                              (newValue) =>
                                  setState(() => selectedClass = newValue)),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          text("Select Fees Head", 0),
                          dropdown(
                              "Select Class",
                              selectedClass,
                              classOptions,
                              (newValue) =>
                                  setState(() => selectedClass = newValue)),
                        ],
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        margin: EdgeInsets.only(top: 10),
                        height: size.height * 0.050,
                        width: size.width * 0.28,
                        decoration: BoxDecoration(
                            border:
                                Border.all(width: 1, color: Color(0xFFD4D4D4)),
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Image.asset(
                              "assets/images/eye.png",
                              height: 25,
                            ),
                            const Text(
                              "View",
                              style: TextStyle(
                                fontSize: 12.0,
                                color: Colors.black38,
                                fontFamily: "LexendRegular",
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 10),
                        height: size.height * 0.050,
                        width: size.width * 0.28,
                        decoration: BoxDecoration(
                            border: Border.all(width: 1, color: Colors.red),
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Image.asset(
                              "assets/images/clear.png",
                              height: 25,
                            ),
                            const Text(
                              "Clear",
                              style: TextStyle(
                                fontSize: 12.0,
                                color: Colors.red,
                                fontFamily: "LexendRegular",
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            Container(
              width: size.width,
              height: size.height * 0.2,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFD4D4D4)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                "Summary",
                style: TextStyle(
                    fontFamily: "LexendRegular",
                    fontSize: 20,
                    color: Color(0xFF0079EA)),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Center(
                  child: Container(
                    height: size.height * 0.050,
                    width: size.width * 0.3,
                    decoration: BoxDecoration(
                        border: Border.all(width: 1, color: Color(0xFFD4D4D4)),
                        color: Color(0xFF0DA800),
                        borderRadius: BorderRadius.circular(5)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Image.asset(
                        //   'assets/images/eye.png',
                        //   height: 25,
                        // ),
                        const Text(
                          "Export",
                          style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.white,
                            fontFamily: "LexendRegular",
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              decoration: BoxDecoration(
                color: const Color(0xFFECF1FF),
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2),
                    blurRadius: 10,
                    spreadRadius: 2,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header Section
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Sr. No. :",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                            const Text(
                              "1",
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 10,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                          ],
                        ),
                        // Student Name Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Student Name :",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                            const Text(
                              "Prithvi Shah",
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 10,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "Fee Head Name",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                          ],
                        ),
                        // Class Name Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Class Name",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                            const Text(
                              "10 th-D",
                              style: TextStyle(
                                color: Color(0xFF444444),
                                fontSize: 10,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              "Discount",
                              style: TextStyle(
                                color: Colors.black,
                                fontSize: 11,
                                fontFamily: "LexendRegular", // Added fontFamily
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  Table(
                    defaultColumnWidth: FixedColumnWidth(size.width * 0.318),
                    // Equal column width for symmetry
                    border: TableBorder.symmetric(
                        inside: BorderSide(width: 1, color: Color(0xffD4D4D4))),
                    children: [
                      // Header Row
                      TableRow(children: [
                        Column(children: []),
                        Column(children: []),
                        Column(children: []),
                      ]),

                      // Data Rows
                      TableRow(children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(left: 5.0),
                              child: Text('Discount Reason:',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 5.0),
                              child: Text('Bad Debt',
                                  style: TextStyle(
                                    color: Color(0xFF0079EA),
                                    fontSize: 12,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                            SizedBox(height: 40), // Space between items
                            Padding(
                              padding: const EdgeInsets.only(left: 5.0),
                              child: Text('Given by:',
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(left: 5.0, bottom: 10),
                              child: Text('20',
                                  style: TextStyle(
                                    color: Color(0xFF0079EA),
                                    fontSize: 12,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                          ],
                        ),
                        Column(children: [
                          Text("Academics",
                              style: TextStyle(
                                fontSize: 12,
                                fontFamily: "LexendRegular", // Added fontFamily
                              )),
                          Divider(thickness: 1, color: Colors.black26),
                          Text("Hostel Fee",
                              style: TextStyle(
                                fontSize: 12,
                                fontFamily: "LexendRegular", // Added fontFamily
                              )),
                          Divider(thickness: 1, color: Colors.black26),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 8.0),
                                child: Text("Total",
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF0079EA),
                                      fontFamily:
                                          "LexendRegular", // Added fontFamily
                                    )),
                              ),
                            ],
                          ),
                          Divider(thickness: 1, color: Colors.black26),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    right: 8.0, bottom: 10),
                                child: Text("Total Discount:",
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFDC2E2E),
                                      fontFamily:
                                          "LexendRegular", // Added fontFamily
                                    )),
                              ),
                            ],
                          ),
                        ]),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 5.0),
                              child: Text("1000.0",
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                            Divider(thickness: 1, color: Colors.black26),
                            Padding(
                              padding: const EdgeInsets.only(right: 5.0),
                              child: Text("500.0",
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                            Divider(thickness: 1, color: Colors.black26),
                            Padding(
                              padding: const EdgeInsets.only(right: 5.0),
                              child: Text("1500.0",
                                  style: TextStyle(
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF0079EA),
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                            Divider(thickness: 1, color: Colors.black26),
                            Padding(
                              padding:
                                  const EdgeInsets.only(right: 5.0, bottom: 10),
                              child: Text("1500.0",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.red,
                                    fontWeight: FontWeight.bold,
                                    fontFamily:
                                        "LexendRegular", // Added fontFamily
                                  )),
                            ),
                          ],
                        ),
                      ]),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.4,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xffD4D4D4)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(
              fontFamily: "LexendRegular",
              color: Color(0xFF989292),
              fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(
              value,
              style: const TextStyle(fontFamily: "LexendRegular"),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: const TextStyle(
                fontFamily: "LexendRegular",
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            if (value == 1) // Use collection if syntax for conditionals
              const TextSpan(
                text: '*',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
