import 'package:flutter/material.dart';

class Events extends StatefulWidget {
  const Events({super.key});

  @override
  State<Events> createState() => _EventsState();
}

DateTime? _eventStartDate;
DateTime? _eventEndDate;
late Size size;
bool isToggled = false;
String? selectedOption = "Drive link";
bool isChecked = false;
bool isSwitched = false;
final List<Map<String, dynamic>> classData = [
  {'srNo': 1, 'className': '10th A', 'isChecked': false},
];

class _EventsState extends State<Events> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    // return Scaffold(
    //   appBar: AppBar(
    //     centerTitle: true,
    //     title: const Text(
    //       "Events",
    //       style: TextStyle(
    //           fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
    //     ),
    //     flexibleSpace: Container(
    //       decoration: const BoxDecoration(
    //         gradient: LinearGradient(
    //           begin: Alignment.topCenter,
    //           end: Alignment.bottomCenter,
    //           colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
    //         ),
    //       ),
    //     ),
    //   ),
    //   body:
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                children: [
                  Builder(builder: (context) {
                    return InkWell(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      onLongPress: () {},
                      child: SizedBox(
                          height: size.height * 0.050,
                          width: size.width * 0.075,
                          child: Image.asset(
                            'assets/images/hamburger-menu.png',
                          )),
                    );
                  }),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text(
                    "Events",
                    style: TextStyle(
                        color: Color(0xFF0079EA),
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: size.height * 0.060,
                width: size.width * 0.35,
                decoration: BoxDecoration(
                    border: Border.all(width: 1, color: Colors.black),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image.asset(
                      'assets/images/geometry 1.png',
                      height: 25,
                    ),
                    const Text(
                      "New",
                      style: TextStyle(fontSize: 14.0, color: Colors.black),
                    )
                  ],
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                height: size.height * 0.060,
                width: size.width * 0.35,
                decoration: BoxDecoration(
                    border: Border.all(width: 1, color: Color(0xFFA1A1A1)),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset(
                      'assets/images/search.png',
                      height: 25,
                    ),
                    const Text(
                      "Search",
                      style:
                          TextStyle(fontSize: 14.0, color: Color(0xFFA1A1A1)),
                    )
                  ],
                ),
              ),
            ],
          ),
          SizedBox(
            height: 15,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: size.height * 0.060,
                width: size.width * 0.35,
                decoration: BoxDecoration(
                    border: Border.all(width: 1, color: Color(0xFF0079EA)),
                    color: Color(0xFF0079EA),
                    borderRadius: BorderRadius.circular(5)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset(
                      'assets/images/plus.png',
                      height: 25,
                    ),
                    const Text(
                      "Save",
                      style: TextStyle(fontSize: 14.0, color: Colors.white),
                    )
                  ],
                ),
              ),
              SizedBox(
                width: 15,
              ),
              Container(
                height: size.height * 0.060,
                width: size.width * 0.35,
                decoration: BoxDecoration(
                    border: Border.all(width: 1, color: Colors.red),
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(5)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Image.asset(
                      'assets/images/delete.png',
                      height: 25,
                    ),
                    const Text(
                      "Delete",
                      style: TextStyle(fontSize: 14.0, color: Colors.red),
                    )
                  ],
                ),
              ),
            ],
          ),
          Padding(
              padding: const EdgeInsets.all(10.0),
              child: Container(
                width: size.width,
                padding: const EdgeInsets.only(
                    top: 10, bottom: 10, left: 20, right: 20),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text("Title"),
                    textFormField("Title", size, 0.050),
                    SizedBox(
                      height: 10,
                    ),
                    text("Description"),
                    textFormField("Description", size, 0.090),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Event Start Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Event Start"),
                            SizedBox(
                              height: 5,
                            ),
                            Container(
                              height: size.height * 0.05,
                              width: size.width * 0.35,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFD4D4D4)),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: TextField(
                                readOnly: true,
                                onTap: () => _selectDate(context, true),
                                decoration: InputDecoration(
                                  hintText: _eventStartDate != null
                                      ? "${_eventStartDate!.day}/${_eventStartDate!.month}/${_eventStartDate!.year}"
                                      : "Select Date",
                                  hintStyle: TextStyle(
                                      color: Color(0xFF989292), fontSize: 12),
                                  border: InputBorder.none,
                                  suffixIcon: GestureDetector(
                                    onTap: () => _selectDate(context, true),
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Image.asset(
                                        "assets/images/calendar.png",
                                        height: 15,
                                        width: 15,
                                      ),
                                    ),
                                  ),
                                  contentPadding: EdgeInsets.only(
                                      left: 10, bottom: 12, right: 10),
                                ),
                              ),
                            ),
                          ],
                        ),

                        // Event End Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Event End"),
                            SizedBox(
                              height: 5,
                            ),
                            Container(
                              height: size.height * 0.05,
                              width: size.width * 0.35,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFD4D4D4)),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: TextField(
                                readOnly: true,
                                onTap: () => _selectDate(context, false),
                                decoration: InputDecoration(
                                  hintText: _eventEndDate != null
                                      ? "${_eventEndDate!.day}/${_eventEndDate!.month}/${_eventEndDate!.year}"
                                      : "Select Date",
                                  hintStyle: TextStyle(
                                      color: Color(0xFF989292), fontSize: 12),
                                  border: InputBorder.none,
                                  suffixIcon: GestureDetector(
                                    onTap: () => _selectDate(context, false),
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Image.asset(
                                        "assets/images/calendar.png",
                                        height: 15,
                                        width: 15,
                                      ),
                                    ),
                                  ),
                                  contentPadding: EdgeInsets.only(
                                      left: 10, bottom: 12, right: 10),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Document Upload:",
                          style: TextStyle(
                              fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                        SizedBox(height: 5),
                        // Reduced spacing between the title and the first item
                        RadioListTile<String>(
                          title: Text(
                            "Drive link",
                            style: TextStyle(fontSize: 12),
                          ),
                          value: "Drive link",
                          groupValue: selectedOption,
                          onChanged: (value) {
                            setState(() {
                              selectedOption = value;
                            });
                          },
                          activeColor: Colors.blue,
                          visualDensity:
                              VisualDensity(horizontal: -4, vertical: -4),
                        ),
                        RadioListTile<String>(
                          title: Text(
                            "YouTube Link",
                            style: TextStyle(fontSize: 12),
                          ),
                          value: "YouTube Link",
                          groupValue: selectedOption,
                          onChanged: (value) {
                            setState(() {
                              selectedOption = value;
                            });
                          },
                          activeColor: Colors.blue,
                          visualDensity:
                              VisualDensity(horizontal: -4, vertical: -4),
                        ),
                        RadioListTile<String>(
                          title: Text(
                            "File",
                            style: TextStyle(fontSize: 12),
                          ),
                          value: "File",
                          groupValue: selectedOption,
                          onChanged: (value) {
                            setState(() {
                              selectedOption = value;
                            });
                          },
                          activeColor: Colors.blue,
                          visualDensity:
                              VisualDensity(horizontal: -4, vertical: -4),
                        ),
                      ],
                    ),
                    if (selectedOption == "Drive link") ...[
                      text("Google Drive Link"),
                      textFormField("Drive Link", size, 0.050),
                    ] else if (selectedOption == "YouTube Link") ...[
                      text("YouTube Link"),
                      SizedBox(
                        height: 5,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            height: size.height * 0.050,
                            width: size.width * 0.75,
                            decoration: BoxDecoration(
                              border: Border.all(color: Color(0xFFD4D4D4)),
                              borderRadius: BorderRadius.circular(11),
                            ),
                            child: TextFormField(
                              textAlign: TextAlign.start,
                              textAlignVertical: TextAlignVertical.center,
                              decoration: InputDecoration(
                                contentPadding:
                                    EdgeInsets.only(left: 10, bottom: 18),
                                hintText: "YouTube Video Link",
                                hintStyle: TextStyle(
                                  color: Color(0xFF989292),
                                  fontSize: 12,
                                ),
                                border: InputBorder.none,
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Please enter some text';
                                }
                                return null;
                              },
                            ),
                          ),
                          Container(
                            height: size.height * 0.050,
                            decoration: BoxDecoration(
                              border: Border.all(
                                  width: 1, color: Color(0xFF0079EA)),
                              color: Color(0xFF0079EA),
                              borderRadius: BorderRadius.circular(5),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Icon(Icons.add, color: Colors.white),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ] else if (selectedOption == "File") ...[
                      text("File"),
                      File("Sample.pdf"),
                    ],
                    SizedBox(
                      height: 10,
                    ),
                    LayoutBuilder(
                      builder:
                          (BuildContext context, BoxConstraints constraints) {
                        return SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: ConstrainedBox(
                              constraints: BoxConstraints(
                                minWidth: constraints.maxWidth,
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: DataTable(
                                  border: TableBorder.all(
                                    color: Color(0xFF989292),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  headingRowHeight: 40,
                                  dataRowHeight: 40,
                                  headingRowColor: MaterialStateProperty.all(
                                      Color(0xFFD9D9D9)),
                                  columns: [
                                    DataColumn(
                                      label: Center(
                                        child: Text(
                                          'SR NO',
                                          style: TextStyle(fontSize: 10),
                                        ),
                                      ),
                                    ),
                                    DataColumn(
                                      label: Center(
                                        child: Text(
                                          'CLASS NAME',
                                          style: TextStyle(fontSize: 10),
                                        ),
                                      ),
                                    ),
                                    DataColumn(
                                      label: Center(
                                        child: Checkbox(
                                          value: isChecked,
                                          onChanged: (bool? value) {
                                            setState(() {
                                              isChecked = value!;
                                            });
                                          },
                                          activeColor: Colors.blue,
                                          checkColor: Colors.white,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                  rows: classData.map((classItem) {
                                    return DataRow(
                                      cells: [
                                        DataCell(
                                          Center(
                                            child: Text(
                                              classItem['srNo'].toString(),
                                              style: TextStyle(fontSize: 10),
                                            ),
                                          ),
                                        ),
                                        DataCell(
                                          Center(
                                            child: Text(
                                              classItem['className'],
                                              style: TextStyle(fontSize: 10),
                                            ),
                                          ),
                                        ),
                                        DataCell(
                                          Center(
                                            child: Checkbox(
                                              value: classItem['isChecked'] ??
                                                  false,
                                              onChanged: (bool? value) {
                                                setState(() {
                                                  classItem['isChecked'] =
                                                      value!;
                                                });
                                              },
                                              activeColor: Colors.blue,
                                              checkColor: Colors.white,
                                              shape: RoundedRectangleBorder(
                                                borderRadius:
                                                    BorderRadius.circular(5),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  }).toList(),
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    )
                  ],
                ),
              )),
        ],
      ),
    );
  }

  Widget File(String Text) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                  hintText: Text,
                  hintStyle: TextStyle(color: Color(0xFF989292), fontSize: 12),
                  border: InputBorder.none,
                  // Removes default underline
                  contentPadding: EdgeInsets.zero,
                  // Adjusts the internal padding
                  prefixIcon: Stack(
                    children: [
                      Image.asset(
                        'assets/images/Rectangle.png',
                        // Adjust the width of the image
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 9.0, bottom: 5, left: 13),
                        child: Image.asset(
                          'assets/images/file.png',
                          height: 15, // Adjust the height of the image
                          width: 15, // Adjust the width of the image
                        ),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ],
    );
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * value,
            width: size.width * value,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context, bool isStartDate) async {
    DateTime initialDate = DateTime.now();
    DateTime firstDate = DateTime(2000);
    DateTime lastDate = DateTime(2100);

    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: isStartDate && _eventStartDate != null
          ? _eventStartDate!
          : (!isStartDate && _eventEndDate != null)
              ? _eventEndDate!
              : initialDate,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (pickedDate != null) {
      setState(() {
        if (isStartDate) {
          _eventStartDate = pickedDate;
        } else {
          _eventEndDate = pickedDate;
        }
      });
    }
  }
}
