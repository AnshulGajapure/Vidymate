import 'package:flutter/material.dart';

class feedback extends StatefulWidget {
  const feedback({super.key});

  @override
  State<feedback> createState() => _feedbackState();
}

class _feedbackState extends State<feedback> {
  late Size size; /////////////////////
  final List<String> classOptions = ['10th A', '10th B', '10th C'];
  String? selectedvalue;
  String? selectedvalue1;

  @override
  Widget build(BuildContext context) {
    DateTime? _eventStartDate;
    DateTime? _eventEndDate;
    Future<void> _selectDate(BuildContext context, bool isStartDate) async {
      DateTime initialDate = DateTime.now();
      DateTime firstDate = DateTime(2000);
      DateTime lastDate = DateTime(2100);

      final DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: isStartDate && _eventStartDate != null
            ? _eventStartDate!
            : (!isStartDate && _eventEndDate != null)
                ? _eventEndDate!
                : initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
      );

      if (pickedDate != null) {
        setState(() {
          if (isStartDate) {
            _eventStartDate = pickedDate;
          } else {
            _eventEndDate = pickedDate;
          }
        });
      }
    }

    String? SelectClass;
    final List<String> Option = ['abc', 'efg', 'hij', 'klm', 'nop'];

    String? selectedClass;
    String? selectedDay;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];
    size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                Container(
                  child: Padding(
                    padding: const EdgeInsets.all(4.0),
                    child: Row(
                      children: [
                        Builder(builder: (context) {
                          return InkWell(
                            onTap: () {
                              Scaffold.of(context).openDrawer();
                            },
                            onLongPress: () {},
                            child: SizedBox(
                                height: size.height * 0.050,
                                width: size.width * 0.075,
                                child: Image.asset(
                                  'assets/images/hamburger-menu.png',
                                )),
                          );
                        }),
                        const SizedBox(
                          width: 20,
                        ),
                        const Text(
                          "Feedback",
                          style: TextStyle(
                              color: Color(0xFF0079EA),
                              fontFamily: "LexendRegular",
                              fontSize: 20,
                              fontWeight: FontWeight.bold),
                        )
                      ],
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: size.height * 0.060,
                      width: size.width * 0.35,
                      decoration: BoxDecoration(
                          border:
                              Border.all(width: 1, color: Color(0xFFD4D4D4)),
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.asset(
                            'assets/images/eye.png',
                            height: 25,
                          ),
                          const Text(
                            "View",
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Colors.black,
                              fontFamily: "LexendRegular",
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    Container(
                      height: size.height * 0.060,
                      width: size.width * 0.35,
                      decoration: BoxDecoration(
                          border:
                              Border.all(width: 1, color: Color(0xFF0079EA)),
                          color: Color(0xFF0079EA),
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.asset(
                            'assets/images/plus.png',
                            height: 25,
                          ),
                          const Text(
                            "Save",
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Colors.white,
                              fontFamily: "LexendRegular",
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: size.height * 0.060,
                      width: size.width * 0.35,
                      decoration: BoxDecoration(
                          border:
                              Border.all(width: 1, color: Color(0xFFDC2E2E)),
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.asset(
                            'assets/images/clear.png',
                            height: 25,
                          ),
                          const Text(
                            "Clear",
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Color(0xFFDC2E2E),
                              fontFamily: "LexendRegular",
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                    Container(
                      height: size.height * 0.060,
                      width: size.width * 0.35,
                      decoration: BoxDecoration(
                          border: Border.all(width: 1, color: Colors.red),
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(5)),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Image.asset(
                            'assets/images/delete.png',
                            height: 25,
                          ),
                          const Text(
                            "Delete",
                            style: TextStyle(
                              fontSize: 14.0,
                              color: Colors.red,
                              fontFamily: "LexendRegular",
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  text("Class"),
                  _buildDropdown("Select Class", selectedvalue, classOptions,
                      (NewValue) => setState(() => selectedvalue = NewValue)),
                  text("Examination"),
                  _buildDropdown("Select Exam", selectedvalue1, classOptions,
                      (NewValue) => setState(() => selectedvalue = NewValue)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Color(0xFFECF1FF),
                borderRadius: BorderRadius.circular(10),
                // Optional rounded corners
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2), // Shadow color
                    blurRadius: 10, // Softness of the shadow
                    spreadRadius: 2, // Extend the shadow
                    offset: Offset(0, 5), // Horizontal and vertical offset
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Sr No.",
                        style: TextStyle(
                          color: Color(0xFF000000),
                          fontSize: 12,
                          fontWeight: FontWeight.bold,
                          fontFamily: "LexendRegular",
                        ),
                      ),
                      Text(
                        "1",
                        style: TextStyle(
                          color: Color(0xFF444444),
                          fontSize: 11,
                          fontFamily: "LexendRegular",
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Remarks",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Excellent",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          ))
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Roll No.",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("25630",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          ))
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Name.",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Aarushi Sen",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          ))
                    ],
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget File(String Text) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                  hintText: Text,
                  hintStyle: TextStyle(color: Color(0xFF989292), fontSize: 12),
                  border: InputBorder.none,
                  // Removes default underline
                  contentPadding: EdgeInsets.zero,
                  // Adjusts the internal padding
                  prefixIcon: Stack(
                    children: [
                      Image.asset(
                        'assets/images/Rectangle.png',
                        // Adjust the width of the image
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 9.0, bottom: 5, left: 13),
                        child: Image.asset(
                          'assets/images/file.png',
                          height: 15, // Adjust the height of the image
                          width: 15, // Adjust the width of the image
                        ),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ],
    );
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * value,
            width: size.width * value,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
//
// class feedback extends StatefulWidget {
//   const feedback({super.key});
//
//   @override
//   State<feedback> createState() => _feedbackState();
// }
//
// late Size size;
// final List<String> classOptions = ['10th A', '10th B', '10th C'];
// String? selectedvalue;
// String? selectedvalue1;
//
// class _feedbackState extends State<feedback> {
//   @override
//   Widget build(BuildContext context) {
//     size = MediaQuery.of(context).size;
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: const Text(
//           "Examination",
//           style: TextStyle(
//               fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
//         ),
//         flexibleSpace: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
//             ),
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           Padding(
//             padding: const EdgeInsets.all(8.0),
//             child: Column(
//               children: [
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.start,
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.all(15.0),
//                       child: Text(
//                         "Feedback",
//                         style: TextStyle(
//                             fontFamily: "LexendRegular",
//                             fontSize: 18,
//                             color: Colors.blue),
//                       ),
//                     ),
//                   ],
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Container(
//                       height: size.height * 0.060,
//                       width: size.width * 0.4,
//                       decoration: BoxDecoration(
//                           border:
//                               Border.all(width: 1, color: Color(0xFFD4D4D4)),
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(5)),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Image.asset(
//                             'assets/images/eye.png',
//                             height: 25,
//                           ),
//                           const Text(
//                             "View",
//                             style:
//                                 TextStyle(fontSize: 14.0, color: Colors.black),
//                           )
//                         ],
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     Container(
//                       height: size.height * 0.060,
//                       width: size.width * 0.4,
//                       decoration: BoxDecoration(
//                           border:
//                               Border.all(width: 1, color: Color(0xFF0079EA)),
//                           color: Color(0xFF0079EA),
//                           borderRadius: BorderRadius.circular(5)),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Image.asset(
//                             'assets/images/plus.png',
//                             height: 25,
//                           ),
//                           const Text(
//                             "Save",
//                             style:
//                                 TextStyle(fontSize: 14.0, color: Colors.white),
//                           )
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//                 SizedBox(
//                   height: 15,
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Container(
//                       height: size.height * 0.060,
//                       width: size.width * 0.4,
//                       decoration: BoxDecoration(
//                           border:
//                               Border.all(width: 1, color: Color(0xFFDC2E2E)),
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(5)),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Image.asset(
//                             'assets/images/clear.png',
//                             height: 25,
//                           ),
//                           const Text(
//                             "Clear",
//                             style: TextStyle(
//                                 fontSize: 14.0, color: Color(0xFFDC2E2E)),
//                           )
//                         ],
//                       ),
//                     ),
//                     SizedBox(
//                       width: 15,
//                     ),
//                     Container(
//                       height: size.height * 0.060,
//                       width: size.width * 0.4,
//                       decoration: BoxDecoration(
//                           border: Border.all(width: 1, color: Colors.red),
//                           color: Colors.white,
//                           borderRadius: BorderRadius.circular(5)),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                         children: [
//                           Image.asset(
//                             'assets/images/delete.png',
//                             height: 25,
//                           ),
//                           const Text(
//                             "Delete",
//                             style: TextStyle(fontSize: 14.0, color: Colors.red),
//                           )
//                         ],
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: EdgeInsets.all(10),
//               decoration: BoxDecoration(
//                   border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
//                   borderRadius: BorderRadius.circular(10)),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   text("Class"),
//                   _buildDropdown("Select Class", selectedvalue, classOptions,
//                       (NewValue) => setState(() => selectedvalue = NewValue)),
//                   text("Examination"),
//                   _buildDropdown("Select Exam", selectedvalue1, classOptions,
//                       (NewValue) => setState(() => selectedvalue = NewValue)),
//                 ],
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: EdgeInsets.all(10),
//               decoration: BoxDecoration(
//                 color: Color(0xFFECF1FF),
//                 borderRadius: BorderRadius.circular(10),
//                 // Optional rounded corners
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.black.withOpacity(0.2), // Shadow color
//                     blurRadius: 10, // Softness of the shadow
//                     spreadRadius: 2, // Extend the shadow
//                     offset: Offset(0, 5), // Horizontal and vertical offset
//                   ),
//                 ],
//               ),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text(
//                         "Sr No.",
//                         style:
//                             TextStyle(color: Color(0xFF000000), fontSize: 12),
//                       ),
//                       Text(
//                         "1",
//                         style:
//                             TextStyle(color: Color(0xFF444444), fontSize: 11),
//                       ),
//                       SizedBox(
//                         height: 10,
//                       ),
//                       Text("Remarks",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("Excellent",
//                           style:
//                               TextStyle(color: Color(0xFF444444), fontSize: 11))
//                     ],
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text("Roll No.",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("25630",
//                           style:
//                               TextStyle(color: Color(0xFF444444), fontSize: 11))
//                     ],
//                   ),
//                   Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Text("Name.",
//                           style: TextStyle(
//                               color: Color(0xFF000000), fontSize: 12)),
//                       Text("Aarushi Sen",
//                           style:
//                               TextStyle(color: Color(0xFF444444), fontSize: 11))
//                     ],
//                   )
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget _buildDropdown(String hint, String? selectedValue, List<String> items,
//       ValueChanged<String?> onChanged) {
//     return Container(
//       height: size.height * 0.05,
//       width: size.width,
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
//       decoration: BoxDecoration(
//         border: Border.all(color: Colors.grey),
//         borderRadius: BorderRadius.circular(8),
//       ),
//       child: DropdownButton<String>(
//         value: selectedValue,
//         isExpanded: true,
//         hint: Text(
//           hint,
//           style: TextStyle(color: Color(0xFF989292), fontSize: 12),
//         ),
//         underline: const SizedBox(),
//         icon: Image.asset(
//           'assets/images/down-arrow.png',
//           height: 15,
//           width: 15,
//         ),
//         onChanged: onChanged,
//         items: items.map((String value) {
//           return DropdownMenuItem<String>(
//             value: value,
//             child: Text(value),
//           );
//         }).toList(),
//       ),
//     );
//   }
//
//   Widget File(String Text) {
//     return Row(
//       children: [
//         Expanded(
//           child: Container(
//             height: size.height * 0.05,
//             width: size.width,
//             decoration: BoxDecoration(
//               border: Border.all(color: Color(0xFFD4D4D4)),
//               borderRadius: BorderRadius.circular(11),
//             ),
//             child: TextField(
//               decoration: InputDecoration(
//                   hintText: Text,
//                   hintStyle: TextStyle(color: Color(0xFF989292), fontSize: 12),
//                   border: InputBorder.none,
//                   // Removes default underline
//                   contentPadding: EdgeInsets.zero,
//                   // Adjusts the internal padding
//                   prefixIcon: Stack(
//                     children: [
//                       Image.asset(
//                         'assets/images/Rectangle.png',
//                         // Adjust the width of the image
//                       ),
//                       Padding(
//                         padding: const EdgeInsets.only(
//                             top: 9.0, bottom: 5, left: 13),
//                         child: Image.asset(
//                           'assets/images/file.png',
//                           height: 15, // Adjust the height of the image
//                           width: 15, // Adjust the width of the image
//                         ),
//                       ),
//                     ],
//                   )),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget textFormField(String? hintText, Size size, double value) {
//     return Row(
//       children: [
//         Expanded(
//           child: Container(
//             height: size.height * value,
//             width: size.width * value,
//             decoration: BoxDecoration(
//               border: Border.all(color: Color(0xFFD4D4D4)),
//               borderRadius: BorderRadius.circular(11),
//             ),
//             child: TextFormField(
//               textAlign: TextAlign.start,
//               textAlignVertical: TextAlignVertical.center,
//               decoration: InputDecoration(
//                 contentPadding: EdgeInsets.only(left: 10, bottom: 18),
//                 hintText: hintText,
//                 hintStyle: TextStyle(
//                   color: Color(0xFF989292),
//                   fontSize: 12,
//                 ),
//                 border: InputBorder.none,
//               ),
//               validator: (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter some text';
//                 }
//                 return null;
//               },
//             ),
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget text(String? text) {
//     return Padding(
//       padding: const EdgeInsets.only(top: 10.0, bottom: 10),
//       child: RichText(
//         text: TextSpan(
//           children: [
//             TextSpan(
//               text: text ?? '',
//               style: TextStyle(
//                 fontSize: 14,
//                 fontFamily: "LexendReguler",
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black,
//               ),
//             ),
//             TextSpan(
//               text: '*',
//               style: TextStyle(
//                 fontSize: 14,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.red,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
