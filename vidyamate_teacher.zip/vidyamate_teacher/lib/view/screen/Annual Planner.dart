import 'package:flutter/material.dart';

class annualplanner extends StatefulWidget {
  const annualplanner({super.key});

  @override
  State<annualplanner> createState() => _annualplannerState();
}

late Size size;

class _annualplannerState extends State<annualplanner> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    // return Scaffold(
    //   appBar: AppBar(
    //     centerTitle: true,
    //     title: const Text(
    //       "Annual Planner",
    //       style: TextStyle(
    //           fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
    //     ),
    //     flexibleSpace: Container(
    //       decoration: const BoxDecoration(
    //         gradient: LinearGradient(
    //           begin: Alignment.topCenter,
    //           end: Alignment.bottomCenter,
    //           colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
    //         ),
    //       ),
    //     ),
    //   ),
    //   body:
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Container(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                children: [
                  Builder(builder: (context) {
                    return InkWell(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      onLongPress: () {},
                      child: SizedBox(
                          height: size.height * 0.050,
                          width: size.width * 0.075,
                          child: Image.asset(
                            'assets/images/hamburger-menu.png',
                          )),
                    );
                  }),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text(
                    "Annual Planner",
                    style: TextStyle(
                        color: Color(0xFF0079EA),
                        fontSize: 20,
                        fontFamily: "LexendReguler",
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
                width: size.width,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(17),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    text("Upload File : "),
                    File("No file chosen"),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: size.height * 0.050,
                            width: size.width * 0.2,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    width: 1, color: const Color(0xFF0079EA)),
                                color: Color(0xFF0079EA),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Image.asset(
                                  'assets/images/plus.png',
                                  height: 25,
                                ),
                                const Text(
                                  "Add",
                                  style: TextStyle(
                                    fontSize: 12.0,
                                    color: Colors.white,
                                    fontFamily: "LexendReguler",
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Container(
                            height: size.height * 0.050,
                            width: size.width * 0.2,
                            decoration: BoxDecoration(
                                border: Border.all(width: 1, color: Colors.red),
                                borderRadius: BorderRadius.circular(5)),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Image.asset(
                                  'assets/images/clear.png',
                                  height: 25,
                                ),
                                const Text(
                                  "Clear",
                                  style: TextStyle(
                                    color: Colors.red,
                                    fontFamily: "LexendReguler",
                                    fontSize: 12.0,
                                  ),
                                )
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: size.width,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFD4D4D4)),
                borderRadius: BorderRadius.circular(17),
              ),
              child: Center(
                child: Text(
                  "Annual Planner Not Available !",
                  style: TextStyle(
                    color: Color(0xff989292),
                    fontFamily: "LexendReguler",
                  ),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget File(String Text) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                  hintText: Text,
                  hintStyle: TextStyle(color: Color(0xFF989292), fontSize: 12),
                  border: InputBorder.none,
                  // Removes default underline
                  contentPadding: EdgeInsets.zero,
                  // Adjusts the internal padding
                  prefixIcon: Stack(
                    children: [
                      Image.asset(
                        'assets/images/Rectangle.png',
                        // Adjust the width of the image
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 9.0, bottom: 5, left: 13),
                        child: Image.asset(
                          'assets/images/file.png',
                          height: 15, // Adjust the height of the image
                          width: 15, // Adjust the width of the image
                        ),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
