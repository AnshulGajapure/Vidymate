import 'package:flutter/material.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

late Size size;
String? dropDown1;
String? dropDown2;
final List<String> Options = ['abc', 'efg', 'hij', 'klm', 'nop'];
bool isSwitched = false;
bool isSwitched1 = false;

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Color(0xFFF9FAFB),
        resizeToAvoidBottomInset: true,
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            "Profile",
            style: TextStyle(
                fontFamily: 'LexendRegular',
                fontWeight: FontWeight.bold,
                fontSize: 17),
          ),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
              ),
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: EdgeInsets.only(
            right: 10,
            top: 10,
            left: 10,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    "Profile",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF0079EA),
                        fontSize: 20,
                        fontFamily: "LexendRegular"),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(
                    left: 8.0, right: 8.0, bottom: 10, top: 10),
                child: Container(
                  padding: EdgeInsets.only(
                      right: 20.0, left: 20, bottom: 20, top: 10),
                  decoration: BoxDecoration(
                    color: Color(0xFFFFFFFF),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      width: 1,
                      color: Color(0xffD4D4D4),
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            "assets/images/user.png",
                            height: 150,
                          ),
                        ],
                      ),
                      text("Organization", 1),
                      textFormField("St. Johns High School", size),
                      // Dropdown("St. Johns High School", dropDown1, Options,
                      //     (newValue) => setState(() => dropDown1 = newValue)),
                      text("School Name", 1),
                      textFormField("School Name", size),
                      // Dropdown("School Name", dropDown2, Options,
                      //     (newValue) => setState(() => dropDown2 = newValue)),
                      text("U-DISE No ", 1),
                      textFormField("87813215448", size),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          text("Government", 0),
                          Padding(
                            padding: const EdgeInsets.only(right: 90.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Transform.scale(
                                  scale: 0.6,
                                  child: Switch(
                                    value: isSwitched,
                                    onChanged: (value) {
                                      setState(() {
                                        isSwitched = value;
                                      });
                                    },
                                    activeColor: Colors.white,
                                    inactiveTrackColor: Colors.grey,
                                    inactiveThumbColor: Colors.white,
                                    trackOutlineColor: WidgetStateProperty.all(
                                        Colors.transparent),
                                    activeTrackColor: Color(0xff0079EA),
                                  ),
                                ),
                                // Switch(
                                //   value: isSwitched,
                                //   onChanged: (value) {
                                //     setState(() {
                                //       isSwitched = value; // Toggle the state
                                //     });
                                //   },
                                //   activeColor: Colors.green,
                                //   inactiveThumbColor: Colors.white,
                                //   inactiveTrackColor: Colors.grey,
                                //   trackOutlineColor: WidgetStatePropertyAll(
                                //       Colors
                                //           .transparent), // Track color when OFF
                                // ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10.0),
                                  child: Text(isSwitched ? "Yes" : "No"),
                                ),
                              ],
                            ),
                          ),
                          // Conditional text based on switch state
                        ],
                      ),
                      text("Address", 1),
                      textFormField("IT Park", size),
                      text("State", 1),
                      textFormField("Maharashtra", size),
                      text("Pincode", 1),
                      textFormField("442506", size),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          text("Status", 0),
                          Padding(
                            padding: const EdgeInsets.only(right: 90),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Transform.scale(
                                  scale: 0.6,
                                  child: Switch(
                                    value: isSwitched1,
                                    onChanged: (value) {
                                      setState(() {
                                        isSwitched1 = value;
                                      });
                                    },
                                    activeColor: Colors.white,
                                    inactiveTrackColor: Colors.grey,
                                    inactiveThumbColor: Colors.white,
                                    trackOutlineColor: WidgetStateProperty.all(
                                        Colors.transparent),
                                    activeTrackColor: Color(0xff0079EA),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10.0),
                                  child: Text(isSwitched1 ? "Yes" : "No"),
                                ),
                              ],
                            ),
                          ),
                          // Conditional text based on switch state
                        ],
                      ),
                      text("Contact Person", 1),
                      textFormField("Purvi", size),
                      text("Contact Number", 1),
                      textFormField("9923561011", size),
                      text("Contact Email", 1),
                      textFormField("purvi@gmail.com", size)
                    ],
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.050,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        color: Color(0xFFF5F5F5),
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              // Display the passed text or an empty string if null
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            if (value == 1)
              TextSpan(
                text: " *",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget textFormField(String? hintText, Size size) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.050,
            width: size.width,
            decoration: BoxDecoration(
              color: Color(0xFFF5F5F5),
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }
}
