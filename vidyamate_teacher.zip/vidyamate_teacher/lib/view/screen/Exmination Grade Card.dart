import 'package:flutter/material.dart';

class GradeCard extends StatefulWidget {
  const GradeCard({super.key});

  @override
  State<GradeCard> createState() => _GradeCardState();
}

class _GradeCardState extends State<GradeCard> {
  late Size size;
  String? selectClass;
  final List<String> options = ['abc', 'efg', 'hij', 'klm', 'nop'];

  // List to track individual row selection
  List<bool> _selectedRows = [false, false, false];

  // To track the "Select All" header checkbox
  bool _selectAll = false;

  void _handleSelectAll(bool? value) {
    setState(() {
      _selectAll = value ?? false;
      _selectedRows = List<bool>.filled(_selectedRows.length, _selectAll);
    });
  }

  void _handleRowSelection(int index, bool? value) {
    setState(() {
      _selectedRows[index] = value ?? false;
      _selectAll = _selectedRows.every((isSelected) => isSelected);
    });
  }

  @override
  Widget build(BuildContext context) {
    DateTime? _eventStartDate;
    DateTime? _eventEndDate;
    Future<void> _selectDate(BuildContext context, bool isStartDate) async {
      DateTime initialDate = DateTime.now();
      DateTime firstDate = DateTime(2000);
      DateTime lastDate = DateTime(2100);

      final DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: isStartDate && _eventStartDate != null
            ? _eventStartDate!
            : (!isStartDate && _eventEndDate != null)
                ? _eventEndDate!
                : initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
      );

      if (pickedDate != null) {
        setState(() {
          if (isStartDate) {
            _eventStartDate = pickedDate;
          } else {
            _eventEndDate = pickedDate;
          }
        });
      }
    }

    String? SelectClass;
    final List<String> Option = ['abc', 'efg', 'hij', 'klm', 'nop'];

    String? selectedClass;
    String? selectedDay;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];
    size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                children: [
                  Builder(builder: (context) {
                    return InkWell(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      onLongPress: () {},
                      child: SizedBox(
                          height: size.height * 0.050,
                          width: size.width * 0.075,
                          child: Image.asset(
                            'assets/images/hamburger-menu.png',
                          )),
                    );
                  }),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text(
                    "GradeCard",
                    style: TextStyle(
                        color: Color(0xFF0079EA),
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
          Row(
            children: [
              _actionButton('View', 'assets/images/eye.png', Color(0xFFD4D4D4)),
              _actionButton(
                  'Print', 'assets/images/printer.png', Color(0xFF0079EA),
                  backgroundColor: Color(0xFF0079EA), textColor: Colors.white),
              _actionButton('Clear', 'assets/images/clear.png', Colors.red,
                  textColor: Colors.red),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: const EdgeInsets.all(10),
              width: size.width,
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  text("Class"),
                  dropdown("Select Class", selectClass, options,
                      (newValue) => setState(() => selectClass = newValue)),
                  text("Select Exam"),
                  dropdown("Select Exam", selectClass, options,
                      (newValue) => setState(() => selectClass = newValue)),
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
                borderRadius: BorderRadius.circular(10),
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: DataTable(
                  headingRowColor: MaterialStateColor.resolveWith(
                      (states) => Colors.grey[200]!),
                  columnSpacing: 10.0,
                  columns: [
                    DataColumn(
                      label: Transform.scale(
                        scale: 0.7,
                        // Adjust the scale factor (smaller than 1 makes it smaller)
                        child: Checkbox(
                          value: _selectAll,
                          onChanged: (bool? value) {
                            _handleSelectAll;
                          },
                        ),
                      ),
                    ),
                    DataColumn(
                        label: _headerText(
                      'Sr No',
                    )),
                    DataColumn(label: _headerText('Roll No.')),
                    DataColumn(label: _headerText('Student Name')),
                  ],
                  rows: [
                    DataRow(
                      cells: [
                        DataCell(
                          Transform.scale(
                            scale: 0.7,
                            // Adjust the scale factor (smaller than 1 makes it smaller)
                            child: Checkbox(
                              value: _selectedRows[0],
                              onChanged: (bool? value) {
                                _handleRowSelection(0, value);
                              },
                            ),
                          ),
                        ),
                        DataCell(Center(
                            child: Text('1', style: TextStyle(fontSize: 11)))),
                        DataCell(Center(
                            child:
                                Text('A1001', style: TextStyle(fontSize: 11)))),
                        DataCell(Text(
                          'Manaswi Roy',
                          style: TextStyle(fontSize: 11),
                          overflow: TextOverflow.ellipsis,
                        )),
                      ],
                    ),
                    DataRow(
                      cells: [
                        DataCell(
                          Transform.scale(
                            scale: 0.7,
                            // Adjust the scale factor (smaller than 1 makes it smaller)
                            child: Checkbox(
                              value: _selectedRows[1],
                              onChanged: (bool? value) {
                                _handleRowSelection(1, value);
                              },
                            ),
                          ),
                        ),
                        DataCell(Center(
                            child: Text(
                          '2',
                          style: TextStyle(fontSize: 11),
                        ))),
                        DataCell(Center(
                            child:
                                Text('A1002', style: TextStyle(fontSize: 11)))),
                        DataCell(Text(
                          'Aarushi Sen',
                          style: TextStyle(fontSize: 11),
                          overflow: TextOverflow.ellipsis,
                        )),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          )
        ],
      ),
    );
  }

  Widget _headerText(String text) {
    return Text(
      text,
      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11),
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _actionButton(String text, String iconPath, Color borderColor,
      {Color? backgroundColor, Color? textColor}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: size.height * 0.050,
        width: size.width * 0.25,
        decoration: BoxDecoration(
            border: Border.all(width: 1, color: borderColor),
            color: backgroundColor ?? Colors.transparent,
            borderRadius: BorderRadius.circular(5)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Image.asset(iconPath, height: 25),
            Text(
              text,
              style: TextStyle(fontSize: 12.0, color: textColor ?? borderColor),
            )
          ],
        ),
      ),
    );
  }

  Widget dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xffD4D4D4)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: const TextStyle(
                fontSize: 12,
                fontFamily: "LexendRegular",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
//
// class GradeCard extends StatefulWidget {
//   const GradeCard({super.key});
//
//   @override
//   State<GradeCard> createState() => _GradeCardState();
// }
//
// class _GradeCardState extends State<GradeCard> {
//   late Size size;
//   String? selectClass;
//   final List<String> options = ['abc', 'efg', 'hij', 'klm', 'nop'];
//
//   // List to track individual row selection
//   List<bool> _selectedRows = [false, false, false];
//
//   // To track the "Select All" header checkbox
//   bool _selectAll = false;
//
//   void _handleSelectAll(bool? value) {
//     setState(() {
//       _selectAll = value ?? false;
//       _selectedRows = List<bool>.filled(_selectedRows.length, _selectAll);
//     });
//   }
//
//   void _handleRowSelection(int index, bool? value) {
//     setState(() {
//       _selectedRows[index] = value ?? false;
//       _selectAll = _selectedRows.every((isSelected) => isSelected);
//     });
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     size = MediaQuery.of(context).size;
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: const Text(
//           "Examination",
//           style: TextStyle(
//               fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
//         ),
//         flexibleSpace: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
//             ),
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           Row(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(15.0),
//                 child: Text(
//                   "Grade Card",
//                   style: TextStyle(
//                       fontFamily: "LexendRegular",
//                       fontSize: 18,
//                       color: Colors.blue),
//                 ),
//               ),
//             ],
//           ),
//           Row(
//             children: [
//               _actionButton('View', 'assets/images/eye.png', Color(0xFFD4D4D4)),
//               _actionButton('Save', 'assets/images/plus.png', Color(0xFF0079EA),
//                   backgroundColor: Color(0xFF0079EA), textColor: Colors.white),
//               _actionButton('Clear', 'assets/images/clear.png', Colors.red,
//                   textColor: Colors.red),
//             ],
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: const EdgeInsets.all(10),
//               width: size.width,
//               decoration: BoxDecoration(
//                   border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
//                   borderRadius: BorderRadius.circular(10)),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   text("Class"),
//                   dropdown("Select Class", selectClass, options,
//                       (newValue) => setState(() => selectClass = newValue)),
//                   text("Select Exam"),
//                   dropdown("Select Exam", selectClass, options,
//                       (newValue) => setState(() => selectClass = newValue)),
//                 ],
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: const EdgeInsets.all(10),
//               width: double.infinity,
//               decoration: BoxDecoration(
//                 border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
//                 borderRadius: BorderRadius.circular(10),
//               ),
//               child: SingleChildScrollView(
//                 scrollDirection: Axis.horizontal,
//                 child: SingleChildScrollView(
//                   scrollDirection: Axis.vertical,
//                   child: DataTable(
//                     columnSpacing: 20.0,
//                     columns: [
//                       DataColumn(
//                         label: Checkbox(
//                           value: _selectAll,
//                           onChanged: _handleSelectAll,
//                         ),
//                       ),
//                       DataColumn(label: _headerText('Sr. No')),
//                       DataColumn(label: _headerText('Roll No')),
//                       DataColumn(label: _headerText('Student Name')),
//                     ],
//                     rows: List.generate(_selectedRows.length, (index) {
//                       return DataRow(
//                         cells: [
//                           DataCell(Checkbox(
//                             value: _selectedRows[index],
//                             onChanged: (bool? value) {
//                               _handleRowSelection(index, value);
//                             },
//                           )),
//                           DataCell(Center(child: Text('${index + 1}'))),
//                           DataCell(Center(child: Text('A10${index + 1}'))),
//                           DataCell(Text(
//                             [
//                               'Manaswi Roy',
//                               'Rahul Sharma',
//                               'Sneha Patel'
//                             ][index],
//                             overflow: TextOverflow.ellipsis,
//                           )),
//                         ],
//                       );
//                     }),
//                   ),
//                 ),
//               ),
//             ),
//           )
//         ],
//       ),
//     );
//   }
//
//   Widget _headerText(String text) {
//     return Text(
//       text,
//       style: TextStyle(fontWeight: FontWeight.bold),
//       overflow: TextOverflow.ellipsis,
//     );
//   }
//
//   Widget _actionButton(String text, String iconPath, Color borderColor,
//       {Color? backgroundColor, Color? textColor}) {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: Container(
//         height: size.height * 0.050,
//         width: size.width * 0.25,
//         decoration: BoxDecoration(
//             border: Border.all(width: 1, color: borderColor),
//             color: backgroundColor ?? Colors.transparent,
//             borderRadius: BorderRadius.circular(5)),
//         child: Row(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             Image.asset(iconPath, height: 25),
//             Text(
//               text,
//               style: TextStyle(fontSize: 12.0, color: textColor ?? borderColor),
//             )
//           ],
//         ),
//       ),
//     );
//   }
//
//   Widget dropdown(String hint, String? selectedValue, List<String> items,
//       ValueChanged<String?> onChanged) {
//     return Container(
//       height: size.height * 0.05,
//       width: size.width,
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         border: Border.all(color: Colors.grey),
//         borderRadius: BorderRadius.circular(8),
//       ),
//       child: DropdownButton<String>(
//         value: selectedValue,
//         isExpanded: true,
//         hint: Text(
//           hint,
//           style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
//         ),
//         underline: const SizedBox(),
//         icon: Image.asset(
//           'assets/images/down-arrow.png',
//           height: 15,
//           width: 15,
//         ),
//         onChanged: onChanged,
//         items: items.map((String value) {
//           return DropdownMenuItem<String>(
//             value: value,
//             child: Text(value),
//           );
//         }).toList(),
//       ),
//     );
//   }
//
//   Widget text(String? text) {
//     return Padding(
//       padding: const EdgeInsets.only(top: 10.0, bottom: 10),
//       child: RichText(
//         text: TextSpan(
//           children: [
//             TextSpan(
//               text: text ?? '',
//               style: const TextStyle(
//                 fontSize: 14,
//                 fontFamily: "LexendRegular",
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black,
//               ),
//             ),
//             const TextSpan(
//               text: '*',
//               style: TextStyle(
//                 fontSize: 14,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.red,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
