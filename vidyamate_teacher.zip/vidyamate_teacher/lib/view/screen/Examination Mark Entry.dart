import 'package:flutter/material.dart';

class MarkEntry extends StatefulWidget {
  const MarkEntry({super.key});

  @override
  State<MarkEntry> createState() => _MarkEntryState();
}

class _MarkEntryState extends State<MarkEntry> {
  late Size size; /////////////////////
  @override
  Widget build(BuildContext context) {
    DateTime? _eventStartDate;
    DateTime? _eventEndDate;
    Future<void> _selectDate(BuildContext context, bool isStartDate) async {
      DateTime initialDate = DateTime.now();
      DateTime firstDate = DateTime(2000);
      DateTime lastDate = DateTime(2100);

      final DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: isStartDate && _eventStartDate != null
            ? _eventStartDate!
            : (!isStartDate && _eventEndDate != null)
                ? _eventEndDate!
                : initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
      );

      if (pickedDate != null) {
        setState(() {
          if (isStartDate) {
            _eventStartDate = pickedDate;
          } else {
            _eventEndDate = pickedDate;
          }
        });
      }
    }

    String? SelectClass;
    final List<String> Option = ['abc', 'efg', 'hij', 'klm', 'nop'];

    String? selectedClass;
    String? selectedDay;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];
    size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Row(
                children: [
                  Builder(builder: (context) {
                    return InkWell(
                      onTap: () {
                        Scaffold.of(context).openDrawer();
                      },
                      onLongPress: () {},
                      child: SizedBox(
                          height: size.height * 0.050,
                          width: size.width * 0.075,
                          child: Image.asset(
                            'assets/images/hamburger-menu.png',
                          )),
                    );
                  }),
                  const SizedBox(
                    width: 20,
                  ),
                  const Text(
                    "Mark Entry",
                    style: TextStyle(
                        color: Color(0xFF0079EA),
                        fontSize: 20,
                        fontWeight: FontWeight.bold),
                  )
                ],
              ),
            ),
          ),
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: size.height * 0.050,
                  width: size.width * 0.25,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Color(0xFFD4D4D4)),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/eye.png',
                        height: 25,
                      ),
                      const Text(
                        "View",
                        style: TextStyle(
                          color: Color(0xFFD4D4D4),
                          fontSize: 12.0,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: size.height * 0.050,
                  width: size.width * 0.25,
                  decoration: BoxDecoration(
                      border:
                          Border.all(width: 1, color: const Color(0xFF0079EA)),
                      color: Color(0xFF0079EA),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/plus.png',
                        height: 25,
                      ),
                      const Text(
                        "Save",
                        style: TextStyle(fontSize: 12.0, color: Colors.white),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: size.height * 0.050,
                  width: size.width * 0.25,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.red),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/clear.png',
                        height: 25,
                      ),
                      const Text(
                        "Clear",
                        style: TextStyle(
                          color: Colors.red,
                          fontSize: 12.0,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10),
              width: size.width,
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
                  borderRadius: BorderRadius.circular(10)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  text("Class", 0),
                  Dropdown("Select Class", SelectClass, Option,
                      (newValue) => setState(() => SelectClass = newValue)),
                  SizedBox(
                    height: 10,
                  ),
                  text("Exam", 0),
                  Dropdown("Exam", SelectClass, Option,
                      (newValue) => setState(() => SelectClass = newValue)),
                  SizedBox(
                    height: 10,
                  ),
                  text("Category", 0),
                  Dropdown("Category", SelectClass, Option,
                      (newValue) => setState(() => SelectClass = newValue))
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10),
              width: size.width,
              decoration: BoxDecoration(
                  color: Color(0xFFF9F9F9),
                  border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text("Roll No."),
                  Text("Student Name"),
                  Text("Max Mark [20]")
                ],
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              padding: EdgeInsets.all(10),
              width: size.width,
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
                  borderRadius: BorderRadius.circular(10)),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    children: [
                      Text("023"),
                    ],
                  ),
                  Column(
                    children: [
                      Container(
                        height: size.height * 0.08,
                        width: size.width * 0.4,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          // White background for the container
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: DropdownButton<String>(
                          value: SelectClass,
                          isExpanded: true,
                          hint: Text(
                            "Enter Student Name",
                            style: const TextStyle(
                                color: Color(0xFF989292), fontSize: 12),
                          ),
                          underline: const SizedBox(),
                          icon: Image.asset(
                            'assets/images/down-arrow.png',
                            height: 15,
                            width: 15,
                          ),
                          onChanged: (newValue) =>
                              setState(() => SelectClass = newValue),
                          items: Option.map((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Container(
                                color: Colors.white,
                                // White background for dropdown items
                                child: Text(value),
                              ),
                            );
                          }).toList(),
                          dropdownColor: Colors
                              .white, // White background for the dropdown menu
                        ),
                      ),
                    ],
                  ),
                  Column(
                    children: [
                      Text("English"),
                      textFormField("English", size, 0.2),
                      SizedBox(
                        height: 5,
                      ),
                      Text("Maths"),
                      textFormField("Maths", size, 0.2),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: const TextStyle(
                fontSize: 14,
                fontFamily: "LexendRegular",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            if (value == 1) // Use collection if syntax for conditionals
              TextSpan(
                text: '*',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Container(
          width: size.width * value,
          height: size.height * 0.05,
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFFD4D4D4)),
            borderRadius: BorderRadius.circular(11),
          ),
          child: TextFormField(
            textAlign: TextAlign.center,
            textAlignVertical: TextAlignVertical.center,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.only(bottom: 18),
              hintText: hintText,
              hintStyle: TextStyle(
                color: Color(0xFF989292),
                fontSize: 12,
              ),
              border: InputBorder.none,
            ),
            // validator: (value) {
            //   if (value == null || value.isEmpty) {
            //     return 'Please enter some text';
            //   }
            //   return null;
            // },
          ),
        ),
      ],
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white, // White background for the container
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.white, // White background for dropdown items
              child: Text(value),
            ),
          );
        }).toList(),
        dropdownColor: Colors.white, // White background for the dropdown menu
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// import 'package:vidyamate_teacher/view/screen/Student%20Subject%20Mapping.dart';
//
// class Examination extends StatefulWidget {
//   const Examination({super.key});
//
//   @override
//   State<Examination> createState() => _ExaminationState();
// }
//
// late Size size;
// String? SelectClass;
// final List<String> Option = ['abc', 'efg', 'hij', 'klm', 'nop'];
//
// class _ExaminationState extends State<Examination> {
//   @override
//   Widget build(BuildContext context) {
//     size = MediaQuery.of(context).size;
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: const Text(
//           "Examination",
//           style: TextStyle(
//               fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
//         ),
//         flexibleSpace: Container(
//           decoration: const BoxDecoration(
//             gradient: LinearGradient(
//               begin: Alignment.topCenter,
//               end: Alignment.bottomCenter,
//               colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
//             ),
//           ),
//         ),
//       ),
//       body: Column(
//         children: [
//           Row(
//             mainAxisAlignment: MainAxisAlignment.start,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(15.0),
//                 child: Text(
//                   "Mark Entry",
//                   style: TextStyle(
//                       fontFamily: "LexendRegular",
//                       fontSize: 18,
//                       color: Colors.blue),
//                 ),
//               ),
//             ],
//           ),
//           Row(
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Container(
//                   height: size.height * 0.050,
//                   width: size.width * 0.25,
//                   decoration: BoxDecoration(
//                       border: Border.all(width: 1, color: Color(0xFFD4D4D4)),
//                       borderRadius: BorderRadius.circular(5)),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                     children: [
//                       Image.asset(
//                         'assets/images/eye.png',
//                         height: 25,
//                       ),
//                       const Text(
//                         "View",
//                         style: TextStyle(
//                           color: Color(0xFFD4D4D4),
//                           fontSize: 12.0,
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Container(
//                   height: size.height * 0.050,
//                   width: size.width * 0.25,
//                   decoration: BoxDecoration(
//                       border:
//                           Border.all(width: 1, color: const Color(0xFF0079EA)),
//                       color: Color(0xFF0079EA),
//                       borderRadius: BorderRadius.circular(5)),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                     children: [
//                       Image.asset(
//                         'assets/images/plus.png',
//                         height: 25,
//                       ),
//                       const Text(
//                         "Save",
//                         style: TextStyle(fontSize: 12.0, color: Colors.white),
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: Container(
//                   height: size.height * 0.050,
//                   width: size.width * 0.25,
//                   decoration: BoxDecoration(
//                       border: Border.all(width: 1, color: Colors.red),
//                       borderRadius: BorderRadius.circular(5)),
//                   child: Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                     children: [
//                       Image.asset(
//                         'assets/images/clear.png',
//                         height: 25,
//                       ),
//                       const Text(
//                         "Clear",
//                         style: TextStyle(
//                           color: Colors.red,
//                           fontSize: 12.0,
//                         ),
//                       )
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: EdgeInsets.all(10),
//               width: size.width,
//               decoration: BoxDecoration(
//                   border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
//                   borderRadius: BorderRadius.circular(10)),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   text("Class"),
//                   Dropdown("Select Class", SelectClass, Option,
//                       (newValue) => setState(() => SelectClass = newValue)),
//                   SizedBox(
//                     height: 10,
//                   ),
//                   text("Exam"),
//                   Dropdown("Exam", SelectClass, Option,
//                       (newValue) => setState(() => SelectClass = newValue)),
//                   SizedBox(
//                     height: 10,
//                   ),
//                   text("Category"),
//                   Dropdown("Category", SelectClass, Option,
//                       (newValue) => setState(() => SelectClass = newValue))
//                 ],
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: EdgeInsets.all(10),
//               width: size.width,
//               decoration: BoxDecoration(
//                   color: Color(0xFFF9F9F9),
//                   border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
//                   borderRadius: BorderRadius.circular(10)),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 children: [
//                   Text("Roll No."),
//                   Text("Student Name"),
//                   Text("Max Mark [20]")
//                 ],
//               ),
//             ),
//           ),
//           Padding(
//             padding: const EdgeInsets.all(10.0),
//             child: Container(
//               padding: EdgeInsets.all(10),
//               width: size.width,
//               decoration: BoxDecoration(
//                   border: Border.all(width: 1, color: Color(0xFFD9D9D9)),
//                   borderRadius: BorderRadius.circular(10)),
//               child: Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceAround,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Column(
//                     children: [
//                       Text("023"),
//                     ],
//                   ),
//                   Column(
//                     children: [
//                       Container(
//                         height: size.height * 0.08,
//                         width: size.width * 0.4,
//                         padding: const EdgeInsets.symmetric(
//                             horizontal: 12, vertical: 4),
//                         decoration: BoxDecoration(
//                           color: Colors.white,
//                           // White background for the container
//                           border: Border.all(color: Colors.grey),
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                         child: DropdownButton<String>(
//                           value: SelectClass,
//                           isExpanded: true,
//                           hint: Text(
//                             "Enter Student Name",
//                             style: const TextStyle(
//                                 color: Color(0xFF989292), fontSize: 12),
//                           ),
//                           underline: const SizedBox(),
//                           icon: Image.asset(
//                             'assets/images/down-arrow.png',
//                             height: 15,
//                             width: 15,
//                           ),
//                           onChanged: (newValue) =>
//                               setState(() => SelectClass = newValue),
//                           items: Option.map((String value) {
//                             return DropdownMenuItem<String>(
//                               value: value,
//                               child: Container(
//                                 color: Colors.white,
//                                 // White background for dropdown items
//                                 child: Text(value),
//                               ),
//                             );
//                           }).toList(),
//                           dropdownColor: Colors
//                               .white, // White background for the dropdown menu
//                         ),
//                       ),
//                     ],
//                   ),
//                   Column(
//                     children: [
//                       Text("English"),
//                       textFormField("English", size, 0.2),
//                       SizedBox(
//                         height: 5,
//                       ),
//                       Text("Maths"),
//                       textFormField("Maths", size, 0.2),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
//
//   Widget textFormField(String? hintText, Size size, double value) {
//     return Row(
//       children: [
//         Container(
//           width: size.width * value,
//           height: size.height * 0.05,
//           decoration: BoxDecoration(
//             border: Border.all(color: Color(0xFFD4D4D4)),
//             borderRadius: BorderRadius.circular(11),
//           ),
//           child: TextFormField(
//             textAlign: TextAlign.center,
//             textAlignVertical: TextAlignVertical.center,
//             decoration: InputDecoration(
//               contentPadding: EdgeInsets.only(bottom: 18),
//               hintText: hintText,
//               hintStyle: TextStyle(
//                 color: Color(0xFF989292),
//                 fontSize: 12,
//               ),
//               border: InputBorder.none,
//             ),
//             // validator: (value) {
//             //   if (value == null || value.isEmpty) {
//             //     return 'Please enter some text';
//             //   }
//             //   return null;
//             // },
//           ),
//         ),
//       ],
//     );
//   }
//
//   Widget Dropdown(String hint, String? selectedValue, List<String> items,
//       ValueChanged<String?> onChanged) {
//     return Container(
//       height: size.height * 0.05,
//       width: size.width,
//       padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
//       decoration: BoxDecoration(
//         color: Colors.white, // White background for the container
//         border: Border.all(color: Colors.grey),
//         borderRadius: BorderRadius.circular(8),
//       ),
//       child: DropdownButton<String>(
//         value: selectedValue,
//         isExpanded: true,
//         hint: Text(
//           hint,
//           style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
//         ),
//         underline: const SizedBox(),
//         icon: Image.asset(
//           'assets/images/down-arrow.png',
//           height: 15,
//           width: 15,
//         ),
//         onChanged: onChanged,
//         items: items.map((String value) {
//           return DropdownMenuItem<String>(
//             value: value,
//             child: Container(
//               color: Colors.white, // White background for dropdown items
//               child: Text(value),
//             ),
//           );
//         }).toList(),
//         dropdownColor: Colors.white, // White background for the dropdown menu
//       ),
//     );
//   }
//
//   Widget text(String? text) {
//     return Padding(
//       padding: const EdgeInsets.only(top: 10.0, bottom: 10),
//       child: RichText(
//         text: TextSpan(
//           children: [
//             TextSpan(
//               text: text ?? '',
//               style: TextStyle(
//                 fontSize: 14,
//                 fontFamily: "LexendReguler",
//                 fontWeight: FontWeight.bold,
//                 color: Colors.black,
//               ),
//             ),
//             TextSpan(
//               text: '*',
//               style: TextStyle(
//                 fontSize: 14,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.red,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
