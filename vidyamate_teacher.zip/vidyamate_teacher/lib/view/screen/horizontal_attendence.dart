import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:vidyamate_teacher/resources/my_assets.dart';

import '../../controller/dashboard_controller.dart';

class HorizontalAttendenceListView extends StatefulWidget {
  @override
  _HorizontalAttendenceListViewState createState() =>
      _HorizontalAttendenceListViewState();
}

class _HorizontalAttendenceListViewState
    extends State<HorizontalAttendenceListView> {
  final DashboardController dashboardController =
      Get.put(DashboardController());

  final PageController _pageController = PageController();
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Column(
      children: [
        Container(
          height: 105,
          // padding: EdgeInsets.all(10),
          child: GetBuilder<DashboardController>(
            builder: (controller) {
              if (controller.circulrsList.isEmpty) {
                return Center(child: Text("No circulars available."));
              }
              return PageView.builder(
                controller: _pageController,
                itemCount: controller.circulrsList.length,
                onPageChanged: (int index) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      // _showCircularDetailsDialog(circular);
                    },
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue.shade50,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: LayoutBuilder(
                        builder: (context, constraints) {
                          bool isWideScreen = constraints.maxWidth > 400;
                          return Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "My Attendence",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 10),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      children: [
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'In Time',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xFF969191),
                                                ),
                                              ),
                                              Row(
                                                children: [
                                                  Image(
                                                    image: intimeClock,
                                                    height: 16,
                                                    width: 16,
                                                  ),
                                                  SizedBox(width: 5),
                                                  Text(
                                                    '5.00 PM',
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                        SizedBox(width: 20),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                'Out Time',
                                                style: TextStyle(
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.bold,
                                                  color: Color(0xFF969191),
                                                ),
                                              ),
                                              Row(
                                                children: [
                                                  Image(
                                                    image: outTimeClock,
                                                    height: 16,
                                                    width: 16,
                                                  ),
                                                  SizedBox(width: 5),
                                                  Text(
                                                    '8.00 AM',
                                                    style: TextStyle(
                                                      fontSize: 14,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              if (isWideScreen) ...[
                                SizedBox(width: 20),
                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  mainAxisSize: MainAxisSize.max,
                                  children: [
                                    Image(
                                      image: fingurePrint,
                                      height: 60,
                                      width: 60,
                                    ),
                                  ],
                                ),
                              ] else ...[
                                // On smaller screens, place the fingerprint image below the attendance details
                                SizedBox(height: 16),
                                Center(
                                  child: Image(
                                    image: fingurePrint,
                                    height: 60,
                                    width: 60,
                                  ),
                                ),
                              ],
                            ],
                          );
                        },
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ),
        SizedBox(
          height: size.height * 0.02,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            dashboardController.circulrsList.length,
            (index) => AnimatedContainer(
              duration: Duration(milliseconds: 300),
              margin: EdgeInsets.symmetric(horizontal: 4),
              width: 20,
              height: 5,
              decoration: BoxDecoration(
                color: _currentIndex == index
                    ? Color(0xff0082E1)
                    : Colors.grey[400],
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.all(Radius.circular(10)),
              ),
            ),
          ),
        ),
      ],
    );
  }

  String getTimeDifference(String noticeDate) {
    DateTime now = DateTime.now();
    DateTime date = DateTime.parse(noticeDate);
    Duration difference = now.difference(date);
    int days = difference.inDays;

    if (days == 0) {
      return "Today";
    } else if (days == 1) {
      return "1 day ago";
    } else {
      return "$days days ago";
    }
  }
}
