import 'package:flutter/material.dart';

class HostelReports extends StatefulWidget {
  const HostelReports({super.key});

  @override
  State<HostelReports> createState() => _HostelReportsState();
}

class _HostelReportsState extends State<HostelReports> {
  late Size size; /////////////////////
  @override
  Widget build(BuildContext context) {
    String? selectedClass;
    String? SelectHostel;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];
    size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  children: [
                    Builder(builder: (context) {
                      return InkWell(
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        },
                        onLongPress: () {},
                        child: SizedBox(
                            height: size.height * 0.050,
                            width: size.width * 0.075,
                            child: Image.asset(
                              'assets/images/hamburger-menu.png',
                            )),
                      );
                    }),
                    const SizedBox(
                      width: 20,
                    ),
                    const Text(
                      "Hostel Reports",
                      style: TextStyle(
                          fontFamily: "LexendRegular",
                          color: Color(0xFF0079EA),
                          fontSize: 17,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Event Start Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Select Hostel",
                              style: TextStyle(
                                  fontFamily: "LexendRegular", fontSize: 12),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            dropdown(
                                "All",
                                SelectHostel,
                                classOptions,
                                (newValue) =>
                                    setState(() => selectedClass = newValue),
                                0.4)
                          ],
                        ),

                        // Event End Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Student Type",
                              style: TextStyle(
                                fontFamily: "LexendRegular",
                                fontSize: 12,
                              ),
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            dropdown(
                                "Regular",
                                SelectHostel,
                                classOptions,
                                (newValue) =>
                                    setState(() => selectedClass = newValue),
                                0.4)
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Text(
                      "Bed Type",
                      style: TextStyle(
                        fontFamily: "LexendRegular",
                        fontSize: 12,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    dropdown(
                        "Occupied",
                        selectedClass,
                        classOptions,
                        (newValue) => setState(() => selectedClass = newValue),
                        0.9),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: size.height * 0.050,
                          width: size.width * 0.28,
                          decoration: BoxDecoration(
                              border: Border.all(
                                  width: 1, color: Color(0xFFD4D4D4)),
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Image.asset(
                                "assets/images/eye.png",
                                height: 25,
                              ),
                              const Text(
                                "View",
                                style: TextStyle(
                                  fontSize: 12.0,
                                  color: Colors.black38,
                                  fontFamily: "LexendRegular",
                                ),
                              )
                            ],
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          margin: EdgeInsets.only(top: 10),
                          height: size.height * 0.050,
                          width: size.width * 0.28,
                          decoration: BoxDecoration(
                              border: Border.all(width: 1, color: Colors.red),
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Image.asset(
                                "assets/images/clear.png",
                                height: 25,
                              ),
                              const Text(
                                "Clear",
                                style: TextStyle(
                                  fontSize: 12.0,
                                  color: Colors.red,
                                  fontFamily: "LexendRegular",
                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ],
                )),
            SizedBox(
              height: 20,
            ),
            Container(
                width: size.width,
                height: size.height * 0.2,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Hostel Reports",
                      style: TextStyle(
                        fontSize: 17,
                        color: Color(0xFF0079EA),
                        fontFamily: "LexendRegular",
                      ),
                    )
                  ],
                )),
            SizedBox(
              height: 10,
            ),

            // Row(
            //   mainAxisAlignment: MainAxisAlignment.end,
            //   children: [
            //     Center(
            //       child: Container(
            //         height: size.height * 0.050,
            //         width: size.width * 0.3,
            //         decoration: BoxDecoration(
            //             border: Border.all(width: 1, color: Color(0xFFD4D4D4)),
            //             color: Color(0xFF0DA800),
            //             borderRadius: BorderRadius.circular(5)),
            //         child: Row(
            //           mainAxisAlignment: MainAxisAlignment.center,
            //           children: [
            //             // Image.asset(
            //             //   'assets/images/eye.png',
            //             //   height: 25,
            //             // ),
            //             const Text(
            //               "Export",
            //               style: TextStyle(fontSize: 14.0, color: Colors.white),
            //             )
            //           ],
            //         ),
            //       ),
            //     ),
            //   ],
            // ),

            Text(
              "Hostel Name : IMT Boys Hostel",
              style: TextStyle(
                color: Color(0xFF0DA800),
                fontFamily: "LexendRegular",
              ),
            ),
            Row(
              children: [
                Image.asset(
                  "assets/images/right-arrow.png",
                  height: 15,
                  width: 15,
                ),
                Text(
                  "Floor-1 RoomNo-1 ( Total Bed :-1)",
                  style: TextStyle(
                    color: Color(0xFF0079EA),
                    fontFamily: "LexendRegular",
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Color(0xFFECF1FF),
                borderRadius: BorderRadius.circular(10),
                // Optional rounded corners
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2), // Shadow color
                    blurRadius: 10, // Softness of the shadow
                    spreadRadius: 2, // Extend the shadow
                    offset: Offset(0, 5), // Horizontal and vertical offset
                  ),
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Reciept No.  :",
                        style: TextStyle(
                            fontFamily: "LexendRegular",
                            color: Color(0xFF000000),
                            fontSize: 12),
                      ),
                      Text(
                        "1",
                        style: TextStyle(
                            fontFamily: "LexendRegular",
                            color: Color(0xFF444444),
                            fontSize: 11),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Student No. :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("0079EA",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Student\nAddress",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Pune",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Mess",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Yes",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Fees",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("12000",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Bed No.",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("1-1-1",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Student Name",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Monesh Roy",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Parent\nName",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Navin Roy",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Start Date",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("12-10-24",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("No. of Installments",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("1",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Student  Type",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Regular",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Student\nContact No.",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("8956231047",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Parent’s\nContact No.",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("9632584105",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("End Date",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Is Allotted",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Yes",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged, double value) {
    return Container(
      height: size.height * 0.05,
      width: size.width * value,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xFFD4D4D4)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(
              value,
              style: TextStyle(
                fontFamily: "LexendRegular",
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _actionButton(String text, Icon iconPath, Color borderColor,
      {Color? backgroundColor, Color? textColor}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: size.height * 0.050,
        width: size.width * 0.25,
        decoration: BoxDecoration(
            border: Border.all(width: 1, color: borderColor),
            color: backgroundColor ?? Colors.transparent,
            borderRadius: BorderRadius.circular(5)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            iconPath,
            Text(
              text,
              style: TextStyle(fontSize: 12.0, color: textColor ?? borderColor),
            )
          ],
        ),
      ),
    );
  }
}
