import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'Absent Students.dart';
import 'Attendance list.dart';
import 'Present Students.dart';

class Attendance extends StatefulWidget {
  const Attendance({super.key});

  @override
  State<Attendance> createState() => _AttendanceState();
}

class _AttendanceState extends State<Attendance> {
  DateTime? selectedDate;
  late Size size;
  String? selectedClass = "Class VII";
  String? selectMonth;
  String? selectYear;
  final List<String> month = ['abc', 'efg', 'hij', 'klm', 'nop'];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Attendance",
          style: TextStyle(
              fontFamily: 'LexendRegular', fontWeight: FontWeight.bold),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0x77EDC7FF), Color(0xFFAADBFF)])),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Padding(
              padding: EdgeInsets.only(top: 10.0, bottom: 10),
              child: Center(
                child: Text(
                  'Choose your class and select the date for roll call',
                  style: TextStyle(fontSize: 13, fontFamily: 'LexendRegular'),
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: size.width * 0.4,
                  height: size.height * 0.05,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: const Color(0xFFECF1FF),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1), // Shadow color
                        spreadRadius: 2, // Spread radius of the shadow
                        blurRadius: 6, // Blur radius for smoothness
                        offset: const Offset(0, 4), // Shadow position offset
                      ),
                    ],
                  ),
                  child: DropdownButton<String>(
                    isExpanded: true,
                    underline: const SizedBox(),
                    value: selectedClass,
                    items: const [
                      DropdownMenuItem(
                        value: "Class VII",
                        child: Text("Class VII",
                            style: TextStyle(
                                fontFamily: 'LexendRegular', fontSize: 12)),
                      ),
                      DropdownMenuItem(
                        value: "Class VIII",
                        child: Text("Class VIII",
                            style: TextStyle(
                                fontFamily: 'LexendRegular', fontSize: 12)),
                      ),
                      DropdownMenuItem(
                        value: "Class IX",
                        child: Text("Class IX",
                            style: TextStyle(
                                fontFamily: 'LegendRegular', fontSize: 12)),
                      ),
                    ],
                    icon: Image.asset(
                      'assets/images/down-arrow.png',
                      height: 15,
                      width: 15,
                    ),
                    onChanged: (value) {
                      setState(() {
                        selectedClass = value;
                      });
                    },
                  ),
                ),
                SizedBox(width: size.width * 0.05),
                GestureDetector(
                  onTap: () async {
                    final DateTime? picked = await showDatePicker(
                      context: context,
                      initialDate: selectedDate ?? DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                    );
                    if (picked != null && picked != selectedDate) {
                      setState(() {
                        selectedDate = picked;
                      });
                    }
                  },
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.grey.shade400),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 4),
                          child: Text(
                            selectedDate == null
                                ? DateFormat('dd MMM yyyy')
                                    .format(DateTime.now())
                                : DateFormat('dd MMM yyyy')
                                    .format(selectedDate!),
                            style: const TextStyle(
                                fontSize: 14,
                                color: Colors.black87,
                                fontWeight: FontWeight.w400,
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Image.asset(
                          "assets/images/calendar.png",
                          height: 20,
                          width: 20,
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatCard("Total", "40", "assets/images/Total.png",
                    const AttendanceListPage()),
                _buildStatCard("Present", "00", "assets/images/Present.png",
                    const PresentStudentsPage()),
                _buildStatCard("Absent", "00", "assets/images/Absent.png",
                    const AbsentStudents()),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              height: size.height * 0.050,
              width: size.width * 0.82,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFF0DA800),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Text(
                    "Take Attendance",
                    style: TextStyle(
                      color: Colors.white,
                      fontFamily: 'LegendRegular',
                      fontSize: 15.0,
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Row(
              children: [
                Text(
                  "Generate Attendance Report",
                  style: TextStyle(fontSize: 16, fontFamily: "LexendRegular"),
                ),
              ],
            ),
            Container(
              width: size.width,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                // Optional rounded corners
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5), // Shadow color
                    spreadRadius: 5, // Spread radius
                    blurRadius: 7, // Blur radius
                    offset: const Offset(
                        0, 3), // Changes the position of shadow (x, y)
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Select Month",
                              style: TextStyle(
                                  color: Color(
                                    0xFF9A9A9A,
                                  ),
                                  fontSize: 12),
                            ),
                            Dropdown(
                                "Select Month",
                                selectMonth,
                                month,
                                (newValue) =>
                                    setState(() => selectMonth = newValue)),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text("Select Year",
                                style: TextStyle(
                                    color: Color(0xFF9A9A9A), fontSize: 12)),
                            Dropdown(
                                "Select Year",
                                selectYear,
                                month,
                                (newValue) =>
                                    setState(() => selectMonth = newValue)),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            // Add your button functionality here
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(
                                0xFF0079EA), // Set the button's background color
                          ),
                          child: const Text(
                            "Generate",
                            style: TextStyle(color: Colors.white),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.38,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white, // White background for the container
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.white, // White background for dropdown items
              child: Text(value),
            ),
          );
        }).toList(),
        dropdownColor: Colors.white, // White background for the dropdown menu
      ),
    );
  }

  Widget _buildStatCard(
      String title, String count, String imagePath, Widget destinationPage) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => destinationPage,
          ),
        );
      },
      child: Column(
        children: [
          Container(
            height: size.height * 0.15,
            width: size.width * 0.27,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              color: const Color(0xFFF5E5F8),
              border: Border.all(
                color: const Color(0xFFF6D0F6),
                width: 3,
              ),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(imagePath, height: size.height * 0.05),
                const SizedBox(height: 8),
                Text(title,
                    style: TextStyle(
                        fontSize: size.width * 0.04,
                        fontFamily: 'LexendRegular',
                        color: const Color(0XFF444444))),
                Text(
                  count,
                  style: TextStyle(
                    fontSize: size.width * 0.045,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'LegendRegular',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
