import 'package:flutter/material.dart';
import 'package:vidyamate_teacher/view/screen/Create%20Mock%20Test.dart';

class MockTest extends StatefulWidget {
  const MockTest({super.key});

  @override
  State<MockTest> createState() => _MockTestState();
}

class _MockTestState extends State<MockTest> {
  late Size size;
  String? selectedClass;
  String? SelectDay;
  String? SelectSubject;
  String? Title;
  String? selectedDay;
  bool isVideoClicked = false;
  bool isAudioClicked = false;

  final List<String> classOptions = ['10th A', '10th B', '10th C'];
  final List<String> dayOptions = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday'
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xffF9FAFB),
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Mock Test",
          style: TextStyle(
              fontWeight: FontWeight.bold,
              fontFamily: 'LexendRegular',
              fontSize: 18),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)])),
        ),
      ),
      body: SingleChildScrollView(
        // Wrap with SingleChildScrollView
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 20.0,
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: GestureDetector(
                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => CreateMockTest()));
                            },
                            child: Container(
                              height: size.height * 0.050,
                              width: size.width * 0.35,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 1, color: const Color(0xFF0079EA)),
                                  color: const Color(0xFF0079EA),
                                  borderRadius: BorderRadius.circular(5)),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Image.asset(
                                    'assets/images/plus.png',
                                    height: 25,
                                  ),
                                  const Text(
                                    "Create Mock Test",
                                    style: TextStyle(
                                        fontSize: 10.0,
                                        color: Colors.white,
                                        fontFamily: 'LexendRegular'),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: GestureDetector(
                            onTap: () {
                              // Handle Reset Filter action here
                              print('Reset Filter clicked');
                            },
                            child: Container(
                              height: size.height * 0.050,
                              width: size.width * 0.35,
                              decoration: BoxDecoration(
                                  color: Colors.white,
                                  border:
                                      Border.all(width: 1, color: Colors.red),
                                  borderRadius: BorderRadius.zero),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  Image.asset(
                                    'assets/images/clear.png',
                                    height: 25,
                                  ),
                                  const Text(
                                    "Reset Filter",
                                    style: TextStyle(
                                      color: Colors.red,
                                      fontFamily: 'LexendRegular',
                                      fontSize: 10.0,
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Row(
                      children: [
                        DropdownSection(),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.88,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xFFD4D4D4), width: 1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(
              value,
              style: TextStyle(
                  fontSize: 14,
                  fontFamily: "LexendReguler",
                  color: Color(0xff989292)),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget DropdownSection() {
    return Container(
      child: Column(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Select Class Dropdown
              text("Select Class", 1),
              Dropdown("Select Class", selectedClass, classOptions,
                  (newValue) => setState(() => selectedClass = newValue)),

              text("Select Subject ", 1),
              Dropdown("Select Subject", SelectDay, dayOptions,
                  (newValue) => setState(() => SelectDay = newValue)),
              text("Chapter", 1),
              Dropdown("Select Chapter Name ", SelectSubject, dayOptions,
                  (newValue) => setState(() => SelectSubject = newValue)),
              const SizedBox(height: 10),
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: size.width * 0.32,
                width: size.width * 0.85,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 5, bottom: 10),
                          child: Text(
                            'ACTIVE TESTS',
                            style: TextStyle(
                                fontSize: 15,
                                color: Color(0xff1E5CE1),
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 20, left: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Test Name',
                                style: TextStyle(
                                    fontSize: 10,
                                    color: Color(0xFF444444),
                                    fontFamily: 'LexendRegular'),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Class',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF444444),
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Subject',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF444444),
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Chapter',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF444444),
                                      fontFamily: 'LexendRegular')),
                            ],
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10),
                      child: Divider(),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 20, left: 20, bottom: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Mock Test 1',
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'LexendRegular'),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('8th',
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('History',
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Cold War',
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'LexendRegular')),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                height: size.width * 0.32,
                width: size.width * 0.85,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 5, bottom: 10),
                          child: Text(
                            'IN-ACTIVE TESTS',
                            style: TextStyle(
                                fontSize: 15,
                                color: Color(0xff1E5CE1),
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                        right: 20,
                        left: 20,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Test Name',
                                style: TextStyle(
                                    color: Color(0xFF444444),
                                    fontSize: 10,
                                    fontFamily: 'LexendRegular'),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Class',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF444444),
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Subject',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF444444),
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Chapter',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: Color(0xFF444444),
                                      fontFamily: 'LexendRegular')),
                            ],
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10),
                      child: Divider(),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 20, left: 20, bottom: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Mock Test 1',
                                style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'LexendRegular'),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('9th',
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Science',
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Life Cycle',
                                  style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'LexendRegular')),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              // Display the passed text or an empty string if null
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Color(0xff444444),
              ),
            ),
            if (value == 1)
              TextSpan(
                text: " *",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
