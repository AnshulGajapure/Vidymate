import 'package:flutter/material.dart';

import 'Annual Planner.dart';
import 'Circular.dart';
import 'Events.dart';
import 'Home Work.dart';
import 'School Communication.dart';
import 'Student Subject Mapping.dart';
import 'Syllabus.dart';

class TeacherDesk extends StatefulWidget {
  const TeacherDesk({super.key});

  @override
  State<TeacherDesk> createState() => _TeacherDeskState();
}

class _TeacherDeskState extends State<TeacherDesk> {
  final GlobalKey<ScaffoldState> _key = GlobalKey<ScaffoldState>();
  int _selectedIndex = 0;
  DateTime? _eventStartDate;
  DateTime? _eventEndDate;

  List<Widget> _widgetOptions = <Widget>[];

  late Size size;

  @override
  void initState() {
    // TODO: implement initState
    _widgetOptions = [
      const syllabus(),
      const Circular(),
      const StudentSubjectMapping(),
      const HomeWork(),
      const annualplanner(),
      const SchoolCommunication(),
      const Events(),
    ];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;

    return Scaffold(
      primary: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: const Row(
          children: [
            Text(
              'Teacher Desk',
              style: TextStyle(
                  fontFamily: 'LexendRegular',
                  fontWeight: FontWeight.bold,
                  fontSize: 17),
            ),
          ],
        ),
        centerTitle: true,
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)])),
        ),
      ),
      body: Scaffold(
        key: _key,
        drawer: myDrawer(),
        body: Builder(builder: (context) {
          return _widgetOptions[_selectedIndex];
        }),
      ),
    );
  }

  //

  myDrawer() {
    return SizedBox(
      width: size.width * 0.80,
      child: Drawer(
        child: Builder(builder: (context) {
          return Container(
            color: const Color(0xFFECF1FF),
            child: ListView(
              children: <Widget>[
                Padding(
                  padding: const EdgeInsets.only(top: 50.0, left: 20),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 40.0),
                        child: Image.asset(
                          'assets/images/hamburger-menu.png',
                          height: size.height * 0.088,
                          width: size.width * 0.088,
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.only(left: 20),
                        child: Text(
                          'Timetable',
                          style: TextStyle(
                            fontFamily: 'LexendRegular',
                            color: Colors.black,
                            fontSize: 24,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                    // margin: const EdgeInsets.only(left: 10),
                    child: const Divider()),
                ListTile(
                  dense: true, // Makes the ListTile more compact
                  title: Container(
                    height: size.height * 0.030,
                    // Reduce the height
                    margin: const EdgeInsets.only(left: 50),
                    // Decrease margin for less spacing
                    color: _selectedIndex == 0
                        ? Colors.white
                        : const Color(0xFFECF1FF),
                    alignment: Alignment.centerLeft,
                    // Ensures text is aligned properly
                    child: const Text(
                      'Syllabus',
                      style: TextStyle(
                        fontSize: 14,
                        fontFamily: 'LexendRegular',
                      ), // Smaller font size
                    ),
                  ),
                  onTap: () {
                    _selectedIndex = 0;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                  },
                ),
                ListTile(
                  dense: true, // Makes the ListTile more compact
                  title: Container(
                    height: size.height * 0.030,
                    // Reduce the height
                    margin: const EdgeInsets.only(left: 50),
                    // Decrease margin for less spacing
                    color: _selectedIndex == 1
                        ? Colors.white
                        : const Color(0xFFECF1FF),
                    alignment: Alignment.centerLeft,
                    // Ensures text is aligned properly
                    child: const Text(
                      'Circulars',
                      style: TextStyle(
                        fontSize: 14,
                        fontFamily: 'LexendRegular',
                      ), // Smaller font size
                    ),
                  ),
                  onTap: () {
                    _selectedIndex = 1;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                  },
                ),
                ListTile(
                  // leading: Icon(Icons.settings),
                  title: Container(
                      height: size.height * 0.030,
                      color: _selectedIndex == 2
                          ? Colors.white
                          : const Color(0xFFECF1FF),
                      margin: const EdgeInsets.only(left: 50),
                      child: const Text('Student Subject Mapping',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'LexendRegular',
                          ))),
                  onTap: () {
                    _selectedIndex = 2;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                    // _onDrawerItemTapped(0);
                    // Handle the onTap action for Settings
                  },
                ),
                ListTile(
                  // leading: Icon(Icons.contact_mail),
                  title: Container(
                    height: size.height * 0.030,
                    color: _selectedIndex == 3
                        ? Colors.white
                        : const Color(0xFFECF1FF),
                    margin: const EdgeInsets.only(left: 50),
                    child: const Text('Home Work',
                        style: TextStyle(
                          fontSize: 14,
                          fontFamily: 'LexendRegular',
                        )),
                  ),
                  onTap: () {
                    _selectedIndex = 3;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                    // _onDrawerItemTapped(0);
                    // Handle the onTap action for Contact
                  },
                ),
                ListTile(
                  // leading: Icon(Icons.contact_mail),
                  title: Container(
                      height: size.height * 0.030,
                      color: _selectedIndex == 4
                          ? Colors.white
                          : const Color(0xFFECF1FF),
                      margin: const EdgeInsets.only(left: 50),
                      child: const Text('Annual Planner',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'LexendRegular',
                          ))),
                  onTap: () {
                    _selectedIndex = 4;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                    // _onDrawerItemTapped(0);
                    // Handle the onTap action for Contact
                  },
                ),
                ListTile(
                  // leading: Icon(Icons.contact_mail),
                  title: Container(
                      height: size.height * 0.030,
                      color: _selectedIndex == 5
                          ? Colors.white
                          : const Color(0xFFECF1FF),
                      margin: const EdgeInsets.only(left: 50),
                      child: const Text('School Communication',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'LexendRegular',
                          ))),
                  onTap: () {
                    _selectedIndex = 5;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                    // _onDrawerItemTapped(0);
                    // Handle the onTap action for Contact
                  },
                ),
                ListTile(
                  // leading: Icon(Icons.contact_mail),
                  title: Container(
                      height: size.height * 0.030,
                      color: _selectedIndex == 6
                          ? Colors.white
                          : const Color(0xFFECF1FF),
                      margin: const EdgeInsets.only(left: 50),
                      child: const Text('Events',
                          style: TextStyle(
                            fontSize: 14,
                            fontFamily: 'LexendRegular',
                          ))),
                  onTap: () {
                    _selectedIndex = 6;
                    setState(() {});
                    Scaffold.of(context).closeDrawer();
                    // _onDrawerItemTapped(0);
                    // Handle the onTap action for Contact
                  },
                ),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * value,
            width: size.width * value,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              // Display the passed text or an empty string if null
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Color(0xff444444),
              ),
            ),
            if (value == 1)
              TextSpan(
                text: " *",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context, bool isStartDate) async {
    DateTime initialDate = DateTime.now();
    DateTime firstDate = DateTime(2000);
    DateTime lastDate = DateTime(2100);

    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: isStartDate && _eventStartDate != null
          ? _eventStartDate!
          : (!isStartDate && _eventEndDate != null)
              ? _eventEndDate!
              : initialDate,
      firstDate: firstDate,
      lastDate: lastDate,
    );

    if (pickedDate != null) {
      setState(() {
        if (isStartDate) {
          _eventStartDate = pickedDate;
        } else {
          _eventEndDate = pickedDate;
        }
      });
    }
  }
}
