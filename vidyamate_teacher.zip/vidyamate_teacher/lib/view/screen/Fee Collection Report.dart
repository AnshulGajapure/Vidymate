import 'package:flutter/material.dart';

class FeeCollectionReport extends StatefulWidget {
  const FeeCollectionReport({super.key});

  @override
  State<FeeCollectionReport> createState() => _FeeCollectionReportState();
}

class _FeeCollectionReportState extends State<FeeCollectionReport> {
  late Size size; /////////////////////
  @override
  Widget build(BuildContext context) {
    DateTime? _eventStartDate;
    DateTime? _eventEndDate;
    Future<void> _selectDate(BuildContext context, bool isStartDate) async {
      DateTime initialDate = DateTime.now();
      DateTime firstDate = DateTime(2000);
      DateTime lastDate = DateTime(2100);

      final DateTime? pickedDate = await showDatePicker(
        context: context,
        initialDate: isStartDate && _eventStartDate != null
            ? _eventStartDate!
            : (!isStartDate && _eventEndDate != null)
                ? _eventEndDate!
                : initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
      );

      if (pickedDate != null) {
        setState(() {
          if (isStartDate) {
            _eventStartDate = pickedDate;
          } else {
            _eventEndDate = pickedDate;
          }
        });
      }
    }

    String? selectedClass;
    String? selectedDay;
    final List<String> classOptions = ['10th A', '10th B', '10th C'];
    final List<String> dayOptions = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday'
    ];
    size = MediaQuery.of(context).size;

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Container(
              child: Padding(
                padding: const EdgeInsets.all(4.0),
                child: Row(
                  children: [
                    Builder(builder: (context) {
                      return InkWell(
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        },
                        onLongPress: () {},
                        child: SizedBox(
                            height: size.height * 0.050,
                            width: size.width * 0.075,
                            child: Image.asset(
                              'assets/images/hamburger-menu.png',
                            )),
                      );
                    }),
                    const SizedBox(
                      width: 20,
                    ),
                    const Text(
                      "Fee Collection Report",
                      style: TextStyle(
                        color: Color(0xFF0079EA),
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        fontFamily: "LexendRegular",
                      ),
                    )
                  ],
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Event Start Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            text("From Date", 1),
                            Container(
                              height: size.height * 0.05,
                              width: size.width * 0.40,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFD4D4D4)),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: TextField(
                                readOnly: true,
                                onTap: () => _selectDate(context, true),
                                decoration: InputDecoration(
                                  hintText: _eventStartDate != null
                                      ? "${_eventStartDate!.day}/${_eventStartDate!.month}/${_eventStartDate!.year}"
                                      : "Select Date",
                                  hintStyle: TextStyle(
                                      color: Color(0xFF989292), fontSize: 12),
                                  border: InputBorder.none,
                                  suffixIcon: GestureDetector(
                                    onTap: () => _selectDate(context, true),
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Image.asset(
                                        "assets/images/calendar.png",
                                        height: 15,
                                        width: 15,
                                      ),
                                    ),
                                  ),
                                  contentPadding: EdgeInsets.only(
                                      left: 10, bottom: 12, right: 10),
                                ),
                              ),
                            ),
                          ],
                        ),

                        // Event End Column
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            text("To Date", 1),
                            Container(
                              height: size.height * 0.05,
                              width: size.width * 0.40,
                              decoration: BoxDecoration(
                                border: Border.all(color: Color(0xFFD4D4D4)),
                                borderRadius: BorderRadius.circular(11),
                              ),
                              child: TextField(
                                readOnly: true,
                                onTap: () => _selectDate(context, false),
                                decoration: InputDecoration(
                                  hintText: _eventEndDate != null
                                      ? "${_eventEndDate!.day}/${_eventEndDate!.month}/${_eventEndDate!.year}"
                                      : "Select Date",
                                  hintStyle: TextStyle(
                                      color: Color(0xFF989292), fontSize: 12),
                                  border: InputBorder.none,
                                  suffixIcon: GestureDetector(
                                    onTap: () => _selectDate(context, false),
                                    child: Padding(
                                      padding: const EdgeInsets.all(10.0),
                                      child: Image.asset(
                                        "assets/images/calendar.png",
                                        height: 15,
                                        width: 15,
                                      ),
                                    ),
                                  ),
                                  contentPadding: EdgeInsets.only(
                                      left: 10, bottom: 12, right: 10),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    dropdown("Select Class", selectedClass, classOptions,
                        (newValue) => setState(() => selectedClass = newValue)),
                    SizedBox(
                      height: 20,
                    ),
                    Center(
                      child: Container(
                        height: size.height * 0.050,
                        width: size.width * 0.25,
                        decoration: BoxDecoration(
                            border:
                                Border.all(width: 1, color: Color(0xFFD4D4D4)),
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Image.asset(
                              "assets/images/eye.png",
                              height: 25,
                            ),
                            const Text(
                              "View",
                              style: TextStyle(
                                fontSize: 12.0,
                                color: Colors.black38,
                                fontFamily: "LexendRegular",
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                )),
            SizedBox(
              height: 20,
            ),
            Container(
                width: size.width,
                height: size.height * 0.2,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  border: Border.all(color: const Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Fee Collection Report",
                      style: TextStyle(
                        fontSize: 20,
                        color: Color(0xFF0079EA),
                        fontFamily: "LexendRegular",
                      ),
                    )
                  ],
                )),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Center(
                  child: Container(
                    height: size.height * 0.050,
                    width: size.width * 0.3,
                    decoration: BoxDecoration(
                        border: Border.all(width: 1, color: Color(0xFFD4D4D4)),
                        color: Color(0xFF0DA800),
                        borderRadius: BorderRadius.circular(5)),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Image.asset(
                        //   'assets/images/eye.png',
                        //   height: 25,
                        // ),
                        const Text(
                          "Export",
                          style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.white,
                            fontFamily: "LexendRegular",
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Color(0xFFECF1FF),
                borderRadius: BorderRadius.circular(10),
                // Optional rounded corners
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.2), // Shadow color
                    blurRadius: 10, // Softness of the shadow
                    spreadRadius: 2, // Extend the shadow
                    offset: Offset(0, 5), // Horizontal and vertical offset
                  ),
                ],
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Sr. No. ",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text(
                        "1",
                        style: TextStyle(
                          color: Color(0xFF444444),
                          fontSize: 11,
                          fontFamily: "LexendRegular",
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Reciept Date :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("22-08-24",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Paid Amount",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("1523",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Reciept Date :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("20",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Payment Mode :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Cash",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Name :",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Prithvi Shah",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Text("Payment\nStatus",
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12,
                            fontFamily: "LexendRegular",
                          )),
                      Text("Success",
                          style: TextStyle(
                            color: Color(0xFF444444),
                            fontSize: 11,
                            fontFamily: "LexendRegular",
                          )),
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xFFD4D4D4)),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(
              value,
              style: TextStyle(
                fontFamily: "LexendRegular",
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: const TextStyle(
                fontSize: 12,
                fontFamily: "LexendRegular",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            if (value == 1) // Use collection if syntax for conditionals
              TextSpan(
                text: '*',
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
