import 'package:flutter/material.dart';

class StudentSubjectMapping extends StatefulWidget {
  const StudentSubjectMapping({super.key});

  @override
  State<StudentSubjectMapping> createState() => _StudentSubjectMappingState();
}

late Size size;
final List<String> Options = ['abc', 'efg', 'hij', 'klm', 'nop'];
String? dropDown;

class _StudentSubjectMappingState extends State<StudentSubjectMapping> {
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    // appBar: AppBar(
    //   centerTitle: true,
    //   title: const Text(
    //     "Student Subject Mapping",
    //     style: TextStyle(
    //         fontFamily: 'LexendRegular',
    //         fontWeight: FontWeight.bold,
    //         fontSize: 18),
    //   ),
    //   flexibleSpace: Container(
    //     decoration: const BoxDecoration(
    //         gradient: LinearGradient(
    //             begin: Alignment.topCenter,
    //             end: Alignment.bottomCenter,
    //             colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)])),
    //   ),
    // ),
    return Column(
      children: [
        Container(
          child: Padding(
            padding: const EdgeInsets.all(4.0),
            child: Row(
              children: [
                Builder(builder: (context) {
                  return InkWell(
                    onTap: () {
                      Scaffold.of(context).openDrawer();
                    },
                    onLongPress: () {},
                    child: SizedBox(
                        height: size.height * 0.050,
                        width: size.width * 0.075,
                        child: Image.asset(
                          'assets/images/hamburger-menu.png',
                        )),
                  );
                }),
                const SizedBox(
                  width: 20,
                ),
                const Text(
                  "Student Subject Mapping",
                  style: TextStyle(
                      color: Color(0xFF0079EA),
                      fontSize: 20,
                      fontWeight: FontWeight.bold),
                )
              ],
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(17),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                text("Class Name"),
                Dropdown("Select Class", dropDown, Options,
                    (newValue) => setState(() => dropDown = newValue)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: size.height * 0.040,
                        width: size.width * 0.2,
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 1, color: const Color(0xFF0079EA)),
                            color: Color(0xFF0079EA),
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Image.asset(
                              'assets/images/plus.png',
                              height: 25,
                            ),
                            const Text(
                              "Add",
                              style: TextStyle(
                                  fontSize: 12.0, color: Colors.white),
                            )
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: size.height * 0.040,
                        width: size.width * 0.2,
                        decoration: BoxDecoration(
                            border: Border.all(width: 1, color: Colors.red),
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Image.asset(
                              'assets/images/clear.png',
                              height: 25,
                            ),
                            const Text(
                              "Clear",
                              style: TextStyle(
                                color: Colors.red,
                                fontSize: 12.0,
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  width: size.width,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: const Color(0xFFD4D4D4)),
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "SR NO",
                            style: TextStyle(fontSize: 12),
                          ),
                          Text("STUDENT NUMBER",
                              style: TextStyle(fontSize: 12)),
                          Text("STUDENT NAME", style: TextStyle(fontSize: 12))
                        ],
                      ),
                      Divider(),
                      SizedBox(
                        height: 50,
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * value,
            width: size.width * value,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.050,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }
}
