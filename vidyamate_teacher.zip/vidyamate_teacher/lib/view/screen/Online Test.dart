import 'package:flutter/material.dart';

import 'Create Online Test.dart';

class OnlineTest extends StatefulWidget {
  const OnlineTest({super.key});

  @override
  State<OnlineTest> createState() => _OnlineTestState();
}

class _OnlineTestState extends State<OnlineTest> {
  late Size size;
  String? selectedClass;
  String? SelectDay;
  String? SelectSubject;
  String? Title;
  String? selectedDay;
  bool isVideoClicked = false;
  bool isAudioClicked = false;

  final List<String> classOptions = ['10th A', '10th B', '10th C'];
  final List<String> dayOptions = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday'
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xffF9FAFB),
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Online Test",
          style: TextStyle(
              fontFamily: 'LexendRegular',
              fontWeight: FontWeight.bold,
              fontSize: 17),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)])),
        ),
      ),
      body: SingleChildScrollView(
        // Wrap with SingleChildScrollView
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Container(
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            CreateOnlineTest()));
                              },
                              child: Container(
                                height: size.height * 0.050,
                                width: size.width * 0.29,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 1,
                                        color: const Color(0xFF0079EA)),
                                    color: const Color(0xFF0079EA),
                                    borderRadius: BorderRadius.circular(5)),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Image.asset(
                                      'assets/images/plus.png',
                                      height: 25,
                                    ),
                                    const Text(
                                      "Create Test",
                                      style: TextStyle(
                                          fontSize: 12.0,
                                          color: Colors.white,
                                          fontFamily: 'LexendRegular'),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                print('Reset Filter clicked');
                              },
                              child: Container(
                                height: size.height * 0.050,
                                width: size.width * 0.29,
                                decoration: BoxDecoration(
                                    border:
                                        Border.all(width: 1, color: Colors.red),
                                    borderRadius: BorderRadius.zero),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Image.asset(
                                      'assets/images/clear.png',
                                      height: 25,
                                    ),
                                    const Text(
                                      "Reset Filter",
                                      style: TextStyle(
                                        color: Colors.red,
                                        fontFamily: 'LexendRegular',
                                        fontSize: 12.0,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        children: [
                          Expanded(child: _buildDropdownSection()),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        // Ensure the dropdown button expands to its parent width
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildDropdownSection() {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Select Class Dropdown
          text("Select Class", 0),
          Dropdown("Select Class", selectedClass, classOptions,
              (newValue) => setState(() => selectedClass = newValue)),

          // Select Day Dropdown
          text("Select Subject", 0),

          Dropdown("Select Subject", SelectDay, dayOptions,
              (newValue) => setState(() => SelectDay = newValue)),
          const SizedBox(height: 20),
          Container(
            width: size.width,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
            child: Column(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 5, bottom: 10),
                          child: Text(
                            'ONGOING TEST',
                            style: TextStyle(
                                fontSize: 18,
                                color: Color(0xFF0079EA),
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 20, left: 20, bottom: 20, top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(
                            children: [Text("Ongoing test not found")],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                Divider(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 5, bottom: 10),
                          child: Text(
                            'UPCOMING TEST',
                            style: TextStyle(
                                fontSize: 18,
                                color: Color(0xFF0079EA),
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 20, left: 20, bottom: 20, top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Column(
                            children: [Text("Upcoming test not found")],
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                Divider(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 10, top: 5, bottom: 10),
                          child: Text(
                            'COMPLETED TEST',
                            style: TextStyle(
                                fontSize: 18,
                                color: Color(0xFF0079EA),
                                fontFamily: 'LexendRegular'),
                          ),
                        ),
                      ],
                    ),
                    Padding(
                      padding:
                          const EdgeInsets.only(right: 20, left: 20, bottom: 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Test Name',
                                style: TextStyle(
                                    color: Color(0xFF989292),
                                    fontFamily: 'LexendRegular'),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Class',
                                  style: TextStyle(
                                      color: Color(0xFF989292),
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Subject',
                                  style: TextStyle(
                                      color: Color(0xFF989292),
                                      fontFamily: 'LexendRegular')),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text('Status',
                                  style: TextStyle(
                                      color: Color(0xFF989292),
                                      fontFamily: 'LexendRegular')),
                            ],
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 10.0, right: 10),
                      child: Divider(),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 20, left: 20, bottom: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Unit 3 Test',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                '9th',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Math',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Inactive',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12,
                                    color: Colors.red),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                    Divider(),
                    Padding(
                      padding: const EdgeInsets.only(
                          right: 20, left: 20, bottom: 10),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Unit 3 Test',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                '9th',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Math',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12),
                              ),
                            ],
                          ),
                          Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Text(
                                'Inactive',
                                style: TextStyle(
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'LexendRegular',
                                    fontSize: 12,
                                    color: Colors.red),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),

          // Container(
          //   height: size.width * 0.32,
          //   width: size.width,
          //   decoration: BoxDecoration(
          //       borderRadius: BorderRadius.circular(10),
          //       border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
          //   child: Column(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: [
          //       Row(
          //         children: [
          //           Padding(
          //             padding:
          //                 const EdgeInsets.only(left: 10, top: 5, bottom: 10),
          //             child: Text(
          //               'ONGOING TEST',
          //               style: TextStyle(
          //                   fontSize: 18,
          //                   color: Color(0xFF0079EA),
          //                   fontFamily: 'LexendRegular'),
          //             ),
          //           ),
          //         ],
          //       ),
          //       Padding(
          //         padding: const EdgeInsets.only(
          //             right: 20, left: 20, bottom: 20, top: 15),
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.center,
          //           children: [
          //             Column(
          //               children: [Text("Ongoing test not found")],
          //             )
          //           ],
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
          // SizedBox(
          //   height: 10,
          // ),
          // Container(
          //   height: size.width * 0.32,
          //   width: size.width,
          //   decoration: BoxDecoration(
          //       borderRadius: BorderRadius.circular(10),
          //       border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
          //   child: Column(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: [
          //       Row(
          //         children: [
          //           Padding(
          //             padding:
          //                 const EdgeInsets.only(left: 10, top: 5, bottom: 10),
          //             child: Text(
          //               'UPCOMING TEST',
          //               style: TextStyle(
          //                   fontSize: 18,
          //                   color: Color(0xFF0079EA),
          //                   fontFamily: 'LexendRegular'),
          //             ),
          //           ),
          //         ],
          //       ),
          //       Padding(
          //         padding: const EdgeInsets.only(
          //             right: 20, left: 20, bottom: 20, top: 15),
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.center,
          //           children: [
          //             Column(
          //               children: [Text("Upcoming test not found")],
          //             )
          //           ],
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
          // SizedBox(
          //   height: 10,
          // ),
          // Container(
          //   width: size.width,
          //   decoration: BoxDecoration(
          //       borderRadius: BorderRadius.circular(10),
          //       border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
          //   child: Column(
          //     mainAxisAlignment: MainAxisAlignment.start,
          //     children: [
          //       Row(
          //         children: [
          //           Padding(
          //             padding:
          //                 const EdgeInsets.only(left: 10, top: 5, bottom: 10),
          //             child: Text(
          //               'COMPLETED TEST',
          //               style: TextStyle(
          //                   fontSize: 18,
          //                   color: Color(0xFF0079EA),
          //                   fontFamily: 'LexendRegular'),
          //             ),
          //           ),
          //         ],
          //       ),
          //       Padding(
          //         padding:
          //             const EdgeInsets.only(right: 20, left: 20, bottom: 5),
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: [
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Test Name',
          //                   style: TextStyle(
          //                       color: Color(0xFF989292),
          //                       fontFamily: 'LexendRegular'),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text('Class',
          //                     style: TextStyle(
          //                         color: Color(0xFF989292),
          //                         fontFamily: 'LexendRegular')),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text('Subject',
          //                     style: TextStyle(
          //                         color: Color(0xFF989292),
          //                         fontFamily: 'LexendRegular')),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text('Status',
          //                     style: TextStyle(
          //                         color: Color(0xFF989292),
          //                         fontFamily: 'LexendRegular')),
          //               ],
          //             )
          //           ],
          //         ),
          //       ),
          //       Padding(
          //         padding: const EdgeInsets.only(left: 10.0, right: 10),
          //         child: Divider(),
          //       ),
          //       Padding(
          //         padding:
          //             const EdgeInsets.only(right: 20, left: 20, bottom: 10),
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: [
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Unit 3 Test',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   '9th',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Math',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Inactive',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12,
          //                       color: Colors.red),
          //                 ),
          //               ],
          //             )
          //           ],
          //         ),
          //       ),
          //       Divider(),
          //       Padding(
          //         padding:
          //             const EdgeInsets.only(right: 20, left: 20, bottom: 10),
          //         child: Row(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: [
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Unit 3 Test',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   '9th',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Math',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12),
          //                 ),
          //               ],
          //             ),
          //             Column(
          //               mainAxisAlignment: MainAxisAlignment.start,
          //               children: [
          //                 Text(
          //                   'Inactive',
          //                   style: TextStyle(
          //                       fontWeight: FontWeight.normal,
          //                       fontFamily: 'LexendRegular',
          //                       fontSize: 12,
          //                       color: Colors.red),
          //                 ),
          //               ],
          //             )
          //           ],
          //         ),
          //       ),
          //     ],
          //   ),
          // ),
          // SizedBox(
          //   height: 10,
          // ),
        ],
      ),
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              // Display the passed text or an empty string if null
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Color(0xff444444),
              ),
            ),
            if (value == 1)
              TextSpan(
                text: " *",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
