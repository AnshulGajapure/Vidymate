import 'package:flutter/material.dart';

class CreateMockTest extends StatefulWidget {
  const CreateMockTest({super.key});

  @override
  State<CreateMockTest> createState() => _CreateMockTestState();
}

class _CreateMockTestState extends State<CreateMockTest> {
  int currentIndex = 0; // Tracks current index for hiding buttons
  int selectedOption = -1; // Tracks the selected radio option
  final int totalItems = 5;

  ///////////////
  List<int> AddFileIndexes = [0];
  int? AddFile;
  int currentFileCount = 1;

///////////////////////////////////////
  //fill in the blank Option
  List<int> FIndexes = [0];
  int? FAddFile;
  int FcurrentFileCount = 1;

///////////////////////////////////////

  // fill in the blank file option
  List<int> FOAddFileIndexes = [0];
  int? FOAddFile;
  int FOcurrentFileCount = 1;

///////////////
  List<int> AddoptionIndexes = [0];
  int? AddOption;
  int? FileOption;

  ///////////

  int currentOptionsCount = 1;

  int TrueFalseOption = -1;
  List<bool> optionValues = [false, false];

  List<bool> correctOptions = [false, false, false, false];
  List<TextEditingController> optionControllers =
      List.generate(4, (index) => TextEditingController());
  late Size size;
  final List<String> classOptions = ['abc', 'efg', 'hij', 'klm', 'nop'];
  final List<String> Options = [
    'Single Choice Questions',
    'True of False',
    'Fill in the blanks'
  ];
  String? selectedValue;
  bool isTextMode = true;
  bool isTextMode2 = true;
  String? selectedClass;
  String? ChapterName;
  String? Selectthetype;
  String? SelectClass;

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: Color(0xffF9FAFB),
        appBar: AppBar(
          centerTitle: true,
          title: const Text(
            "Mock Test",
            style: TextStyle(
                fontFamily: 'LexendRegular',
                fontWeight: FontWeight.bold,
                fontSize: 17),
          ),
          flexibleSpace: Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)])),
          ),
        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(15),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding:
                      const EdgeInsets.only(left: 5, top: 10.0, bottom: 10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        child: Row(
                          children: [
                            Text(
                              "Create Mock Test",
                              style: TextStyle(
                                  color: Color(0xFF000000),
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: "LexendReguler"),
                            )
                          ],
                        ),
                      ),
                      Container(
                        height: size.height * 0.050,
                        width: size.width * 0.30,
                        decoration: BoxDecoration(
                            border: Border.all(
                                width: 1, color: const Color(0xFF0079EA)),
                            borderRadius: BorderRadius.circular(5)),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            const Text(
                              "Go Back",
                              style:
                                  TextStyle(fontSize: 12.0, color: Colors.blue),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.3),
                        spreadRadius: 5,
                        blurRadius: 7,
                        offset: Offset(0, 3),
                      ),
                    ],
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Row for Class and Subject Dropdowns
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildDropdown(
                              "Select Class",
                              SelectClass,
                              classOptions,
                              (newValue) =>
                                  setState(() => SelectClass = newValue)),
                          SizedBox(width: 16),
                          _buildDropdown(
                              "Select Subject",
                              selectedClass,
                              classOptions,
                              (newValue) =>
                                  setState(() => selectedClass = newValue)),
                        ],
                      ),
                      SizedBox(height: 10),

                      // Test Name TextFormField
                      RichText(
                        text: const TextSpan(
                          children: [
                            TextSpan(
                              text: ' Test Name ',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black),
                            ),
                            TextSpan(
                              text: '*',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.red), // Customize the asterisk
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 5),
                      Container(
                        height: size.height * 0.05,
                        width: size.width,
                        decoration: BoxDecoration(
                          border: Border.all(color: Color(0xFFD4D4D4)),
                          borderRadius: BorderRadius.circular(11),
                        ),
                        child: TextField(
                          decoration: InputDecoration(
                            hintText: "Enter the test name",
                            hintStyle: TextStyle(
                                color: Color(0xFF989292), fontSize: 12),
                            border: InputBorder.none,
                            // Removes default underline
                            contentPadding: EdgeInsets.only(
                              left: 10,
                              bottom: 10,
                            ),
                            // Adjusts the internal padding
                          ),
                        ),
                      ),

                      SizedBox(height: 20),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: const TextSpan(
                                  children: [
                                    TextSpan(
                                      text: ' No. of Questions ',
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                    TextSpan(
                                      text: '*',
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors
                                              .red), // Customize the asterisk
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Container(
                                height: size.height * 0.05,
                                width: size.width * 0.35,
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xFFD4D4D4)),
                                  borderRadius: BorderRadius.circular(11),
                                ),
                                child: TextField(
                                  decoration: InputDecoration(
                                    hintText: "Enter the No. of Questions",
                                    hintStyle: TextStyle(
                                        color: Color(0xFF989292), fontSize: 12),
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.symmetric(
                                        vertical: 14.0, horizontal: 10.0),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                text: const TextSpan(
                                  children: [
                                    TextSpan(
                                      text: ' Chapter ',
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors.black),
                                    ),
                                    TextSpan(
                                      text: '*',
                                      style: TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold,
                                          color: Colors
                                              .red), // Customize the asterisk
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              _buildDropdown(
                                  "Chapter Name",
                                  ChapterName,
                                  classOptions,
                                  (newValue) =>
                                      setState(() => ChapterName = newValue)),
                            ],
                          )
                        ],
                      ),
                      SizedBox(height: 20),

                      // Add Questions Button
                      Center(
                        child: ElevatedButton(
                          onPressed: () {
                            // Define your button action here
                          },
                          style: ElevatedButton.styleFrom(
                            padding: EdgeInsets.symmetric(
                                horizontal: 24, vertical: 12),
                            backgroundColor: Colors.blue,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: Text(
                            'Add Questions',
                            style: TextStyle(fontSize: 16, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Column(
                        children: [
                          Text(
                            "Select the Type \nof Question",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontFamily: "LexendReguler",
                            ),
                          ),
                        ],
                      ),
                      Column(
                        children: [
                          Dropdown(
                            "Select the type",
                            selectedValue,
                            Options,
                            (value) {
                              setState(() {
                                selectedValue = value; // Update selected value
                              });
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                selectedValue != null
                    ? SelectedWidget(selectedValue!)
                    : Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Text(
                              "Please Select an Option",
                              style: TextStyle(
                                fontSize: 13,
                                fontFamily: "LexendReguler",
                              ),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Text(
                              "No Questions Added",
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                fontFamily: "LexendReguler",
                              ),
                            ),
                          ),
                        ],
                      ),
              ],
            ),
          ),
        ));
  }

  Widget _buildDropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.38,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white, // White background for the container
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.white, // White background for dropdown items
              child: Text(value),
            ),
          );
        }).toList(),
        dropdownColor: Colors.white, // White background for the dropdown menu
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.38,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white, // White background for the container
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: const TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Container(
              color: Colors.white, // White background for dropdown items
              child: Text(value),
            ),
          );
        }).toList(),
        dropdownColor: Colors.white, // White background for the dropdown menu
      ),
    );
  }

  Widget textFormField(String? hintText, Size size, double value) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * value,
            width: size.width * value,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextFormField(
              textAlign: TextAlign.start,
              textAlignVertical: TextAlignVertical.center,
              decoration: InputDecoration(
                contentPadding: EdgeInsets.only(left: 10, bottom: 18),
                hintText: hintText,
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                ),
                border: InputBorder.none,
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter some text';
                }
                return null;
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text) {
    return Padding(
      padding: const EdgeInsets.only(top: 10.0, bottom: 10),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            TextSpan(
              text: '*',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: Colors.red,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget File(String Text) {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                  hintText: Text,
                  hintStyle: TextStyle(color: Color(0xFF989292), fontSize: 12),
                  border: InputBorder.none,
                  // Removes default underline
                  contentPadding: EdgeInsets.zero,
                  // Adjusts the internal padding
                  prefixIcon: Stack(
                    children: [
                      Image.asset(
                        'assets/images/Rectangle.png',
                        // Adjust the width of the image
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 9.0, bottom: 5, left: 13),
                        child: Image.asset(
                          'assets/images/file.png',
                          height: 15, // Adjust the height of the image
                          width: 15, // Adjust the width of the image
                        ),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ],
    );
  }

  /////////////////////////////////////////////////////////////////////////////////////////
  Widget AddQuestionContainer() {
    return Container(
      width: size.width,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          text(
            "Add Question",
          ),
          textFormField("Enter the Question", size, 0.050),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [text("Add Options"), text("Correct")],
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isTextMode = true;
                          });
                        },
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 50,
                              height: 25,
                              decoration: BoxDecoration(
                                color: isTextMode
                                    ? Colors.grey[300]
                                    : Colors.grey[200],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Image.asset(
                                  "assets/images/font.png",
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                            ),
                            if (isTextMode)
                              Positioned(
                                  left: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Image.asset(
                                      "assets/images/check.png",
                                      height: 10,
                                      width: 10,
                                    ),
                                  )),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isTextMode = false;
                          });
                        },
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 50,
                              height: 25,
                              decoration: BoxDecoration(
                                color: !isTextMode
                                    ? Colors.grey[300]
                                    : Colors.grey[200],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Image.asset(
                                  "assets/images/image.png",
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                            ),
                            if (!isTextMode)
                              Positioned(
                                  left: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Image.asset(
                                      "assets/images/check.png",
                                      height: 10,
                                      width: 10,
                                    ),
                                  )),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (isTextMode)
                        TextButton.icon(
                          onPressed: currentOptionsCount < 5
                              ? () {
                                  setState(() {
                                    AddoptionIndexes.add(
                                        AddoptionIndexes.length);
                                    currentOptionsCount++;
                                  });
                                }
                              : null,
                          icon: Icon(Icons.add),
                          label: Text('Add'),
                        ),
                      if (!isTextMode) // Add another "Add" button when not in text mode
                        TextButton.icon(
                          onPressed: currentFileCount < 5
                              ? () {
                                  setState(() {
                                    AddFileIndexes.add(AddFileIndexes.length);
                                    currentFileCount++; // Increment the number of added options
                                  });
                                }
                              : null,
                          icon: Icon(Icons.add),
                          label: Text('Add'),
                        ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 16),
              if (isTextMode)
                Column(
                  children: [
                    // Dynamically generate Option widgets
                    Column(
                      children: AddoptionIndexes.map((index) {
                        return AddQuestionOption(
                          index,
                          AddOption,
                          (value) {
                            setState(() {
                              AddOption = value;
                            });
                          },
                          () {
                            index == 0 ||
                                    index == 1 ||
                                    index == 2 ||
                                    index == 3 ||
                                    index == 4
                                ? setState(() {
                                    AddoptionIndexes.remove(index);
                                    currentOptionsCount--;
                                  })
                                : null;
                          },
                          size,
                        );
                      }).toList(),
                    ),

                    // Additional widgets (e.g., Extra widget)
                    Extra("Correct Answer Explaination"),
                  ],
                )
              else
                Column(
                  children: [
                    // Dynamically generate Option widgets
                    Column(
                      children: AddFileIndexes.map((index) {
                        return fileChoose(
                          index,
                          AddFile,
                          (value) {
                            setState(() {
                              AddFile = value;
                            });
                          },
                          () {
                            index == 0 ||
                                    index == 1 ||
                                    index == 2 ||
                                    index == 3 ||
                                    index == 4
                                ? setState(() {
                                    AddFileIndexes.remove(index);
                                    currentFileCount--;
                                  })
                                : null;
                          },
                          size,
                        );
                      }).toList(),
                    ),

                    // Additional widgets (e.g., Extra widget)
                    Extra("Correct Answer Explaination"),
                  ],
                )
            ],
          )
        ],
      ),
    );
  }

  Widget AddQuestionOption(
    int index,
    int? selectedOption,
    ValueChanged<int?> onChanged,
    final VoidCallback? onDelete,
    Size size, // Include size for better layout management
  ) {
    return Container(
      width: size.width,
      child: Column(
        children: [
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: textFormField(
                      // Option display logic
                      "Option ${index < 5 ? index + 1 : index + 1}",

                      size,
                      0.050,
                    ),
                  ),
                  Row(
                    children: [
                      Radio<int>(
                        value: index,
                        groupValue: selectedOption,
                        onChanged: onChanged, // Update state via callback
                      ),
                      IconButton(
                        icon: Icon(Icons.close, color: Colors.red),
                        onPressed: () {
                          if (AddoptionIndexes.isNotEmpty &&
                              AddoptionIndexes.last == index) {
                            setState(() {
                              if (AddoptionIndexes.isNotEmpty &&
                                  AddoptionIndexes.first == index) {
                                return;
                              }
                              AddoptionIndexes.remove(index);
                              currentOptionsCount--;
                            });
                          } else {
                            setState(() {
                              null;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget fileChoose(
    int index,
    int? selectedOption,
    ValueChanged<int?> onChanged,
    final VoidCallback? onDelete, // Callback for delete action
    Size size,

    // Include size for better layout management
  ) {
    return Container(
      width: size.width,
      child: Column(
        children: [
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: File(
                        "No file chosen ${index < 5 ? index + 1 : index + 1}"),
                  ),
                  Row(
                    children: [
                      Radio<int>(
                        value: index,
                        groupValue: selectedOption,
                        onChanged: onChanged, // Update state via callback
                      ),
                      IconButton(
                        icon: Icon(Icons.close, color: Colors.red),
                        onPressed: () {
                          if (AddFileIndexes.isNotEmpty &&
                              AddFileIndexes.last == index) {
                            setState(() {
                              if (AddFileIndexes.isNotEmpty &&
                                  AddFileIndexes.first == index) {
                                return;
                              }
                              AddFileIndexes.remove(index);
                              currentFileCount--;
                            });
                          } else {
                            setState(() {
                              null;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget FAddQuestionOption(
    int index,
    int? selectedOption,
    ValueChanged<int?> onChanged,
    final VoidCallback? onDelete,
    Size size, // Include size for better layout management
  ) {
    return Container(
      width: size.width,
      child: Column(
        children: [
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: textFormField(
                      // Option display logic
                      "Option ${index < 5 ? index + 1 : index + 1}",

                      size,
                      0.050,
                    ),
                  ),
                  Row(
                    children: [
                      Radio<int>(
                        value: index,
                        groupValue: selectedOption,
                        onChanged: onChanged, // Update state via callback
                      ),
                      IconButton(
                        icon: Icon(Icons.close, color: Colors.red),
                        onPressed: () {
                          if (FOAddFileIndexes.isNotEmpty &&
                              FOAddFileIndexes.last == index) {
                            setState(() {
                              if (FOAddFileIndexes.isNotEmpty &&
                                  FOAddFileIndexes.first == index) {
                                return;
                              }
                              FOAddFileIndexes.remove(index);
                              FOcurrentFileCount--;
                            });
                          } else {
                            setState(() {
                              null;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget FfileChoose(
    int index,
    int? selectedOption,
    ValueChanged<int?> onChanged,
    final VoidCallback? onDelete, // Callback for delete action
    Size size,

    // Include size for better layout management
  ) {
    return Container(
      width: size.width,
      child: Column(
        children: [
          Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: File(
                        "No file chosen ${index < 5 ? index + 1 : index + 1}"),
                  ),
                  Row(
                    children: [
                      Radio<int>(
                        value: index,
                        groupValue: selectedOption,
                        onChanged: onChanged, // Update state via callback
                      ),
                      IconButton(
                        icon: Icon(Icons.close, color: Colors.red),
                        onPressed: () {
                          if (FIndexes.isNotEmpty && FIndexes.last == index) {
                            setState(() {
                              if (FIndexes.isNotEmpty &&
                                  FIndexes.first == index) {
                                return;
                              }
                              FIndexes.remove(index);
                              FcurrentFileCount--;
                            });
                          } else {
                            setState(() {
                              null;
                            });
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget Extra(String value) {
    return Column(
      children: [
        SizedBox(
          height: 20,
        ),
        textFormField(value, size, 0.090),
        SizedBox(
          height: 20,
        ),
        Center(
          child: ElevatedButton(
            onPressed: () {
              // Handle add question logic
            },
            style: ElevatedButton.styleFrom(
              padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
              backgroundColor: Color(0xFF0079EA),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
            ),
            child: Text("Add Question",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,
                  fontFamily: "LexendReguler",
                )),
          ),
        ),
      ],
    );
  }

  ////////////////////////////////////////////////////////////////////////////////////////
  Widget TrueFalse() {
    return Container(
      width: size.width,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          text("Add Question"),
          textFormField("Enter the Question", size, 0.050),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [text("Add Options"), text("Correct")],
          ),
          Column(
            children: [
              for (int i = 0; i < 2; i++)
                Row(
                  children: [
                    Expanded(
                      child: textFormField(
                          optionValues[i] ? "True" : "False"
                          //"Option ${i + 1}"
                          ,
                          size,
                          0.050),
                    ),
                    Radio<int>(
                      value: i,
                      groupValue: TrueFalseOption,
                      onChanged: (value) {
                        setState(() {
                          TrueFalseOption = value!;
                          optionValues = [false, false];
                          optionValues[TrueFalseOption] = true;
                        });
                      },
                    ),
                  ],
                ),
              SizedBox(
                height: 20,
              ),
              textFormField("Correct Answer Explaination", size, 0.090),
              SizedBox(
                height: 20,
              ),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    // Handle add question logic
                  },
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                    backgroundColor: Color(0xFF0079EA),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text("Add Question",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                        fontFamily: "LexendReguler",
                      )),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  ////////////////////////////////////////////////////////////////////////////////////////
  Widget Fillintheblanks() {
    return Container(
      width: size.width,
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.3),
            spreadRadius: 5,
            blurRadius: 7,
            offset: Offset(0, 3),
          ),
        ],
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          text("Add Question"),
          textFormField("Enter the Question", size, 0.050),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [text("Add Options"), text("Correct")],
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isTextMode2 = true;
                          });
                        },
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 50,
                              height: 25,
                              decoration: BoxDecoration(
                                color: isTextMode2
                                    ? Colors.grey[300]
                                    : Colors.grey[200],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Image.asset(
                                  "assets/images/font.png",
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                            ),
                            if (isTextMode2)
                              Positioned(
                                  left: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Image.asset(
                                      "assets/images/check.png",
                                      height: 10,
                                      width: 10,
                                    ),
                                  )),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 5,
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            isTextMode2 = false;
                          });
                        },
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Container(
                              width: 50,
                              height: 25,
                              decoration: BoxDecoration(
                                color: !isTextMode2
                                    ? Colors.grey[300]
                                    : Colors.grey[200],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Center(
                                child: Image.asset(
                                  "assets/images/image.png",
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                            ),
                            if (!isTextMode2)
                              Positioned(
                                  left: 1,
                                  child: Padding(
                                    padding: const EdgeInsets.all(3.0),
                                    child: Image.asset(
                                      "assets/images/check.png",
                                      height: 10,
                                      width: 10,
                                    ),
                                  )),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (isTextMode2)
                        TextButton.icon(
                          onPressed: FOcurrentFileCount < 5
                              ? () {
                                  setState(() {
                                    FOAddFileIndexes.add(
                                        FOAddFileIndexes.length);
                                    FOcurrentFileCount++;
                                  });
                                }
                              : null,
                          icon: Icon(Icons.add),
                          label: Text(
                            'Add',
                            style: TextStyle(
                              fontFamily: "LexendReguler",
                            ),
                          ),
                        ),
                      if (!isTextMode2) // Add another "Add" button when not in text mode
                        TextButton.icon(
                          onPressed: FcurrentFileCount < 5
                              ? () {
                                  setState(() {
                                    FIndexes.add(FIndexes.length);
                                    FcurrentFileCount++; // Increment the number of added options
                                  });
                                }
                              : null,
                          icon: Icon(Icons.add),
                          label: Text(
                            'Add',
                            style: TextStyle(
                              fontFamily: "LexendReguler",
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
              SizedBox(height: 16),
              // Display the dynamic list of FillBlankOption widgets based on isTextMode
              if (isTextMode2)
                Column(
                  children: [
                    // Dynamically generate Option widgets
                    Column(
                      children: FOAddFileIndexes.map((index) {
                        return FAddQuestionOption(
                          index,
                          FOAddFile,
                          (value) {
                            setState(() {
                              FOAddFile = value;
                            });
                          },
                          () {
                            index == 0 ||
                                    index == 1 ||
                                    index == 2 ||
                                    index == 3 ||
                                    index == 4
                                ? setState(() {
                                    FOAddFileIndexes.remove(index);
                                    FOcurrentFileCount--;
                                  })
                                : null;
                          },
                          size,
                        );
                      }).toList(),
                    ),
                    Extra("Correct Answer Explaination"),
                  ],
                )
              else
                Column(
                  children: [
                    Column(
                      children: FIndexes.map((index) {
                        return FfileChoose(
                          index,
                          FAddFile,
                          (value) {
                            setState(() {
                              FAddFile = value;
                            });
                          },
                          () {
                            index == 0 ||
                                    index == 1 ||
                                    index == 2 ||
                                    index == 3 ||
                                    index == 4
                                ? setState(() {
                                    FIndexes.remove(index);
                                    FcurrentFileCount--;
                                  })
                                : null;
                          },
                          size,
                        );
                      }).toList(),
                    ),
                    Extra("Correct Answer Explaination"),
                  ],
                )
            ],
          ),
        ],
      ),
    );
  }

  ///////////////////////////////////////////////////////////////////////////////////////
  Widget SelectedWidget(String selectedValue) {
    if (selectedValue == "Single Choice Questions") {
      return AddQuestionContainer();
    } else if (selectedValue == "True of False") {
      return TrueFalse();
    } else if (selectedValue == "Fill in the blanks") {
      return Fillintheblanks();
    } else {
      return Text("data");
    }
  }
}
