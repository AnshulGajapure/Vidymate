import 'package:flutter/material.dart';

class PresentStudentsPage extends StatefulWidget {
  const PresentStudentsPage({super.key});

  @override
  State<PresentStudentsPage> createState() => PresentStudentsPageState();
}

class PresentStudentsPageState extends State<PresentStudentsPage> {
  TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _controller.removeListener(() {});
    _controller.dispose();
    super.dispose();
  }

  void _clearText() {
    setState(() {
      _controller.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // AppBar with Back Button
          Container(
            height: screenHeight * 0.18,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
              ),
            ),
            child: Center(
              child: Padding(
                padding: EdgeInsets.only(top: screenHeight * 0.05),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.arrow_back, color: Colors.black),
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                    Text(
                      "Present Students",
                      style: TextStyle(
                        fontSize: screenWidth * 0.05,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(width: 40), // Spacer to align title center
                  ],
                ),
              ),
            ),
          ),
          // Search Bar positioned below AppBar
          Positioned(
            top: screenHeight * 0.14,
            left: screenWidth * 0.04,
            right: screenWidth * 0.04,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.04,
                vertical: screenHeight * 0.005,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Icon(Icons.search, color: Colors.grey),
                  SizedBox(width: screenWidth * 0.02),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: 'Search student name or code',
                        hintStyle: const TextStyle(color: Color(0xFF9A9A9A)),
                        border: InputBorder.none,
                        suffixIcon: _controller.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.close),
                                onPressed: _clearText,
                              )
                            : null,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Main Body Content
          Padding(
            padding: EdgeInsets.only(top: screenHeight * 0.22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Date Widget
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today,
                          size: 12, color: Colors.redAccent),
                      SizedBox(width: 8),
                      Text(
                        '14 May 2024',
                        style: TextStyle(
                            fontSize: 15,
                            color: Colors.black87,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                // Scrollable Data Table of students
                Container(
                  height: screenHeight * 0.7,
                  width: double.infinity,
                  margin: const EdgeInsets.symmetric(horizontal: 16.0),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.blueAccent),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: SingleChildScrollView(
                    scrollDirection: Axis.vertical,
                    child: DataTable(
                      columnSpacing: screenWidth * 0.08,
                      // Adjust spacing between columns as needed
                      headingRowColor: WidgetStateProperty.all(
                        Colors.blueAccent.shade100.withOpacity(0.5),
                      ),
                      dataRowHeight: 35,
                      headingRowHeight: 35,
                      columns: const [
                        DataColumn(
                          label: Expanded(
                            child: Text(
                              "Sr. NO",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Expanded(
                            child: Center(
                              child: Text(
                                "Name",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    fontSize: 12,
                                    color: Colors.black87,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                        ),
                        DataColumn(
                          label: Expanded(
                            child: Text(
                              "Student Code",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black87,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                      rows: List<DataRow>.generate(
                        students.length,
                        (index) => DataRow(
                          color: MaterialStateProperty.resolveWith<Color>(
                              (Set<MaterialState> states) {
                            if (index % 2 == 0) return Colors.grey.shade200;
                            return Colors.transparent;
                          }),
                          cells: [
                            DataCell(
                              Center(
                                child: Text(
                                  (index + 1).toString(),
                                  style: const TextStyle(fontSize: 13),
                                ),
                              ),
                            ),
                            DataCell(
                              Center(
                                child: Container(
                                  width: screenWidth * 0.29,
                                  child: Text(
                                    students[index].name,
                                    style: const TextStyle(fontSize: 13),
                                  ),
                                ),
                              ),
                            ),
                            DataCell(
                              Center(
                                child: Text(
                                  students[index].code,
                                  style: TextStyle(
                                      fontSize: 13, color: Colors.grey[600]),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Data Model for Student
class Student {
  final String name;
  final String code;

  Student(this.name, this.code);
}

// Sample list of students
List<Student> students = [
  Student('Udeshna Kakati', '020833'),
  Student('Priyanshi Das', '020834'),
  Student('Moul Chakraborty', '020835'),
  Student('Ayat Mahira', '020836'),
  Student('Aayanjyoti Borgohain', '020837'),
  Student('Zayed Ahmed Khan', '020838'),
  Student('Shafi Uddin Ahmed', '020839'),
  Student('Briyansh Saha', '020833'),
  Student('Kriti Gupta', '020833'),
  Student('Priyesh Das', '020833'),
  Student('Yuvaan D Thakuria', '020833'),
  Student('Avni Kumari', '020833'),
  Student('Veerangana Chanda', '020833'),
];
