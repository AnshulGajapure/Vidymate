import 'package:flutter/material.dart';

class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  void _onPageChanged(int index) {
    setState(() {
      _currentPage = index;
    });
  }

  late Size size;

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: _currentPage == 0
          ? const Color(0xffF9FAFB)
          : _currentPage == 1
              ? const Color(0xffFCF7CF)
              : const Color(0xffD1F8E7),
      body: Column(
        children: [
          // Logo at the top
          Padding(
            padding: const EdgeInsets.only(top: 80.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Image.asset(
                  "assets/images/vm_logo-removebg-preview.png",
                  height: size.height * 0.13,
                ),
                // Conditionally include the second image
                if (_currentPage == 0)
                  Image.asset(
                    "assets/images/notebook.png",
                    height: size.height * 0.13,
                  ),
              ],
            ),
          ),
          // Onboarding slides
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: _onPageChanged,
              children: const [
                OnboardingSlide(
                  imagePath: 'assets/images/prescreen1.png',
                  title: 'Enhancing Classroom Efficiency',
                  description:
                      'Simplifies lesson planning, assignment management, and student progress tracking. It offers seamless communication with students and parents, while providing insights into class performance through real-time analytics.',
                ),
                OnboardingSlide(
                  imagePath: 'assets/images/prescreen2.png',
                  title: 'Empowering Educators',
                  description:
                      'Streamlining classroom management by offering tools for creating lessons, grading assignments, and tracking student progress. Teachers can engage students more effectively and foster a more productive learning experience.',
                ),
                OnboardingSlide(
                  imagePath: 'assets/images/prescreen3.png',
                  title: 'Revolutionizing Teaching',
                  description:
                      'Simplifying daily tasks with tools for lesson creation, assignment grading, and real-time student progress tracking. It enables teachers to focus on personalized learning and improving student outcomes.',
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 170.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    3,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 300),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      height: 8,
                      width: _currentPage == index ? 8 : 8,
                      decoration: BoxDecoration(
                        color: _currentPage == index
                            ? Color(0xff26252F)
                            : Color(0xffD9D9D9),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
              ),
              // if (_currentPage < 2)
              TextButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, '/Dashboard');
                },
                child: const Text(
                  "Skip",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.blue,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16)
        ],
      ),
    );
  }
}

class OnboardingSlide extends StatelessWidget {
  final String imagePath;
  final String title;
  final String description;

  const OnboardingSlide({
    required this.imagePath,
    required this.title,
    required this.description,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset(imagePath, height: 300),
          const SizedBox(height: 24),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            description,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14),
          ),
        ],
      ),
    );
  }
}
