import 'package:flutter/material.dart';

class MyTimetable extends StatefulWidget {
  const MyTimetable({super.key});

  @override
  State<MyTimetable> createState() => _MyTimetableState();
}

class _MyTimetableState extends State<MyTimetable> {
  late Size size;
  String? selectDay;
  String? selectDay1;

  final List<String> dayOptions = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday'
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "My Timetable",
          style: TextStyle(
              fontFamily: 'LexendRegular',
              fontWeight: FontWeight.bold,
              fontSize: 17),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)])),
        ),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.only(bottom: 30, left: 10, right: 10),
          child: Column(
            children: [
              Row(
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 20, top: 20, bottom: 20),
                    child: Text(
                      "Timetable",
                      style: TextStyle(
                          fontSize: 15,
                          fontFamily: "LexendReguler",
                          color: Color(0xFF0079EA),
                          fontWeight: FontWeight.bold),
                    ),
                  )
                ],
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(width: 1, color: Color(0xFFD9D9D9))),
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: _buildDayHeaders(),
                      ),
                    ),
                    Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Count(),
                          Stack(
                            children: [
                              Container(
                                width: size.width * 0.75,
                                height: size.height * 0.13,
                                decoration: BoxDecoration(
                                  color: const Color(0xFF878383),
                                  borderRadius: BorderRadius.circular(15.0),
                                ),
                              ),
                              Container(
                                margin:
                                    const EdgeInsets.symmetric(horizontal: 8.0),
                                width: size.width * 0.80,
                                height: size.height * 0.13,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF5F5F5),
                                  borderRadius: BorderRadius.circular(8.0),
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Padding(
                                      padding: EdgeInsets.only(
                                          left: 14.0, top: 7.0, bottom: 7.0),
                                      child: Align(
                                        alignment: Alignment.centerLeft,
                                        child: Text(
                                          "9.00 am - 10.00 am",
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: Color(0xFF989292),
                                            fontFamily: "LexendReguler",
                                          ),
                                        ),
                                      ),
                                    ),
                                    Dropdown(
                                        "Select Day",
                                        selectDay,
                                        dayOptions,
                                        (newValue) => setState(
                                            () => selectDay = newValue)),
                                    const SizedBox(height: 10),
                                    Dropdown(
                                        "Select Day",
                                        selectDay1,
                                        dayOptions,
                                        (newValue) => setState(
                                            () => selectDay1 = newValue)),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                        height: size.height * 0.050,
                        width: size.width * 0.22,
                        decoration: BoxDecoration(
                            color: const Color(0xFF0DA800),
                            border: Border.all(
                                width: 1, color: const Color(0xFF0DA800)),
                            borderRadius: BorderRadius.circular(5)),
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            // Icon(
                            //   Icons.visibility,
                            //   size: 18,
                            // ),
                            Text(
                              "Export",
                              style: TextStyle(
                                fontSize: 15.0,
                                color: Colors.white,
                                fontFamily: "LexendReguler",
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildDayHeaders() {
    return ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT']
        .map(
          (day) => Container(
            height: size.height * 0.030,
            width: size.width * 0.13,
            decoration: BoxDecoration(
                color: const Color(0xFF878383),
                borderRadius: BorderRadius.circular(5)),
            child: Center(
              child: Text(
                day,
                style: TextStyle(
                  fontSize: 12.0,
                  color: Colors.white,
                  fontFamily: "LexendReguler",
                ),
              ),
            ),
          ),
        )
        .toList();
  }

  Widget Count() {
    return Center(
      child: Container(
        width: size.width * 0.060,
        height: size.height * 0.025,
        decoration: const BoxDecoration(
          color: Color(0xFFDDDDDD),
          shape: BoxShape.circle,
        ),
        child: const Center(
          child: Text(
            '1',
            style: TextStyle(
              fontSize: 10,
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontFamily: "LexendReguler",
            ),
          ),
        ),
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.031,
      width: size.width * 0.60,
      margin: EdgeInsets.only(left: 5, right: 5),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(
            color: Color(0xFF989292),
            fontSize: 12,
            fontFamily: "LexendReguler",
          ),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
      ),
    );
  }
}
