import 'package:flutter/material.dart';

class ContentUploader extends StatefulWidget {
  const ContentUploader({super.key});

  @override
  State<ContentUploader> createState() => _ContentUploaderState();
}

class _ContentUploaderState extends State<ContentUploader> {
  late Size size;
  String? selectedClass;
  String? SelectDay;
  String? SelectSubject;
  String? Title;
  int? _selectedFileType = 1;
  String? selectedDay;
  bool isVideoClicked = true;
  bool isAudioClicked = false;

  final List<String> classOptions = ['10th A', '10th B', '10th C'];
  final List<String> dayOptions = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday'
  ];

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Color(0xffF9FAFB),
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          "Content Uploader",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 18,
            fontFamily: "LexendReguler",
          ),
        ),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(
                    padding:
                        const EdgeInsets.only(left: 5, top: 10, bottom: 10),
                    child: Text(
                      "Content Uploader",
                      style: TextStyle(
                        color: Color(0xFF000000),
                        fontSize: 18,
                        fontFamily: "LexendReguler",
                      ),
                    ),
                  ),
                ],
              ), // Space between sections
              DropdownSection(),
              const SizedBox(height: 20), // Space between sections
              ContentSection(),
            ],
          ),
        ),
      ),
    );
  }

  Widget DropdownSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFD4D4D4), width: 1.5),
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Select Class Dropdown
          text("Class", 1),
          Dropdown("Select Class", selectedClass, classOptions,
              (newValue) => setState(() => selectedClass = newValue)),
          text("Select Subject", 1),

          Dropdown("Select Day", SelectDay, dayOptions,
              (newValue) => setState(() => SelectDay = newValue)),
          text("Chapter", 1),
          Dropdown("Select Subject", SelectSubject, dayOptions,
              (newValue) => setState(() => SelectSubject = newValue)),
          const SizedBox(height: 10),
          const Text(
            "If the Chapter is not available, type and press enter.",
            style: TextStyle(
                fontSize: 10.5,
                fontWeight: FontWeight.bold,
                fontFamily: 'LexendRegular',
                color: Color(0xFF989292)),
          ),
        ],
      ),
    );
  }

  Widget ContentSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        border: Border.all(color: const Color(0xFFD4D4D4), width: 1.5),
        borderRadius: BorderRadius.circular(20),
        color: Colors.white,
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() {
                    isVideoClicked = true;
                    isAudioClicked = false;
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 10),
                  child: Text(
                    "VIDEO",
                    style: TextStyle(
                      fontFamily: "LexendReguler",
                      color: isVideoClicked ? Color(0xff1E5CE1) : Colors.black,
                      fontWeight:
                          isVideoClicked ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    isAudioClicked = true;
                    isVideoClicked = false;
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.only(left: 20, right: 10),
                  child: Text(
                    "NOTES",
                    style: TextStyle(
                      fontFamily: "LexendReguler",
                      color: isAudioClicked ? Color(0xff1E5CE1) : Colors.black,
                      fontWeight:
                          isAudioClicked ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
              ),
            ],
          ),
          const Divider(thickness: 1, color: Color(0xFFD4D4D4)),
          if (isVideoClicked) Videos() else Notes(),
        ],
      ),
    );
  }

  Widget Dropdown(String hint, String? selectedValue, List<String> items,
      ValueChanged<String?> onChanged) {
    return Container(
      height: size.height * 0.05,
      width: size.width * 0.9,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        border: Border.all(color: Color(0xFFD4D4D4), width: 2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: DropdownButton<String>(
        value: selectedValue,
        isExpanded: true,
        hint: Text(
          hint,
          style: TextStyle(color: Color(0xFF989292), fontSize: 12),
        ),
        underline: const SizedBox(),
        icon: Image.asset(
          'assets/images/down-arrow.png',
          height: 15,
          width: 15,
        ),
        onChanged: onChanged,
        items: items.map((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(
              value,
              style: TextStyle(
                  fontSize: 14,
                  fontFamily: "LexendReguler",
                  color: Color(0xff989292)),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget Videos() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [text("Title", 1)],
          ),
          const SizedBox(height: 5),
          Container(
            height: size.height * 0.05,
            width: size.width,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Enter Title",
                hintStyle: TextStyle(color: Color(0xFF989292), fontSize: 12),
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 10, bottom: 10),
              ),
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [text("Video Type", 1)],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Radio(
                value: 1,
                groupValue: _selectedFileType,
                onChanged: (int? value) {
                  setState(() {
                    _selectedFileType = value;
                  });
                },
                fillColor: MaterialStateProperty.resolveWith<Color>(
                    (Set<MaterialState> states) {
                  if (states.contains(MaterialState.selected)) {
                    return Color(0xff1E5CE1); // Inner point color
                  }
                  return Color(
                      0xff989292); // Default color for the unselected state
                }),
              ),
              const Text("File"),
              const SizedBox(width: 8),
              Radio(
                value: 2,
                groupValue: _selectedFileType,
                onChanged: (int? value) {
                  setState(() {
                    _selectedFileType = value;
                  });
                },
                fillColor: MaterialStateProperty.resolveWith<Color>(
                    (Set<MaterialState> states) {
                  if (states.contains(MaterialState.selected)) {
                    return Color(0xff1E5CE1); // Inner point color
                  }
                  return Color(
                      0xff989292); // Default color for the unselected state
                }),
              ),
              const Text("Url"),
            ],
          ),
          const SizedBox(height: 5),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: _selectedFileType == 1 ? 'File Uploaded' : 'Url',
                      style: TextStyle(
                          fontSize: 14,
                          fontFamily: "LexendReguler",
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    TextSpan(
                      text: ' *',
                      style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          color: Colors.red), // Customize the asterisk
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          if (_selectedFileType == 1) File() else URL(),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: size.height * 0.040,
                  width: size.width * 0.2,
                  decoration: BoxDecoration(
                      border:
                          Border.all(width: 1, color: const Color(0xFF0079EA)),
                      color: Color(0xFF0079EA),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/plus.png',
                        height: 25,
                      ),
                      const Text(
                        "Add",
                        style: TextStyle(
                          fontSize: 12.0,
                          color: Colors.white,
                          fontFamily: "LexendReguler",
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                  height: size.height * 0.040,
                  width: size.width * 0.2,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.red),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/clear.png',
                        height: 25,
                      ),
                      const Text(
                        "Clear",
                        style: TextStyle(
                          fontFamily: "LexendReguler",
                          color: Colors.red,
                          fontSize: 12.0,
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('TITLE',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
              Text('FILE TYPE',
                  style: TextStyle(
                    fontFamily: "LexendReguler",
                    color: Color(0xFF989292),
                  )),
              Spacer(),
              Text('FILE',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
              Text('ACTION',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
            ],
          ),
          Divider(),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                'Video Not Available !',
                style: TextStyle(
                    fontSize: 16,
                    fontFamily: "LexendReguler",
                    color: Color(0xFF989292),
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget Notes() {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          text("Title", 1),
          Container(
            height: size.height * 0.05,
            width: size.width * 0.7,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8),
            ),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Enter Title",
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                  fontFamily: "LexendReguler",
                ),
                border: InputBorder.none,
                contentPadding: EdgeInsets.only(top: 10, bottom: 10),
              ),
            ),
          ),
          text("File Uploaded", 1),
          Row(
            children: [
              Container(
                height: size.height * 0.05,
                width: size.width * 0.7,
                decoration: BoxDecoration(
                  border: Border.all(color: Color(0xFFD4D4D4)),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: TextField(
                  decoration: InputDecoration(
                      hintText: "No notes chosen",
                      hintStyle: TextStyle(
                        color: Color(0xFF989292),
                        fontSize: 12,
                        fontFamily: "LexendReguler",
                      ),
                      border: InputBorder.none,
                      // Removes default underline
                      contentPadding: EdgeInsets.zero,
                      // Adjusts the internal padding
                      prefixIcon: Stack(
                        children: [
                          Image.asset(
                            'assets/images/Rectangle.png',
                            // Adjust the width of the image
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                                top: 9.0, bottom: 5, left: 13),
                            child: Image.asset(
                              'assets/images/file.png',
                              height: 15, // Adjust the height of the image
                              width: 15, // Adjust the width of the image
                            ),
                          ),
                        ],
                      )),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  height: size.height * 0.040,
                  width: size.width * 0.2,
                  decoration: BoxDecoration(
                      border:
                          Border.all(width: 1, color: const Color(0xFF0079EA)),
                      color: Color(0xFF0079EA),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/plus.png',
                        height: 25,
                      ),
                      const Text(
                        "Add",
                        style: TextStyle(
                          fontSize: 12.0,
                          color: Colors.white,
                          fontFamily: "LexendReguler",
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Container(
                  height: size.height * 0.040,
                  width: size.width * 0.2,
                  decoration: BoxDecoration(
                      border: Border.all(width: 1, color: Colors.red),
                      borderRadius: BorderRadius.circular(5)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        'assets/images/clear.png',
                        height: 25,
                      ),
                      const Text(
                        "Clear",
                        style: TextStyle(
                          color: Colors.red,
                          fontFamily: "LexendReguler",
                          fontSize: 12.0,
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 20,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('TITLE',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
              Text('FILE TYPE',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
              Text('FILE',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
              Text('ACTION',
                  style: TextStyle(
                    color: Color(0xFF989292),
                    fontFamily: "LexendReguler",
                  )),
              Spacer(),
            ],
          ),
          Divider(),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Center(
              child: Text(
                'Video Not Available !',
                style: TextStyle(
                  color: Color(0xFF989292),
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: "LexendReguler",
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget File() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                  hintText: "No file chosen",
                  hintStyle: TextStyle(
                    color: Color(0xFF989292),
                    fontSize: 12,
                    fontFamily: "LexendReguler",
                  ),
                  border: InputBorder.none,
                  // Removes default underline
                  contentPadding: EdgeInsets.zero,
                  // Adjusts the internal padding
                  prefixIcon: Stack(
                    children: [
                      Image.asset(
                        'assets/images/Rectangle.png',
                        // Adjust the width of the image
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                            top: 9.0, bottom: 5, left: 13),
                        child: Image.asset(
                          'assets/images/file.png',
                          height: 15, // Adjust the height of the image
                          width: 15, // Adjust the width of the image
                        ),
                      ),
                    ],
                  )),
            ),
          ),
        ),
      ],
    );
  }

  Widget URL() {
    return Row(
      children: [
        Expanded(
          child: Container(
            height: size.height * 0.05,
            width: size.width,
            decoration: BoxDecoration(
              border: Border.all(color: Color(0xFFD4D4D4)),
              borderRadius: BorderRadius.circular(11),
            ),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Enter URL",
                hintStyle: TextStyle(
                  color: Color(0xFF989292),
                  fontSize: 12,
                  fontFamily: "LexendReguler",
                ),
                border: InputBorder.none,
                // Removes default underline
                contentPadding: EdgeInsets.only(
                  left: 10,
                  bottom: 10,
                ),
                // Adjusts the internal padding
              ),
            ),
            // child: Row(
            //   children: [
            //     Stack(children: [
            //       Image.asset(
            //         "assets/images/Rectangle.png",
            //         height: 32,
            //         width: 32,
            //       ),
            //       Padding(
            //         padding: const EdgeInsets.all(8.0),
            //         child: Image.asset(
            //           "assets/images/file.png",
            //           height: 15,
            //           width: 15,
            //         ),
            //       ),
            //     ]),
            //     const SizedBox(width: 10),
            //     Text(
            //         _selectedFileType == 1
            //             ? 'No file chosen'
            //             : 'URL uploaded',
            //         style: TextStyle(
            //             color: Color(0xFF989292), fontSize: 12)),
            //   ],
            // ),
          ),
        ),
      ],
    );
  }

  Widget text(String? text, int value) {
    return Padding(
      padding: const EdgeInsets.only(top: 15.0, bottom: 5),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: text ?? '',
              // Display the passed text or an empty string if null
              style: TextStyle(
                fontSize: 14,
                fontFamily: "LexendReguler",
                fontWeight: FontWeight.bold,
                color: Color(0xff444444),
              ),
            ),
            if (value == 1)
              TextSpan(
                text: " *",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
