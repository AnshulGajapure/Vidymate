import 'package:flutter/material.dart';

class AttendanceListPage extends StatefulWidget {
  const AttendanceListPage({super.key});

  @override
  State<AttendanceListPage> createState() => AttendanceListPageState();
}

class AttendanceListPageState extends State<AttendanceListPage> {
  TextEditingController _controller = TextEditingController();

  // Function to clear text
  void _clearText() {
    setState(() {
      _controller.clear(); // Clear the text in the TextField
    });
  }

  @override
  void initState() {
    super.initState();
    // Add a listener to the controller to trigger setState when text changes
    _controller.addListener(() {
      setState(() {}); // Rebuild the widget when the text changes
    });
  }

  @override
  void dispose() {
    _controller.removeListener(
        () {}); // Remove the listener when the widget is disposed
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          // AppBar with Back Button
          Container(
            height: screenHeight * 0.18,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: <Color>[Color(0xFFAADBFF), Color(0x77EDC7FF)],
              ),
            ),
            child: Padding(
              padding: EdgeInsets.only(top: screenHeight * 0.05),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.black),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),
                  SizedBox(width: screenWidth * 0.19),
                  Text(
                    "Attendance List",
                    style: TextStyle(
                      fontSize: screenWidth * 0.05,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Search Bar positioned below AppBar
          Positioned(
            top: screenHeight * 0.14,
            left: screenWidth * 0.04,
            right: screenWidth * 0.04,
            child: Container(
              padding: EdgeInsets.symmetric(
                horizontal: screenWidth * 0.04,
                vertical: screenHeight * 0.005,
              ),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(30),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: Row(
                children: [
                  const Icon(Icons.search, color: Colors.grey),
                  SizedBox(width: screenWidth * 0.02),
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: 'Search student name or code',
                        hintStyle: const TextStyle(color: Color(0xFF9A9A9A)),
                        border: InputBorder.none,
                        suffixIcon: _controller.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.close),
                                onPressed: _clearText, // Clear text when tapped
                              )
                            : null, // Show nothing if the text is empty
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          // Body content below the search bar
          Padding(
            padding: EdgeInsets.only(
              top: screenHeight * 0.23,
              left: screenWidth * 0.05,
              right: screenWidth * 0.05,
              bottom: screenHeight * 0.05,
            ),
            child: Container(
              width: double.infinity,
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFF778BC0)),
                borderRadius: BorderRadius.circular(10),
              ),
              child: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: DataTable(
                  columnSpacing: screenWidth * 0.08,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  headingRowColor: MaterialStateColor.resolveWith(
                      (states) => Colors.blueAccent.shade100.withOpacity(0.5)),
                  dataRowHeight: 40,
                  headingRowHeight: 40,
                  columns: [
                    DataColumn(
                      label: Center(
                        child: Text(
                          'Name',
                          style: TextStyle(
                            fontSize: screenWidth * 0.028,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Center(
                        child: Text(
                          'StudentCode',
                          style: TextStyle(
                            fontSize: screenWidth * 0.028,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                    DataColumn(
                      label: Center(
                        child: Text(
                          'Attendance',
                          style: TextStyle(
                            fontSize: screenWidth * 0.028,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                  rows: students
                      .asMap() // Get index of the list
                      .map((index, student) {
                        return MapEntry(
                          index,
                          DataRow(
                            color: WidgetStateProperty.all(Colors.white),
                            cells: [
                              DataCell(
                                Center(
                                  child: Text(
                                    student.name,
                                    style: TextStyle(
                                      fontSize: screenWidth *
                                          0.025, // Smaller font size for content
                                    ),
                                  ),
                                ),
                              ),
                              DataCell(
                                Center(
                                  child: Text(
                                    student.code,
                                    style: TextStyle(
                                      fontSize: screenWidth * 0.025,
                                      // Smaller font size for content
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ),
                              ),
                              DataCell(
                                Transform.scale(
                                  scale: 0.6,
                                  child: Switch(
                                    value: student.isPresent,
                                    onChanged: (value) {
                                      setState(() {
                                        student.isPresent = value;
                                      });
                                    },
                                    activeColor: Colors.white,
                                    inactiveTrackColor: Colors.red,
                                    inactiveThumbColor: Colors.white,
                                    trackOutlineColor: WidgetStateProperty.all(
                                        Colors.transparent),
                                    activeTrackColor: Colors.green,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      })
                      .values
                      .toList(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Data Model for Student
class Student {
  final String name;
  final String code;
  bool isPresent;

  Student(this.name, this.code, this.isPresent);
}

// Sample list of students
List<Student> students = [
  Student('Priyanshi Das', '020834', false),
  Student('Moul Chakraborty', '020835', false),
  Student('Ayat Mahira', '020836', false),
  Student('Udeshna Kakati', '020833', false),
  Student('Aayanjyoti Borgohain', '020837', false),
  Student('Zayed Ahmed Khan', '020838', false),
  Student('Shafi Uddin Ahmed', '020839', false),
  Student('Briyansh Saha', '020840', false),
  Student('Kriti Gupta', '020841', false),
  Student('Priyesh Das', '020842', false),
  Student('Yuvaan Thakuria', '020843', false),
  Student('Avni Kumari', '020844', false),
  Student('Veerangana Chanda', '020845', false),
];
