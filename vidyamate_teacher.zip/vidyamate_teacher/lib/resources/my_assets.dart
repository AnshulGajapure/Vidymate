import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import 'my_colors.dart';

var appLogo = const AssetImage('assets/images/logo.png');

//dialog
var errorIcon = const AssetImage('assets/images/error.png');
var noInternetIcon = const AssetImage('assets/images/no_internet.png');
var unlock = const AssetImage('assets/images/unlock.png');
var administration = const AssetImage('assets/images/admin.png');
var addmission = const AssetImage('assets/images/student.png');
var fees = const AssetImage('assets/images/fees.png');
var lms = const AssetImage('assets/images/LMS.png');
var hostel = const AssetImage('assets/images/hostel.png');
var payroll = const AssetImage('assets/images/salary.png');
var schoolCommunication =
    const AssetImage('assets/images/School Communication.png');
var teachersDesk = const AssetImage('assets/images/desk.png');
var transport = const AssetImage('assets/images/bus.png');
var attendence = const AssetImage('assets/images/Attendance.png');
var examination = const AssetImage('assets/images/Examination.png');
var reports = const AssetImage('assets/images/Reports.png');
var timetable = const AssetImage('assets/images/timetable.png');
var intimeClock = const AssetImage('assets/images/in-time 1.png');
var outTimeClock = const AssetImage('assets/images/clock 1.png');
var fingurePrint = const AssetImage('assets/images/fingerprint 1.png');
var ellipse = const AssetImage('assets/images/Ellipse 256.png');
var confetti = const AssetImage('assets/images/confetti 1.png');

Widget imageLoader() {
  return Shimmer.fromColors(
    period: Duration(milliseconds: 1000),
    baseColor: MyColor.black,
    highlightColor: Colors.grey.shade700,
    child: Container(color: Colors.black),
  );
}

Widget errorWidget(BuildContext context, String url, dynamic error) {
  return Image(
    image: errorIcon,
    fit: BoxFit.cover,
  );
}

Widget errorWidget2(BuildContext context, String url, dynamic error) {
  return Shimmer.fromColors(
    period: Duration(milliseconds: 1000),
    baseColor: MyColor.black,
    highlightColor: Colors.grey.shade700,
    child: Container(color: Colors.white),
  );
}
