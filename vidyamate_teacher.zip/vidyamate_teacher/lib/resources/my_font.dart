import 'package:flutter/material.dart';

class MyFont {
  static const String jakartaLight = "PlusJakartaSansLight";
  static const String jakartaRegular = "PlusJakartaSansRegular";
  static const String jakartaMedium = "PlusJakartaSansMedium";
  static const String jakartaSemiBold = "PlusJakartaSansSemiBold";
  static const String jakartaBold = "PlusJakartaSansBold";
  static const String jakartaExtraBold = "PlusJakartaSansExtraBold";

  static const String dmSerifTextRegular = 'DMSerifTextRegular';
}
