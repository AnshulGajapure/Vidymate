class MyString {
  static const String errorMessage = "Something went wrong, please try later";

  static const String onbTextOne = "Unlimited entertainment,\nin one platform";
  static const String onbTextTwo = "Grab your popcorn\n& enjoy the show";
  static const String onbTextThree = "Personalized\nrecommendation";
}
