class DashboardApi2Model {
  int? status;
  String? msg;
  Payload? payload;

  DashboardApi2Model({this.status, this.msg, this.payload});

  DashboardApi2Model.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
    payload =
        json['payload'] != null ? new Payload.fromJson(json['payload']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    if (this.payload != null) {
      data['payload'] = this.payload!.toJson();
    }
    return data;
  }
}

class Payload {
  List<Circulars>? circulars;
  List<Eventactivity>? eventactivity;
  List<TopPerformance>? topPerformance;

  Payload({this.circulars, this.eventactivity, this.topPerformance});

  Payload.fromJson(Map<String, dynamic> json) {
    if (json['circulars'] != null) {
      circulars = <Circulars>[];
      json['circulars'].forEach((v) {
        circulars!.add(new Circulars.fromJson(v));
      });
    }
    if (json['eventactivity'] != null) {
      eventactivity = <Eventactivity>[];
      json['eventactivity'].forEach((v) {
        eventactivity!.add(new Eventactivity.fromJson(v));
      });
    }
    if (json['top_performance'] != null) {
      topPerformance = <TopPerformance>[];
      json['top_performance'].forEach((v) {
        topPerformance!.add(new TopPerformance.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.circulars != null) {
      data['circulars'] = this.circulars!.map((v) => v.toJson()).toList();
    }
    if (this.eventactivity != null) {
      data['eventactivity'] =
          this.eventactivity!.map((v) => v.toJson()).toList();
    }
    if (this.topPerformance != null) {
      data['top_performance'] =
          this.topPerformance!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Circulars {
  String? mainTitle;
  String? title;
  String? circular;
  Null? fromDate;
  Null? toDate;

  Circulars(
      {this.mainTitle, this.title, this.circular, this.fromDate, this.toDate});

  Circulars.fromJson(Map<String, dynamic> json) {
    mainTitle = json['main_title'];
    title = json['title'];
    circular = json['circular'];
    fromDate = json['from_date'];
    toDate = json['to_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['main_title'] = this.mainTitle;
    data['title'] = this.title;
    data['circular'] = this.circular;
    data['from_date'] = this.fromDate;
    data['to_date'] = this.toDate;
    return data;
  }
}

class Eventactivity {
  String? title;
  String? description;
  String? startDate;
  String? endDate;

  Eventactivity({this.title, this.description, this.startDate, this.endDate});

  Eventactivity.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    description = json['description'];
    startDate = json['start_date'];
    endDate = json['end_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['title'] = this.title;
    data['description'] = this.description;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    return data;
  }
}

class TopPerformance {
  int? studentRank;
  num? obtainMarks;
  num? totalMaxMarks;
  int? id;
  int? fkStudent;
  num? percentage;
  String? name;
  String? section;
  String? studentCode;

  TopPerformance(
      {this.studentRank,
      this.obtainMarks,
      this.totalMaxMarks,
      this.id,
      this.fkStudent,
      this.percentage,
      this.name,
      this.section,
      this.studentCode});

  TopPerformance.fromJson(Map<String, dynamic> json) {
    studentRank = json['student_rank'];
    obtainMarks = json['obtain_marks'];
    totalMaxMarks = json['total_maxMarks'];
    id = json['id'];
    fkStudent = json['fk_student'];
    percentage = json['percentage'];
    name = json['name'];
    section = json['section'];
    studentCode = json['student_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['student_rank'] = this.studentRank;
    data['obtain_marks'] = this.obtainMarks;
    data['total_maxMarks'] = this.totalMaxMarks;
    data['id'] = this.id;
    data['fk_student'] = this.fkStudent;
    data['percentage'] = this.percentage;
    data['name'] = this.name;
    data['section'] = this.section;
    data['student_code'] = this.studentCode;
    return data;
  }
}
