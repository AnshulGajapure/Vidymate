class ClassAndSectionModel {
  int? status;
  List<Payload>? payload;

  ClassAndSectionModel({this.status, this.payload});

  ClassAndSectionModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['payload'] != null) {
      payload = <Payload>[];
      json['payload'].forEach((v) {
        payload!.add(new Payload.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.payload != null) {
      data['payload'] = this.payload!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Payload {
  int? id;
  int? fkClassId;
  String? section;
  String? medium;
  String? minStrength;
  String? maxStrength;
  bool? activeStatus;
  String? className;
  String? classCode;

  Payload(
      {this.id,
      this.fkClassId,
      this.section,
      this.medium,
      this.minStrength,
      this.maxStrength,
      this.activeStatus,
      this.className,
      this.classCode});

  Payload.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fkClassId = json['fk_class_id'];
    section = json['section'];
    medium = json['medium'];
    minStrength = json['min_strength'];
    maxStrength = json['max_strength'];
    activeStatus = json['active_status'];
    className = json['class_name'];
    classCode = json['class_code'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['fk_class_id'] = this.fkClassId;
    data['section'] = this.section;
    data['medium'] = this.medium;
    data['min_strength'] = this.minStrength;
    data['max_strength'] = this.maxStrength;
    data['active_status'] = this.activeStatus;
    data['class_name'] = this.className;
    data['class_code'] = this.classCode;
    return data;
  }
}
