class TeacherLoginOTP {
  int? status;
  String? msg;
  int? otp;
  int? schoolStatfId;
  int? staffId;

  TeacherLoginOTP(
      {this.status, this.msg, this.otp, this.schoolStatfId, this.staffId});

  TeacherLoginOTP.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
    otp = json['otp'];
    schoolStatfId = json['school_statf_id'];
    staffId = json['staff_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    data['otp'] = this.otp;
    data['school_statf_id'] = this.schoolStatfId;
    data['staff_id'] = this.staffId;
    return data;
  }
}
