class AcademicSessionModel {
  int? status;
  List<Payload>? payload;

  AcademicSessionModel({this.status, this.payload});

  AcademicSessionModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['payload'] != null) {
      payload = <Payload>[];
      json['payload'].forEach((v) {
        payload!.add(new Payload.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    if (this.payload != null) {
      data['payload'] = this.payload!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Payload {
  int? id;
  int? fkSuperadminId;
  int? fkOrganizationId;
  String? name;
  String? startDate;
  String? endDate;
  bool? currentSession;
  String? createdDate;
  String? insertBy;
  String? insertDate;
  Null? lastInsertBy;
  String? lastCreatedDate;

  Payload(
      {this.id,
      this.fkSuperadminId,
      this.fkOrganizationId,
      this.name,
      this.startDate,
      this.endDate,
      this.currentSession,
      this.createdDate,
      this.insertBy,
      this.insertDate,
      this.lastInsertBy,
      this.lastCreatedDate});

  Payload.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fkSuperadminId = json['fk_superadmin_id'];
    fkOrganizationId = json['fk_organization_id'];
    name = json['name'];
    startDate = json['start_date'];
    endDate = json['end_date'];
    currentSession = json['current_session'];
    createdDate = json['created_date'];
    insertBy = json['insert_by'];
    insertDate = json['insert_date'];
    lastInsertBy = json['last_insert_by'];
    lastCreatedDate = json['last_created_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['fk_superadmin_id'] = this.fkSuperadminId;
    data['fk_organization_id'] = this.fkOrganizationId;
    data['name'] = this.name;
    data['start_date'] = this.startDate;
    data['end_date'] = this.endDate;
    data['current_session'] = this.currentSession;
    data['created_date'] = this.createdDate;
    data['insert_by'] = this.insertBy;
    data['insert_date'] = this.insertDate;
    data['last_insert_by'] = this.lastInsertBy;
    data['last_created_date'] = this.lastCreatedDate;
    return data;
  }
}
