class TeacherDataModel {
  int? status;
  String? msg;
  TempDict? tempDict;
  String? bulkStudentExcelFormatUrl;

  TeacherDataModel(
      {this.status, this.msg, this.tempDict, this.bulkStudentExcelFormatUrl});

  TeacherDataModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    msg = json['msg'];
    tempDict = json['temp_dict'] != null
        ? new TempDict.fromJson(json['temp_dict'])
        : null;
    bulkStudentExcelFormatUrl = json['Bulk_student_excel_format_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['msg'] = this.msg;
    if (this.tempDict != null) {
      data['temp_dict'] = this.tempDict!.toJson();
    }
    data['Bulk_student_excel_format_url'] = this.bulkStudentExcelFormatUrl;
    return data;
  }
}

class TempDict {
  int? id;
  String? email;
  String? name;
  String? firebaseToken;
  String? userType;
  bool? isDefaultPassword;
  UserDetail? userDetail;
  List<SchoolModules>? schoolModules;
  String? token;

  TempDict(
      {this.id,
      this.email,
      this.name,
      this.firebaseToken,
      this.userType,
      this.isDefaultPassword,
      this.userDetail,
      this.schoolModules,
      this.token});

  TempDict.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    name = json['name'];
    firebaseToken = json['firebase_token'];
    userType = json['user_type'];
    isDefaultPassword = json['is_default_password'];
    userDetail = json['user_detail'] != null
        ? new UserDetail.fromJson(json['user_detail'])
        : null;
    if (json['school_modules'] != null) {
      schoolModules = <SchoolModules>[];
      json['school_modules'].forEach((v) {
        schoolModules!.add(new SchoolModules.fromJson(v));
      });
    }
    token = json['token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['email'] = this.email;
    data['name'] = this.name;
    data['firebase_token'] = this.firebaseToken;
    data['user_type'] = this.userType;
    data['is_default_password'] = this.isDefaultPassword;
    if (this.userDetail != null) {
      data['user_detail'] = this.userDetail!.toJson();
    }
    if (this.schoolModules != null) {
      data['school_modules'] =
          this.schoolModules!.map((v) => v.toJson()).toList();
    }
    data['token'] = this.token;
    return data;
  }
}

class UserDetail {
  String? userTypeDashboard;
  int? staffId;
  int? schoolEmpId;
  int? organizationId;
  String? organizationRegNo;
  String? organizationName;
  String? organizationSinceDate;
  int? fkSchoolId;
  String? schoolName;
  String? udiseNo;
  String? schoolContactEmail;
  String? schoolContactNumber;
  String? schoolAddress;
  String? schoolPincode;
  String? schoolLogo;
  String? lat;
  String? lng;
  String? firstName;
  String? lastName;
  bool? isAdmin;
  String? designation;
  int? designationId;

  UserDetail(
      {this.userTypeDashboard,
      this.staffId,
      this.schoolEmpId,
      this.organizationId,
      this.organizationRegNo,
      this.organizationName,
      this.organizationSinceDate,
      this.fkSchoolId,
      this.schoolName,
      this.udiseNo,
      this.schoolContactEmail,
      this.schoolContactNumber,
      this.schoolAddress,
      this.schoolPincode,
      this.schoolLogo,
      this.lat,
      this.lng,
      this.firstName,
      this.lastName,
      this.isAdmin,
      this.designation,
      this.designationId});

  UserDetail.fromJson(Map<String, dynamic> json) {
    userTypeDashboard = json['user_type_dashboard'];
    staffId = json['staff_id'];
    schoolEmpId = json['school_emp_id'];
    organizationId = json['organization_id'];
    organizationRegNo = json['organization_reg_no'];
    organizationName = json['organization_name'];
    organizationSinceDate = json['organization_since_date'];
    fkSchoolId = json['fk_school_id'];
    schoolName = json['school_name'];
    udiseNo = json['udise_no'];
    schoolContactEmail = json['school_contact_email'];
    schoolContactNumber = json['school_contact_number'];
    schoolAddress = json['school_address'];
    schoolPincode = json['school_pincode'];
    schoolLogo = json['school_logo'];
    lat = json['lat'];
    lng = json['lng'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    isAdmin = json['is_admin'];
    designation = json['designation'];
    designationId = json['designation_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['user_type_dashboard'] = this.userTypeDashboard;
    data['staff_id'] = this.staffId;
    data['school_emp_id'] = this.schoolEmpId;
    data['organization_id'] = this.organizationId;
    data['organization_reg_no'] = this.organizationRegNo;
    data['organization_name'] = this.organizationName;
    data['organization_since_date'] = this.organizationSinceDate;
    data['fk_school_id'] = this.fkSchoolId;
    data['school_name'] = this.schoolName;
    data['udise_no'] = this.udiseNo;
    data['school_contact_email'] = this.schoolContactEmail;
    data['school_contact_number'] = this.schoolContactNumber;
    data['school_address'] = this.schoolAddress;
    data['school_pincode'] = this.schoolPincode;
    data['school_logo'] = this.schoolLogo;
    data['lat'] = this.lat;
    data['lng'] = this.lng;
    data['first_name'] = this.firstName;
    data['last_name'] = this.lastName;
    data['is_admin'] = this.isAdmin;
    data['designation'] = this.designation;
    data['designation_id'] = this.designationId;
    return data;
  }
}

class SchoolModules {
  int? id;
  int? fkModuleId;
  String? fkModuleName;
  String? fkModuleIcon;
  int? fkModuleSequence;
  String? fkModulePageUrl;
  List<MenusData>? menusData;

  SchoolModules(
      {this.id,
      this.fkModuleId,
      this.fkModuleName,
      this.fkModuleIcon,
      this.fkModuleSequence,
      this.fkModulePageUrl,
      this.menusData});

  SchoolModules.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fkModuleId = json['fk_module_id'];
    fkModuleName = json['fk_module__name'];
    fkModuleIcon = json['fk_module__icon'];
    fkModuleSequence = json['fk_module__sequence'];
    fkModulePageUrl = json['fk_module__page_url'];
    if (json['menus_data'] != null) {
      menusData = <MenusData>[];
      json['menus_data'].forEach((v) {
        menusData!.add(new MenusData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['fk_module_id'] = this.fkModuleId;
    data['fk_module__name'] = this.fkModuleName;
    data['fk_module__icon'] = this.fkModuleIcon;
    data['fk_module__sequence'] = this.fkModuleSequence;
    data['fk_module__page_url'] = this.fkModulePageUrl;
    if (this.menusData != null) {
      data['menus_data'] = this.menusData!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class MenusData {
  int? id;
  int? sequence;
  String? name;
  String? icon;
  String? pageUrl;

  MenusData({this.id, this.sequence, this.name, this.icon, this.pageUrl});

  MenusData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    sequence = json['sequence'];
    name = json['name'];
    icon = json['icon'];
    pageUrl = json['page_url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['sequence'] = this.sequence;
    data['name'] = this.name;
    data['icon'] = this.icon;
    data['page_url'] = this.pageUrl;
    return data;
  }
}
