package com.app.vidyamate_teacher

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
